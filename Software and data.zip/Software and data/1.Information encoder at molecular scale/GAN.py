# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 21:17:54 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 13:27:32 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Improved GAN-based Tetramer Composition Generation System
Using correct 5-feature matching (based on final selected features.csv)
Automatically generates molecules with similar compositions
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import joblib
import warnings
warnings.filterwarnings('ignore')
import os
import sys
import time
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import gc
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from sklearn.metrics.pairwise import cosine_similarity
from scipy.spatial.distance import cdist

# ==================== Configuration ====================
# Using SVR_rbf model path
MODEL_DIR = r"C:\Users\ma'wei'bin\Desktop\Project\Tg\GroupModel_Augment3.0x_20260811_125755"
MODEL_PATH = os.path.join(MODEL_DIR, "SVR_rbf_model.pkl")
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.pkl")
FEATURE_CSV_PATH = os.path.join(MODEL_DIR, "Final_Selected_Features.csv")

TRAINING_DATA_FILE = "TLCP1.xlsx"
SELECTED_MOLECULES_FILE = "Selected_Molecules.xlsx"

# ==================== Load feature names from CSV ====================
def load_feature_names_from_csv(csv_path):
    """Load feature names from final selected features CSV"""
    if os.path.exists(csv_path):
        try:
            df = pd.read_csv(csv_path)
            # Find column containing feature names
            for col in df.columns:
                if 'Feature_Name' in col or 'name' in col.lower():
                    feature_names = df[col].tolist()
                    print(f"Loaded {len(feature_names)} feature names from CSV")
                    return feature_names
            # If no feature name column, try using feature index column
            if 'Feature_ID' in df.columns:
                indices = df['Feature_ID'].tolist()
                english_feature_names = [
                    "Mean_MolecularWeight", "Mean_RotatableBonds", "Mean_HeavyAtomCount",
                    "Mean_TPSA", "Mean_LogP", "Mean_HBondDonors", "Mean_HBondAcceptors",
                    "Mean_AromaticRatio", "Mean_RingCount", "Mean_RigidityIndex",
                    "Mean_PolarityIndex", "Mean_TopologicalIndex", "Mean_MolarRefractivity",
                    "Mean_ShapeIndex", "Mean_FlexibilityIndex", "Std_MolecularWeight",
                    "Std_RotatableBonds", "Std_HeavyAtomCount", "Std_TPSA", "Std_LogP",
                    "Std_HBondDonors", "Std_HBondAcceptors", "Std_AromaticRatio",
                    "Std_RingCount", "Std_RigidityIndex", "Max_MolecularWeight",
                    "Max_RotatableBonds", "Max_HeavyAtomCount", "Max_TPSA", "Max_LogP",
                    "Min_MolecularWeight", "Min_RotatableBonds", "Min_HeavyAtomCount",
                    "Min_TPSA", "Min_LogP", "Range_MolecularWeight", "Range_RotatableBonds",
                    "Range_HeavyAtomCount", "Range_TPSA", "Range_LogP",
                    "MolecularWeightxRigidity", "MolecularWeightxAromaticity",
                    "RigidityxAromaticity", "Polarity_Flexibility", "MolecularWeight_Flexibility",
                    "MonomerCount", "TotalMolecularWeight", "TotalAromaticity"
                ]
                feature_names = []
                for idx in indices:
                    if isinstance(idx, (int, np.integer)) and idx < len(english_feature_names):
                        feature_names.append(english_feature_names[idx])
                    else:
                        feature_names.append(f"Feature_{idx}")
                print(f"Loaded {len(feature_names)} feature names from CSV indices")
                return feature_names
        except Exception as e:
            print(f"Error loading feature CSV: {e}")
    return None

# Load feature names
FEATURE_NAMES = load_feature_names_from_csv(FEATURE_CSV_PATH)
if FEATURE_NAMES is None:
    # Use default feature names
    FEATURE_NAMES = [
        'Mean_TPSA',           # index 3
        'Mean_HBondDonors',    # index 5
        'Mean_AromaticRatio',  # index 7
        'Mean_RigidityIndex',  # index 9
        'Mean_PolarityIndex'   # index 10
    ]
    print(f"Using default {len(FEATURE_NAMES)} feature names")

# ==================== Correct feature list (based on final selected features.csv) ====================
# Using feature names loaded from CSV
CORRECT_FEATURES = FEATURE_NAMES

# Map English names to Chinese indices for internal use
ENGLISH_TO_CHINESE = {
    'Mean_TPSA': 'Mean_TPSA',
    'Mean_HBondDonors': 'Mean_HBondDonors',
    'Mean_AromaticRatio': 'Mean_AromaticRatio',
    'Mean_RigidityIndex': 'Mean_RigidityIndex',
    'Mean_PolarityIndex': 'Mean_PolarityIndex',
    'Std_MolecularWeight': 'Std_MolecularWeight',
    'Std_TPSA': 'Std_TPSA',
    'Std_HBondDonors': 'Std_HBondDonors',
    'Std_HBondAcceptors': 'Std_HBondAcceptors',
    'Std_AromaticRatio': 'Std_AromaticRatio',
    'TotalMolecularWeight': 'TotalMolecularWeight',
}

# Keep only first 5 features for GAN (or as needed)
# Using: Mean_TPSA, Mean_AromaticRatio, Mean_RigidityIndex, Mean_PolarityIndex
GAN_FEATURES = ['Mean_TPSA', 'Mean_AromaticRatio', 'Mean_RigidityIndex', 'Mean_PolarityIndex']
# If these features don't exist, use defaults
for feat in GAN_FEATURES:
    if feat not in CORRECT_FEATURES:
        GAN_FEATURES = ['Mean_TPSA', 'Mean_HBondDonors', 'Mean_AromaticRatio', 'Mean_RigidityIndex', 'Mean_PolarityIndex']
        break

print(f"\nGAN features used: {GAN_FEATURES}")

# ==================== GAN Configuration ====================
GAN_CONFIG = {
    'latent_dim': 100,
    'noise_dim': 50,
    'generator_hidden': 256,
    'discriminator_hidden': 256,
    'batch_size': 128,
    'epochs': 300,
    'learning_rate': 0.0001,
    'beta1': 0.5,
    'beta2': 0.999,
    'sample_interval': 20,
    'use_cuda': torch.cuda.is_available(),
    'gradient_penalty_weight': 10,
    'n_critic': 5,
    'dropout_rate': 0.2,
}

# ==================== Hard-coded monomer ranges ====================
HARD_CODED_RANGES = {
    'monomer_order': ['HBA', 'HNA', 'TA', 'HQ'],
    
    'ranges': {
        'HBA': {'min': 0.35, 'max': 0.58, 'mean': 0.45},
        'HNA': {'min': 0.12, 'max': 0.28, 'mean': 0.20},
        'TA': {'min': 0.12, 'max': 0.22, 'mean': 0.17},
        'HQ': {'min': 0.12, 'max': 0.22, 'mean': 0.17}
    },
    
    'monomer_info': {
        'HBA': {
            'name': 'Parahydroxybenzoic acid',
            'smiles': 'OC1=CC=C(C(O)=O)C=C1',
        },
        'HNA': {
            'name': '2-Hydroxy-6-naphthalic acid',
            'smiles': 'O=C(O)C1=CC2=CC=C(O)C=C2C=C1',
        },
        'TA': {
            'name': 'Terephthalic acid',
            'smiles': 'O=C(O)C1=CC=C(C(O)=O)C=C1',
        },
        'HQ': {
            'name': 'Hydroquinone',
            'smiles': 'OC1=CC=C(O)C=C1',
        }
    }
}

# ==================== Reference samples ====================
REFERENCE_SAMPLES = {
    'K280': {
        'composition': [0.40, 0.18, 0.24, 0.18],
        'description': 'K280 - Reference sample 1',
        'monomers': ['HBA', 'HQ', 'HNA', 'TA'],
        'experimental_tg': 165.0
    },
    'K310': {
        'composition': [0.45, 0.16, 0.23, 0.16],
        'description': 'K310 - Reference sample 2',
        'monomers': ['HBA', 'HQ', 'HNA', 'TA'],
        'experimental_tg': 175.0
    },
    'K335': {
        'composition': [0.54, 0.15, 0.15, 0.15],
        'description': 'K335 - Reference sample 3',
        'monomers': ['HBA', 'HQ', 'HNA', 'TA'],
        'experimental_tg': 185.0
    }
}

# ==================== Correct Feature Extractor (based on final selected features) ====================

class CorrectFeatureExtractor:
    """Correct feature extractor - matching final selected features"""
    
    def __init__(self, feature_names):
        self.feature_names = feature_names
        
        # Feature index mapping
        self.feature_indices = {
            'Mean_TPSA': 3,
            'Mean_HBondDonors': 5,
            'Mean_AromaticRatio': 7,
            'Mean_RigidityIndex': 9,
            'Mean_PolarityIndex': 10,
            'Mean_MolecularWeight': 0,
            'Mean_RotatableBonds': 1,
            'Mean_HeavyAtomCount': 2,
            'Mean_LogP': 4,
            'Mean_HBondAcceptors': 6,
            'Mean_RingCount': 8,
            'Mean_TopologicalIndex': 11,
            'Mean_MolarRefractivity': 12,
            'Mean_ShapeIndex': 13,
            'Mean_FlexibilityIndex': 14,
            'Std_MolecularWeight': 15,
            'Std_TPSA': 18,
            'Std_HBondDonors': 20,
            'Std_HBondAcceptors': 21,
            'Std_AromaticRatio': 22,
            'TotalMolecularWeight': 46,
        }
        
        self.monomer_features_cache = {}
        print(f"Correct feature extractor initialized")
        print(f"Number of features: {len(self.feature_names)}")
        print(f"Feature list: {self.feature_names[:5]}...")
    
    def _extract_monomer_features(self, smiles):
        """Extract all 15 monomer features from SMILES string"""
        if smiles in self.monomer_features_cache:
            return self.monomer_features_cache[smiles]
        
        try:
            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                return None
            
            features = []
            
            # 0. Molecular weight
            mol_weight = Descriptors.MolWt(mol)
            features.append(mol_weight)
            
            # 1. Rotatable bonds
            rotatable_bonds = Descriptors.NumRotatableBonds(mol)
            features.append(rotatable_bonds)
            
            # 2. Heavy atoms
            heavy_atoms = mol.GetNumHeavyAtoms()
            features.append(heavy_atoms)
            
            # 3. TPSA
            tpsa = Descriptors.TPSA(mol)
            features.append(tpsa)
            
            # 4. LogP
            logp = Crippen.MolLogP(mol)
            features.append(logp)
            
            # 5. H-bond donors
            hbd = Descriptors.NumHDonors(mol)
            features.append(hbd)
            
            # 6. H-bond acceptors
            hba = Descriptors.NumHAcceptors(mol)
            features.append(hba)
            
            # 7. Aromatic ratio
            aromatic_atoms = sum(1 for atom in mol.GetAtoms() if atom.GetIsAromatic())
            aromatic_ratio = aromatic_atoms / max(heavy_atoms, 1)
            features.append(aromatic_ratio)
            
            # 8. Ring count
            num_rings = Descriptors.RingCount(mol)
            features.append(num_rings)
            
            # 9. Rigidity index
            rigid_index = (heavy_atoms - rotatable_bonds) / max(heavy_atoms, 1)
            features.append(rigid_index)
            
            # 10. Polarity index
            polarity_index = tpsa / max(mol_weight, 1)
            features.append(polarity_index)
            
            # 11. Chi0
            chi0 = Descriptors.Chi0(mol)
            features.append(chi0)
            
            # 12. Molar refractivity
            mr = Crippen.MolMR(mol)
            features.append(mr)
            
            # 13. Shape index
            shape_index = (heavy_atoms ** (1/3)) / max(rotatable_bonds + 1, 1)
            features.append(shape_index)
            
            # 14. Flexibility index
            flexibility_index = rotatable_bonds / max(heavy_atoms, 1)
            features.append(flexibility_index)
            
            result = np.array(features)
            self.monomer_features_cache[smiles] = result
            return result
            
        except Exception as e:
            return None
    
    def _calculate_polymer_features(self, mono_features, ratios):
        """Calculate all 43 polymer features"""
        polymer_features = []
        
        # 1. Mean values (15) - weighted by ratio
        for i in range(mono_features.shape[1]):
            weighted_avg = np.sum(mono_features[:, i] * ratios)
            polymer_features.append(weighted_avg)
        
        # 2. Standard deviations (10)
        if len(mono_features) > 1:
            for i in range(min(10, mono_features.shape[1])):
                polymer_features.append(np.std(mono_features[:, i]))
        else:
            polymer_features.extend([0] * 10)
        
        # 3. Maximum values (5)
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.max(mono_features[:, i]))
        
        # 4. Minimum values (5)
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.min(mono_features[:, i]))
        
        # 5. Range values (5)
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.max(mono_features[:, i]) - np.min(mono_features[:, i]))
        
        # 6. Interaction features (5)
        mw_mean = np.mean(mono_features[:, 0])
        rigid_mean = np.mean(mono_features[:, 9])
        aromatic_mean = np.mean(mono_features[:, 7])
        tpsa_mean = np.mean(mono_features[:, 3])
        rotatable_mean = np.mean(mono_features[:, 1])
        
        polymer_features.append(mw_mean * rigid_mean)
        polymer_features.append(mw_mean * aromatic_mean)
        polymer_features.append(rigid_mean * aromatic_mean)
        polymer_features.append(tpsa_mean / max(rotatable_mean, 0.1))
        polymer_features.append(mw_mean / max(rotatable_mean, 0.1))
        
        # 7. Aggregation features (3)
        polymer_features.append(len(mono_features))  # Monomer count
        polymer_features.append(np.sum(mono_features[:, 0]))  # Total molecular weight
        polymer_features.append(np.sum(mono_features[:, 7]))  # Total aromaticity
        
        return np.array(polymer_features)
    
    def extract_features(self, monomer_composition, monomer_smiles_dict):
        """Extract features for a single sample"""
        # Get monomer SMILES
        smiles_list = []
        ratios = []
        for monomer, ratio in zip(['HBA', 'HNA', 'TA', 'HQ'], monomer_composition):
            if ratio > 0.001:
                if monomer in monomer_smiles_dict:
                    smiles_list.append(monomer_smiles_dict[monomer])
                    ratios.append(ratio)
        
        if not smiles_list:
            return None
        
        # Normalize ratios
        ratios = np.array(ratios)
        if ratios.sum() > 0:
            ratios = ratios / ratios.sum()
        else:
            ratios = np.ones(len(smiles_list)) / len(smiles_list)
        
        # Extract features for each monomer
        mono_features = []
        for smiles in smiles_list:
            feats = self._extract_monomer_features(smiles)
            if feats is not None:
                mono_features.append(feats)
        
        if not mono_features:
            return None
        
        mono_features = np.array(mono_features)
        
        # Calculate 43 polymer features
        polymer_features = self._calculate_polymer_features(mono_features, ratios)
        
        # Select specified features
        selected_features = []
        for feature_name in self.feature_names:
            # Find feature index
            idx = self.feature_indices.get(feature_name, -1)
            if idx >= 0 and idx < len(polymer_features):
                selected_features.append(polymer_features[idx])
            else:
                # Try looking up by name
                for key, value in self.feature_indices.items():
                    if key == feature_name:
                        selected_features.append(polymer_features[value] if value < len(polymer_features) else 0.0)
                        break
                else:
                    selected_features.append(0.0)
        
        return np.array(selected_features)


# ==================== GAN Model Definitions ====================

class ImprovedGenerator(nn.Module):
    """Improved generator model"""
    
    def __init__(self, latent_dim, noise_dim, output_dim=4, hidden_dim=256, dropout_rate=0.2):
        super(ImprovedGenerator, self).__init__()
        
        input_dim = latent_dim + noise_dim
        
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.BatchNorm1d(hidden_dim * 2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.BatchNorm1d(hidden_dim // 2),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.Linear(hidden_dim // 2, output_dim),
            nn.Softmax(dim=1)
        )
        
        self._initialize_weights()
    
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
    
    def forward(self, z):
        return self.model(z)


class ImprovedDiscriminator(nn.Module):
    """Improved discriminator model"""
    
    def __init__(self, input_dim=4, hidden_dim=256, dropout_rate=0.2):
        super(ImprovedDiscriminator, self).__init__()
        
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.Linear(hidden_dim // 2, 1)
        )
        
        self._initialize_weights()
    
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        return self.model(x)


class ImprovedGANTrainer:
    """Improved GAN trainer"""
    
    def __init__(self, config, real_data, monomer_ranges):
        self.config = config
        self.real_data = real_data
        self.monomer_ranges = monomer_ranges
        self.device = torch.device("cuda" if config['use_cuda'] else "cpu")
        
        print(f"Initializing improved GAN trainer...")
        print(f"Device: {self.device}")
        print(f"Real data shape: {self.real_data.shape}")
        
        self.generator = ImprovedGenerator(
            latent_dim=config['latent_dim'],
            noise_dim=config['noise_dim'],
            output_dim=4,
            hidden_dim=config['generator_hidden'],
            dropout_rate=config['dropout_rate']
        ).to(self.device)
        
        self.discriminator = ImprovedDiscriminator(
            input_dim=4,
            hidden_dim=config['discriminator_hidden'],
            dropout_rate=config['dropout_rate']
        ).to(self.device)
        
        self.optimizer_G = optim.AdamW(
            self.generator.parameters(), 
            lr=config['learning_rate'], 
            betas=(config['beta1'], config['beta2']),
            weight_decay=1e-4
        )
        self.optimizer_D = optim.AdamW(
            self.discriminator.parameters(), 
            lr=config['learning_rate'], 
            betas=(config['beta1'], config['beta2']),
            weight_decay=1e-4
        )
        
        self.scheduler_G = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer_G, T_max=config['epochs'], eta_min=1e-6
        )
        self.scheduler_D = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer_D, T_max=config['epochs'], eta_min=1e-6
        )
        
        self._create_dataloader()
        
        self.history = {
            'd_losses': [], 'g_losses': [], 'w_distances': [], 'gp_values': [],
            'diversity_scores': []
        }
    
    def _create_dataloader(self):
        real_data_tensor = torch.FloatTensor(self.real_data)
        dataset = TensorDataset(real_data_tensor)
        self.dataloader = DataLoader(
            dataset, 
            batch_size=self.config['batch_size'],
            shuffle=True,
            num_workers=0,
            drop_last=True,
            pin_memory=True if self.config['use_cuda'] else False
        )
        print(f"DataLoader created, batch size: {self.config['batch_size']}")
    
    def _compute_gradient_penalty(self, real_samples, fake_samples):
        alpha = torch.rand(real_samples.size(0), 1).to(self.device)
        interpolates = (alpha * real_samples + (1 - alpha) * fake_samples).requires_grad_(True)
        d_interpolates = self.discriminator(interpolates)
        
        gradients = torch.autograd.grad(
            outputs=d_interpolates,
            inputs=interpolates,
            grad_outputs=torch.ones_like(d_interpolates).to(self.device),
            create_graph=True,
            retain_graph=True,
            only_inputs=True
        )[0]
        
        gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
        return gradient_penalty
    
    def _calculate_diversity_score(self, samples):
        if len(samples) < 2:
            return 0.0
        
        from sklearn.metrics.pairwise import pairwise_distances
        distances = pairwise_distances(samples, metric='euclidean')
        np.fill_diagonal(distances, 0)
        diversity = np.mean(distances[distances > 0])
        return diversity
    
    def train_epoch(self, epoch):
        d_losses = []
        g_losses = []
        w_distances = []
        gp_values = []
        all_fake_samples = []
        
        for i, (real_batch,) in enumerate(self.dataloader):
            real_batch = real_batch.to(self.device)
            batch_size = real_batch.size(0)
            
            # Train discriminator
            for _ in range(self.config['n_critic']):
                self.optimizer_D.zero_grad()
                
                noise = torch.randn(batch_size, self.config['noise_dim']).to(self.device)
                latent = torch.randn(batch_size, self.config['latent_dim']).to(self.device)
                z = torch.cat([latent, noise], dim=1)
                
                fake_batch = self.generator(z).detach()
                
                real_validity = self.discriminator(real_batch)
                fake_validity = self.discriminator(fake_batch)
                
                w_distance = real_validity.mean() - fake_validity.mean()
                gradient_penalty = self._compute_gradient_penalty(real_batch.data, fake_batch.data)
                
                d_loss = -w_distance + self.config['gradient_penalty_weight'] * gradient_penalty
                
                d_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.discriminator.parameters(), max_norm=1.0)
                self.optimizer_D.step()
                
                d_losses.append(d_loss.item())
                w_distances.append(w_distance.item())
                gp_values.append(gradient_penalty.item())
            
            # Train generator
            self.optimizer_G.zero_grad()
            
            noise = torch.randn(batch_size, self.config['noise_dim']).to(self.device)
            latent = torch.randn(batch_size, self.config['latent_dim']).to(self.device)
            z = torch.cat([latent, noise], dim=1)
            
            fake_batch = self.generator(z)
            all_fake_samples.append(fake_batch.cpu().detach().numpy())
            
            g_loss = -self.discriminator(fake_batch).mean()
            
            g_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.generator.parameters(), max_norm=1.0)
            self.optimizer_G.step()
            
            g_losses.append(g_loss.item())
        
        avg_d_loss = np.mean(d_losses)
        avg_g_loss = np.mean(g_losses)
        avg_w_distance = np.mean(w_distances)
        avg_gp = np.mean(gp_values)
        
        if all_fake_samples:
            all_samples = np.vstack(all_fake_samples)
            diversity_score = self._calculate_diversity_score(all_samples)
            self.history['diversity_scores'].append(diversity_score)
        
        self.history['d_losses'].append(avg_d_loss)
        self.history['g_losses'].append(avg_g_loss)
        self.history['w_distances'].append(avg_w_distance)
        self.history['gp_values'].append(avg_gp)
        
        return avg_d_loss, avg_g_loss, avg_w_distance, avg_gp
    
    def train(self):
        print(f"\nStarting improved GAN training, {self.config['epochs']} epochs...")
        print("-"*70)
        
        start_time = time.time()
        best_diversity = 0
        
        for epoch in range(self.config['epochs']):
            d_loss, g_loss, w_dist, gp = self.train_epoch(epoch)
            
            self.scheduler_G.step()
            self.scheduler_D.step()
            
            if (epoch + 1) % self.config['sample_interval'] == 0:
                current_lr = self.optimizer_G.param_groups[0]['lr']
                diversity = self.history['diversity_scores'][-1] if self.history['diversity_scores'] else 0
                
                print(f"Epoch {epoch+1:3d}/{self.config['epochs']} | "
                      f"D_loss: {d_loss:.4f} | G_loss: {g_loss:.4f} | "
                      f"W_dist: {w_dist:.4f} | GP: {gp:.4f} | "
                      f"Div: {diversity:.4f} | LR: {current_lr:.2e}")
                
                samples = self.generate_samples(n_samples=10, epoch=epoch+1)
                
                if diversity > best_diversity:
                    best_diversity = diversity
                    self.save_models(path='gan_models/best')
        
        elapsed_time = time.time() - start_time
        print(f"\nGAN training completed, time: {elapsed_time:.1f} seconds")
        self.plot_training_history()
    
    def generate_samples(self, n_samples, epoch=None, temperature=1.0):
        self.generator.eval()
        
        with torch.no_grad():
            noise = torch.randn(n_samples, self.config['noise_dim']).to(self.device)
            latent = torch.randn(n_samples, self.config['latent_dim']).to(self.device)
            z = torch.cat([latent, noise], dim=1)
            
            generated = self.generator(z).cpu().numpy()
            
            if temperature != 1.0:
                generated = np.power(generated, 1/temperature)
                generated = generated / generated.sum(axis=1, keepdims=True)
            
            constrained = []
            for sample in generated:
                constrained_sample = self._apply_monomer_constraints(sample)
                constrained.append(constrained_sample)
            
            generated_constrained = np.array(constrained)
        
        self.generator.train()
        
        if epoch:
            print(f"Epoch {epoch} generated samples:")
            unique_samples = len(np.unique(generated_constrained, axis=0))
            print(f"  Unique samples: {unique_samples}/{n_samples}")
            for i, sample in enumerate(generated_constrained[:5]):
                print(f"  Sample{i+1}: HBA={sample[0]:.3f}, HNA={sample[1]:.3f}, "
                      f"TA={sample[2]:.3f}, HQ={sample[3]:.3f}, sum={sample.sum():.3f}")
        
        return generated_constrained
    
    def _apply_monomer_constraints(self, composition):
        constrained = np.copy(composition)
        monomer_order = ['HBA', 'HNA', 'TA', 'HQ']
        
        for i, monomer in enumerate(monomer_order):
            min_val = self.monomer_ranges[monomer]['min'] * 0.9
            max_val = self.monomer_ranges[monomer]['max'] * 1.1
            constrained[i] = np.clip(constrained[i], min_val, max_val)
        
        constrained = np.maximum(constrained, 0.001)
        constrained = constrained / constrained.sum()
        
        return constrained
    
    def plot_training_history(self):
        fig, axes = plt.subplots(2, 3, figsize=(15, 8))
        
        axes[0, 0].plot(self.history['d_losses'])
        axes[0, 0].set_title('Discriminator Loss')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].grid(True, alpha=0.3)
        
        axes[0, 1].plot(self.history['g_losses'])
        axes[0, 1].set_title('Generator Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].grid(True, alpha=0.3)
        
        axes[0, 2].plot(self.history['w_distances'])
        axes[0, 2].set_title('Wasserstein Distance')
        axes[0, 2].set_xlabel('Epoch')
        axes[0, 2].set_ylabel('Distance')
        axes[0, 2].grid(True, alpha=0.3)
        
        axes[1, 0].plot(self.history['gp_values'])
        axes[1, 0].set_title('Gradient Penalty')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].set_ylabel('Penalty Value')
        axes[1, 0].grid(True, alpha=0.3)
        
        if self.history['diversity_scores']:
            axes[1, 1].plot(self.history['diversity_scores'])
            axes[1, 1].set_title('Sample Diversity')
            axes[1, 1].set_xlabel('Epoch')
            axes[1, 1].set_ylabel('Diversity Score')
            axes[1, 1].grid(True, alpha=0.3)
        
        axes[1, 2].axis('off')
        
        plt.tight_layout()
        plt.savefig('improved_gan_training_history.png', dpi=150)
        plt.show()
    
    def save_models(self, path='gan_models'):
        os.makedirs(path, exist_ok=True)
        torch.save({
            'model_state_dict': self.generator.state_dict(),
            'config': self.config,
            'history': self.history
        }, os.path.join(path, 'generator.pth'))
        torch.save({
            'model_state_dict': self.discriminator.state_dict(),
            'config': self.config
        }, os.path.join(path, 'discriminator.pth'))
        print(f"Models saved to: {path}")
    
    def load_models(self, path='gan_models'):
        generator_checkpoint = torch.load(os.path.join(path, 'generator.pth'))
        self.generator.load_state_dict(generator_checkpoint['model_state_dict'])
        
        discriminator_checkpoint = torch.load(os.path.join(path, 'discriminator.pth'))
        self.discriminator.load_state_dict(discriminator_checkpoint['model_state_dict'])
        
        print(f"Models loaded from {path}")


# ==================== Large-Scale Tg Predictor (using correct features) ====================

class LargeScaleTgPredictor:
    """Large-scale Tg predictor using correct features"""
    
    def __init__(self, model_path, scaler_path, feature_names):
        print(f"Initializing large-scale Tg predictor...")
        print(f"Model file: {model_path}")
        print(f"Scaler file: {scaler_path}")
        
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model file not found: {model_path}")
        if not os.path.exists(scaler_path):
            raise FileNotFoundError(f"Scaler file not found: {scaler_path}")
        
        try:
            # Load model and scaler
            self.model = joblib.load(model_path)
            self.scaler = joblib.load(scaler_path)
            
            # Initialize correct feature extractor
            self.feature_extractor = CorrectFeatureExtractor(feature_names)
            
            # Verify scaler feature count
            if hasattr(self.scaler, 'n_features_in_'):
                self.expected_features = self.scaler.n_features_in_
                print(f"Scaler expected features: {self.expected_features}")
            elif hasattr(self.scaler, 'mean_'):
                self.expected_features = len(self.scaler.mean_)
                print(f"Scaler expected features: {self.expected_features}")
            else:
                self.expected_features = len(feature_names)
                print(f"Using feature count: {self.expected_features}")
            
            print(f"SVR_rbf model and scaler loaded successfully")
            
        except Exception as e:
            print(f"Failed to load model: {e}")
            raise
    
    def predict_tg_batch(self, compositions, monomer_smiles_dict, batch_size=2000):
        """Batch predict Tg values"""
        n_samples = len(compositions)
        print(f"Starting batch Tg prediction for {n_samples} samples...")
        
        all_predictions = []
        valid_count = 0
        invalid_count = 0
        all_features = []
        
        for i in range(0, n_samples, batch_size):
            batch_compositions = compositions[i:i+batch_size]
            
            batch_features = []
            for comp in batch_compositions:
                features = self.feature_extractor.extract_features(comp, monomer_smiles_dict)
                if features is not None:
                    batch_features.append(features)
                    valid_count += 1
                else:
                    invalid_count += 1
            
            if not batch_features:
                continue
            
            batch_features = np.array(batch_features)
            all_features.extend(batch_features)
            
            # Verify feature count
            if batch_features.shape[1] != self.expected_features:
                print(f"Warning: Extracted features count: {batch_features.shape[1]}, expected: {self.expected_features}")
                if batch_features.shape[1] > self.expected_features:
                    batch_features = batch_features[:, :self.expected_features]
                elif batch_features.shape[1] < self.expected_features:
                    padding = np.zeros((batch_features.shape[0], self.expected_features - batch_features.shape[1]))
                    batch_features = np.hstack([batch_features, padding])
            
            try:
                # Standardize features
                batch_features_scaled = self.scaler.transform(batch_features)
                
                # Predict Tg
                batch_predictions = self.model.predict(batch_features_scaled)
                
                # Outlier detection
                for pred in batch_predictions:
                    if pred < 20 or pred > 400:
                        print(f"Warning: Detected abnormal Tg value {pred:.1f}°C")
                
                all_predictions.extend(batch_predictions)
                
            except Exception as e:
                print(f"Error predicting batch {i//batch_size + 1}: {e}")
                continue
            
            processed = min(i + batch_size, n_samples)
            if processed % 5000 == 0 or processed >= n_samples:
                print(f"  Tg prediction progress: {processed}/{n_samples} ({processed/n_samples*100:.1f}%)")
        
        predictions_array = np.array(all_predictions)
        
        print(f"\nTg prediction completed:")
        print(f"  Total samples: {n_samples}")
        print(f"  Valid predictions: {len(predictions_array)}")
        print(f"  Invalid samples: {invalid_count}")
        
        if len(predictions_array) > 0:
            print(f"  Average predicted Tg: {predictions_array.mean():.1f}°C")
            print(f"  Std deviation: {predictions_array.std():.1f}°C")
            print(f"  Min predicted Tg: {predictions_array.min():.1f}°C")
            print(f"  Max predicted Tg: {predictions_array.max():.1f}°C")
            print(f"  Quartiles: Q1={np.percentile(predictions_array, 25):.1f}°C, "
                  f"Q3={np.percentile(predictions_array, 75):.1f}°C")
            
            # Show Tg distribution bins
            print(f"  Tg distribution:")
            bins = [0, 50, 100, 120, 140, 160, 180, 200, 220, 240, 260, 300, 350, 400]
            hist, bin_edges = np.histogram(predictions_array, bins=bins)
            for j in range(len(hist)):
                if hist[j] > 0:
                    print(f"    {bin_edges[j]:.0f}-{bin_edges[j+1]:.0f}°C: {hist[j]} ({hist[j]/len(predictions_array)*100:.1f}%)")
        
        return predictions_array


# ==================== Hard-Coded Range Controller ====================

class HardCodedRangeController:
    def __init__(self):
        self.monomer_order = HARD_CODED_RANGES['monomer_order']
        self.ranges = HARD_CODED_RANGES['ranges']
        self.monomer_info = HARD_CODED_RANGES['monomer_info']
        
        self.monomer_smiles_dict = {}
        for monomer_id, info in self.monomer_info.items():
            self.monomer_smiles_dict[monomer_id] = info['smiles']
        
        print("\n" + "="*60)
        print("Hard-coded Monomer Range Settings")
        print("="*60)
        self.display_ranges()
    
    def display_ranges(self):
        print("\nMonomer info (ordered: HBA, HNA, TA, HQ):")
        print("-"*50)
        for i, monomer_id in enumerate(self.monomer_order):
            info = self.monomer_info[monomer_id]
            print(f"\n{monomer_id}: {info['name']}")
            print(f"  SMILES: {info['smiles']}")
            print(f"  Ratio range: {self.ranges[monomer_id]['min']:.2f} - {self.ranges[monomer_id]['max']:.2f}")
            print(f"  Mean: {self.ranges[monomer_id]['mean']:.2f}")
    
    def get_valid_composition(self, composition):
        valid_comp = np.copy(composition)
        for i, monomer_id in enumerate(self.monomer_order):
            min_val = self.ranges[monomer_id]['min'] * 0.9
            max_val = self.ranges[monomer_id]['max'] * 1.1
            valid_comp[i] = np.clip(valid_comp[i], min_val, max_val)
        
        valid_comp = np.maximum(valid_comp, 0.001)
        valid_comp = valid_comp / valid_comp.sum()
        return valid_comp


# ==================== Excel Style Setter ====================

class ExcelStyleSetter:
    def __init__(self):
        self.header_font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
        self.header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
        self.thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        self.center_alignment = Alignment(horizontal='center', vertical='center')
        self.right_alignment = Alignment(horizontal='right', vertical='center')
    
    def apply_header_style(self, cell):
        cell.font = self.header_font
        cell.fill = self.header_fill
        cell.alignment = self.center_alignment
        cell.border = self.thin_border
    
    def apply_data_cell_style(self, cell, data_type='number'):
        if data_type == 'number':
            cell.alignment = self.right_alignment
        else:
            cell.alignment = self.center_alignment
        cell.border = self.thin_border


# ==================== Main Program ====================

def main():
    print("="*80)
    print("Improved GAN-based Tetramer Composition Generation System")
    print("Using correct feature matching with trained SVR_rbf model")
    print(f"Model path: {MODEL_PATH}")
    print(f"Scaler path: {SCALER_PATH}")
    print(f"Feature CSV: {FEATURE_CSV_PATH}")
    print("="*80)
    
    start_time = time.time()
    
    # 1. Initialize hard-coded range controller
    print("\n1. Initializing hard-coded range controller")
    print("-"*40)
    range_controller = HardCodedRangeController()
    
    # 2. Prepare real data (based on high Tg sample features)
    print("\n2. Preparing real data (based on high Tg sample features)")
    print("-"*40)
    
    real_data = []
    n_random_real = 2000
    
    print(f"Generating {n_random_real} high Tg-tendency real samples...")
    
    # Define different Dirichlet parameters favoring high Tg compositions
    alphas_list = [
        [5.0, 1.5, 2.0, 1.5],  # HBA dominant (high aromatic ratio)
        [4.5, 2.5, 1.5, 1.5],  # High HBA+HNA (high rigidity)
        [4.0, 2.0, 2.5, 1.5],  # High HBA+TA
        [4.5, 1.5, 1.5, 2.5],  # Slightly high HBA+HQ
        [3.5, 3.0, 2.0, 1.5],  # Balanced HBA+HNA
        [5.5, 1.5, 1.5, 1.5],  # Very high HBA
        [4.0, 2.5, 2.0, 1.5],  # HBA+HNA
        [4.0, 2.0, 2.0, 2.0],  # Balanced with slightly higher HBA
        [3.5, 2.5, 2.5, 1.5],  # High HNA+TA
        [4.0, 2.0, 1.5, 2.5],  # HBA+HQ
    ]
    
    for _ in range(n_random_real):
        idx = np.random.randint(0, len(alphas_list))
        alphas = alphas_list[idx]
        # Add some random perturbation
        alphas = np.array(alphas) * (1 + 0.2 * np.random.randn(4))
        alphas = np.maximum(alphas, 1.0)
        
        random_comp = np.random.dirichlet(alphas)
        valid_comp = range_controller.get_valid_composition(random_comp)
        real_data.append(valid_comp)
    
    real_data_array = np.array(real_data)
    print(f"Real data ready, {len(real_data_array)} samples")
    print(f"Data shape: {real_data_array.shape}")
    
    # Display real data statistics
    print(f"\nReal data composition statistics:")
    for i, monomer in enumerate(['HBA', 'HNA', 'TA', 'HQ']):
        print(f"  {monomer}: mean={real_data_array[:, i].mean():.3f}, "
              f"std={real_data_array[:, i].std():.3f}, "
              f"range=[{real_data_array[:, i].min():.3f}, {real_data_array[:, i].max():.3f}]")
    
    # 3. Train improved GAN
    print("\n3. Training improved GAN")
    print("-"*40)
    
    gan_config = GAN_CONFIG.copy()
    
    train_new = input("Train new improved GAN model? (y/n, default y): ") or "y"
    train_new = train_new.lower() in ['y', 'yes', '1']
    
    gan_trainer = ImprovedGANTrainer(gan_config, real_data_array, range_controller.ranges)
    
    if train_new:
        gan_trainer.train()
        save_models = input("Save trained GAN models? (y/n, default y): ") or "y"
        if save_models.lower() in ['y', 'yes', '1']:
            gan_trainer.save_models()
    else:
        try:
            gan_trainer.load_models()
            print("GAN models loaded successfully")
        except:
            print("Cannot load existing models, using randomly initialized model")
    
    # 4. Set generation parameters
    print("\n4. Setting generation parameters")
    print("-"*40)
    
    try:
        n_generate = int(input("How many compositions to generate? [default 10000]: ") or "10000")
        temperature = float(input("Generation temperature (0.5-2.0, default 1.0, higher = more diverse): ") or "1.0")
    except:
        n_generate = 10000
        temperature = 1.0
    
    print(f"Generation parameters:")
    print(f"  Generation count: {n_generate}")
    print(f"  Generation temperature: {temperature}")
    
    # 5. Generate samples using improved GAN
    print("\n5. Generating samples using improved GAN")
    print("-"*40)
    
    print(f"Generating {n_generate} samples...")
    
    generated_samples = []
    batch_size = 1000
    
    for i in range(0, n_generate, batch_size):
        current_batch = min(batch_size, n_generate - i)
        
        with torch.no_grad():
            noise = torch.randn(current_batch, gan_config['noise_dim']).to(gan_trainer.device)
            latent = torch.randn(current_batch, gan_config['latent_dim']).to(gan_trainer.device)
            z = torch.cat([latent, noise], dim=1)
            
            batch_samples = gan_trainer.generator(z).cpu().numpy()
        
        if temperature != 1.0:
            batch_samples = np.power(batch_samples, 1/temperature)
            batch_samples = batch_samples / batch_samples.sum(axis=1, keepdims=True)
        
        for sample in batch_samples:
            constrained = range_controller.get_valid_composition(sample)
            generated_samples.append(constrained)
        
        if (i + batch_size) % 5000 == 0 or (i + batch_size) >= n_generate:
            print(f"  Generated {min(i + batch_size, n_generate)}/{n_generate} samples")
    
    generated_samples_array = np.array(generated_samples)
    
    unique_samples = len(np.unique(generated_samples_array, axis=0))
    print(f"GAN generation completed, {len(generated_samples_array)} samples")
    print(f"Unique samples: {unique_samples} (diversity: {unique_samples/len(generated_samples_array)*100:.1f}%)")
    
    # 6. Initialize Tg predictor (using correct features)
    print("\n6. Initializing Tg predictor")
    print("-"*40)
    
    try:
        # Use feature names loaded from CSV
        tg_predictor = LargeScaleTgPredictor(MODEL_PATH, SCALER_PATH, CORRECT_FEATURES)
        print(f"Large-scale Tg predictor initialized successfully")
        print(f"  Using {len(CORRECT_FEATURES)} features: {CORRECT_FEATURES[:5]}...")
    except Exception as e:
        print(f"Failed to initialize Tg predictor: {e}")
        print("Program exiting")
        return
    
    # 7. Batch predict Tg values
    print("\n7. Batch predicting Tg values")
    print("-"*40)
    
    generated_tg_predictions = tg_predictor.predict_tg_batch(
        generated_samples_array, 
        range_controller.monomer_smiles_dict,
        batch_size=5000
    )
    
    # 8. Create Excel file
    print("\n8. Creating Excel file")
    print("-"*40)
    
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    output_dir = f"GAN_Results_{timestamp}"
    os.makedirs(output_dir, exist_ok=True)
    
    # Create DataFrame of all generated samples
    all_data = []
    n_display_samples = min(10000, len(generated_samples_array))
    
    for i in range(n_display_samples):
        sample_data = {
            'Sample_ID': f"Sample_{i+1:06d}",
            'HBA_Ratio': generated_samples_array[i][0],
            'HNA_Ratio': generated_samples_array[i][1],
            'TA_Ratio': generated_samples_array[i][2],
            'HQ_Ratio': generated_samples_array[i][3],
            'Sum': np.sum(generated_samples_array[i]),
            'Predicted_Tg_C': generated_tg_predictions[i] if i < len(generated_tg_predictions) else 0,
        }
        all_data.append(sample_data)
    
    all_df = pd.DataFrame(all_data)
    
    # Save to Excel
    excel_file = os.path.join(output_dir, f"All_Generated_Samples_{timestamp}.xlsx")
    
    with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
        # Sheet 1: All generated samples
        all_df.to_excel(writer, sheet_name='All_Generated_Samples', index=False)
        
        # Sheet 2: Summary statistics
        summary_data = {
            'Statistic': [
                'GAN Generated Samples Total',
                'Valid Prediction Samples',
                'Generation Temperature',
                'Sample Diversity (%)',
                'Average Predicted Tg',
                'Predicted Tg Std Dev',
                'Number of Features Used',
            ],
            'Value': [
                len(generated_samples_array),
                len(generated_tg_predictions),
                temperature,
                f"{unique_samples/len(generated_samples_array)*100:.1f}",
                f"{generated_tg_predictions.mean():.1f}°C" if len(generated_tg_predictions) > 0 else 'N/A',
                f"{generated_tg_predictions.std():.1f}°C" if len(generated_tg_predictions) > 0 else 'N/A',
                len(CORRECT_FEATURES),
            ]
        }
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(writer, sheet_name='Summary_Statistics', index=False)
        
        # Sheet 3: Feature information
        feature_df = pd.DataFrame({
            'Feature_Index': list(range(len(CORRECT_FEATURES))),
            'Feature_Name': CORRECT_FEATURES,
        })
        feature_df.to_excel(writer, sheet_name='Feature_Info', index=False)
    
    print(f"All results saved to: {excel_file}")
    
    # 9. Visualize results
    print("\n9. Visualizing results")
    print("-"*40)
    
    try:
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        fig.suptitle('GAN Generation Results', fontsize=16)
        
        # Tg distribution
        if len(generated_tg_predictions) > 0:
            axes[0, 0].hist(generated_tg_predictions, bins=50, alpha=0.7, 
                           color='skyblue', edgecolor='black')
            axes[0, 0].set_xlabel('Predicted Tg (°C)')
            axes[0, 0].set_ylabel('Frequency')
            axes[0, 0].set_title('Tg Distribution of GAN Generated Samples')
            axes[0, 0].grid(True, alpha=0.3)
        
        # Composition distribution
        labels = ['HBA', 'HNA', 'TA', 'HQ']
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
        for i in range(4):
            axes[0, 1].hist(generated_samples_array[:10000, i], bins=30, alpha=0.5, 
                           label=labels[i], color=colors[i])
        axes[0, 1].set_xlabel('Monomer Ratio')
        axes[0, 1].set_ylabel('Frequency')
        axes[0, 1].set_title('Monomer Ratio Distribution')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
        
        # Tg vs HBA ratio
        if len(generated_tg_predictions) > 0:
            scatter = axes[1, 0].scatter(generated_samples_array[:5000, 0], 
                                        generated_tg_predictions[:5000], 
                                        c=generated_samples_array[:5000, 1], 
                                        cmap='viridis', alpha=0.5, s=10)
            axes[1, 0].set_xlabel('HBA Ratio')
            axes[1, 0].set_ylabel('Predicted Tg (°C)')
            axes[1, 0].set_title('Tg vs HBA Ratio (color: HNA Ratio)')
            plt.colorbar(scatter, ax=axes[1, 0])
            axes[1, 0].grid(True, alpha=0.3)
        
        # Diversity trend
        if gan_trainer.history['diversity_scores']:
            axes[1, 1].plot(gan_trainer.history['diversity_scores'])
            axes[1, 1].set_xlabel('Epoch')
            axes[1, 1].set_ylabel('Diversity Score')
            axes[1, 1].set_title('Sample Diversity During Training')
            axes[1, 1].grid(True, alpha=0.3)
        
        # Composition correlation heatmap
        axes[0, 2].axis('off')
        axes[1, 2].axis('off')
        
        plt.tight_layout()
        chart_file = os.path.join(output_dir, f"GAN_Results_Visualization_{timestamp}.png")
        plt.savefig(chart_file, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"Visualization chart saved: {chart_file}")
        
    except Exception as e:
        print(f"Error generating charts: {e}")
    
    # 10. Program summary
    elapsed_time = time.time() - start_time
    print(f"\n10. Program Execution Summary")
    print("-"*40)
    print(f"GAN generated samples total: {len(generated_samples_array):,}")
    print(f"Valid prediction samples: {len(generated_tg_predictions):,}")
    print(f"Sample diversity: {unique_samples/len(generated_samples_array)*100:.1f}%")
    if len(generated_tg_predictions) > 0:
        print(f"Average predicted Tg: {generated_tg_predictions.mean():.1f}°C")
        print(f"Predicted Tg std dev: {generated_tg_predictions.std():.1f}°C")
    print(f"Features used: {len(CORRECT_FEATURES)}")
    print(f"Total execution time: {elapsed_time:.1f} seconds")
    print(f"Output directory: {output_dir}")


if __name__ == "__main__":
    print("Improved GAN Tetramer Composition Generation System")
    print(f"Start time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    try:
        main()
    except KeyboardInterrupt:
        print("\nProgram interrupted by user")
    except Exception as e:
        print(f"\nProgram error: {e}")
        import traceback
        traceback.print_exc()
    
    print("\nThank you for using! Press Enter to exit...")
    input()