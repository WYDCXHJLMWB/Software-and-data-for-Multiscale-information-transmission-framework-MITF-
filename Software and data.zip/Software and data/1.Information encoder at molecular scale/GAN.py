# -*- coding: utf-8 -*-
"""
Improved GAN-based tetrapolymer composition generation system.
Adapted for the model directory structure saved by the new nested_cv_group.py:
    NestedCV_xxx/FinalModels_xxx/
        ├── LightGBM_model.pkl  (one of the 7 models)
        ├── scaler.pkl
        ├── feature_info.pkl
        └── Final_Selected_Features.csv
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import joblib
import warnings
warnings.filterwarnings('ignore')
import os
import sys
import time
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import gc
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from sklearn.metrics.pairwise import cosine_similarity
from scipy.spatial.distance import cdist

# ==================== Configuration ====================
# Model directory saved by the new nested_cv_group.py
MODEL_DIR = r"Your model results file path"

# Use the LightGBM model (best performer in nested CV)
MODEL_PATH   = os.path.join(MODEL_DIR, "LightGBM_model.pkl")
SCALER_PATH  = os.path.join(MODEL_DIR, "scaler.pkl")
FEATURE_CSV_PATH  = os.path.join(MODEL_DIR, "Final_Selected_Features.csv")
FEATURE_INFO_PATH = os.path.join(MODEL_DIR, "feature_info.pkl")

TRAINING_DATA_FILE = "TLCP1.xlsx"
SELECTED_MOLECULES_FILE = "Selected_Molecules.xlsx"

# Validate file existence
for p in (MODEL_PATH, SCALER_PATH, FEATURE_INFO_PATH):
    if not os.path.exists(p):
        print(f"[WARN] File not found: {p}")
print(f"Using model: {MODEL_PATH}")


# ==================== Load feature names from Final_Selected_Features.csv ====================
def load_feature_names_from_csv(csv_path, feature_info_path=None):
    """Load feature names from Final_Selected_Features.csv / feature_info.pkl."""
    # Prefer feature_info.pkl (new structure) - most reliable
    if feature_info_path and os.path.exists(feature_info_path):
        try:
            import pickle
            with open(feature_info_path, 'rb') as f:
                info = pickle.load(f)
            names = info.get('final_feature_names', None)
            if names:
                print(f"Loaded {len(names)} feature names from feature_info.pkl")
                return names
        except Exception as e:
            print(f"Error reading feature_info.pkl: {e}")

    # Fall back to CSV
    if os.path.exists(csv_path):
        try:
            df = pd.read_csv(csv_path)
            for col in df.columns:
                if 'feature_name' in col.lower() or 'name' in col.lower():
                    names = df[col].tolist()
                    print(f"Loaded {len(names)} feature names from CSV")
                    return names
        except Exception as e:
            print(f"Error loading feature CSV: {e}")
    return None


FEATURE_NAMES = load_feature_names_from_csv(FEATURE_CSV_PATH, FEATURE_INFO_PATH)
if FEATURE_NAMES is None:
    FEATURE_NAMES = [
        'Mean_TPSA', 'Mean_HBondDonors', 'Mean_AromaticRatio',
        'Mean_RigidityIndex', 'Mean_PolarityIndex'
    ]
    print(f"Using default {len(FEATURE_NAMES)} feature names")

CORRECT_FEATURES = FEATURE_NAMES

# Feature index lookup in the 48-dim polymer feature vector.
# Maps every possible feature name variant (English or legacy Chinese alias)
# to its fixed position in the polymer feature vector.
FEATURE_INDEX_MAP = {
    # --- Weighted mean features (indices 0-14) ---
    'Mean_MolecularWeight': 0, 'Mean_RotatableBonds': 1,
    'Mean_HeavyAtoms': 2, 'Mean_HeavyAtomCount': 2,
    'Mean_TPSA': 3, 'Mean_LogP': 4, 'Mean_HBondDonors': 5,
    'Mean_HDonors': 5, 'Mean_HBondAcceptors': 6, 'Mean_HAcceptors': 6,
    'Mean_AromaticRatio': 7, 'Mean_RingCount': 8,
    'Mean_RigidityIndex': 9, 'Mean_PolarityIndex': 10,
    'Mean_TopologicalIndex': 11, 'Mean_MolarRefractivity': 12,
    'Mean_ShapeIndex': 13, 'Mean_FlexibilityIndex': 14,
    # Legacy Chinese aliases (kept for backward compatibility with older artifacts)
    '平均_分子量': 0, '平均_可旋转键': 1, '平均_重原子数': 2,
    '平均_TPSA': 3, '平均_LogP': 4, '平均_氢键供体': 5,
    '平均_氢键受体': 6, '平均_芳香比例': 7, '平均_环数': 8,
    '平均_刚性指数': 9, '平均_极性指数': 10, '平均_拓扑指数': 11,
    '平均_摩尔折射度': 12, '平均_形状指数': 13, '平均_柔韧性指数': 14,
    # --- Weighted std features (indices 15-24) ---
    'Std_MolecularWeight': 15, 'Std_TPSA': 18,
    'Std_HBondDonors': 20, 'Std_HBondAcceptors': 21,
    'Std_AromaticRatio': 22,
    '标准差_分子量': 15, '标准差_TPSA': 18, '标准差_氢键供体': 20,
    '标准差_氢键受体': 21, '标准差_芳香比例': 22,
    # --- Interaction features (indices 40-44) ---
    'MW_x_Rigidity': 40, 'MW_x_Aromaticity': 41,
    'Rigidity_x_Aromaticity': 42,
    'Polarity_Flexibility': 43, 'MW_Flexibility': 44,
    '分子量×刚性': 40, '分子量×芳香性': 41, '刚性×芳香性': 42,
    '极性/柔性': 43, '分子量/柔性': 44,
    # --- Aggregate features (indices 45-47) ---
    'TotalMolecularWeight': 46, 'TotalMW': 46,
    'TotalAromaticity': 47, 'MonomerCount': 45,
    '总分子量': 46, '总芳香性': 47, '单体数量': 45,
}


# ==================== GAN configuration ====================
GAN_CONFIG = {
    'latent_dim': 100,
    'noise_dim': 50,
    'generator_hidden': 256,
    'discriminator_hidden': 256,
    'batch_size': 128,
    'epochs': 300,
    'learning_rate': 0.0001,
    'beta1': 0.5,
    'beta2': 0.999,
    'sample_interval': 20,
    'use_cuda': torch.cuda.is_available(),
    'gradient_penalty_weight': 10,
    'n_critic': 5,
    'dropout_rate': 0.2,
}

# ==================== Hard-coded monomer ranges ====================
HARD_CODED_RANGES = {
    'monomer_order': ['HBA', 'HNA', 'TA', 'HQ'],
    'ranges': {
        'HBA': {'min': 0.35, 'max': 0.58, 'mean': 0.45},
        'HNA': {'min': 0.12, 'max': 0.28, 'mean': 0.20},
        'TA':  {'min': 0.12, 'max': 0.22, 'mean': 0.17},
        'HQ':  {'min': 0.12, 'max': 0.22, 'mean': 0.17},
    },
    'monomer_info': {
        'HBA': {'name': 'Parahydroxybenzoic acid',
                'smiles': 'OC1=CC=C(C(O)=O)C=C1'},
        'HNA': {'name': '2-Hydroxy-6-naphthalic acid',
                'smiles': 'O=C(O)C1=CC2=CC=C(O)C=C2C=C1'},
        'TA':  {'name': 'Terephthalic acid',
                'smiles': 'O=C(O)C1=CC=C(C(O)=O)C=C1'},
        'HQ':  {'name': 'Hydroquinone',
                'smiles': 'OC1=CC=C(O)C=C1'},
    },
}


# ==================== Selected molecules loader ====================
class SelectedMoleculesLoader:
    def __init__(self, file_path=SELECTED_MOLECULES_FILE):
        self.file_path = file_path
        self.df = None
        self.compositions = []
        self.smiles_list = []
        self.sample_names = []

    def load(self):
        print(f"\n{'='*60}\nLoading selected molecules file: {self.file_path}\n{'='*60}")
        if not os.path.exists(self.file_path):
            print(f"Warning: file {self.file_path} does not exist!")
            return False
        try:
            self.df = pd.read_excel(self.file_path)
            print(f"Successfully loaded {len(self.df)} samples")
            print(f"Data columns: {list(self.df.columns)}")
            for idx, row in self.df.iterrows():
                smiles = []
                for i in range(1, 5):
                    col = f'monomer{i}_smiles'
                    if col in self.df.columns and pd.notna(row[col]):
                        smiles.append(str(row[col]).strip())
                ratios = []
                for i in range(1, 5):
                    col = f'ratio{i}'
                    if col in self.df.columns and pd.notna(row[col]):
                        try:
                            ratios.append(float(row[col]))
                        except Exception:
                            ratios.append(0.0)
                if sum(ratios) > 0:
                    ratios = np.array(ratios) / sum(ratios)
                else:
                    ratios = np.ones(4) / 4
                self.compositions.append(ratios)
                self.smiles_list.append(smiles)
                sample_name = f"Sample{idx+1}"
                if 'No' in self.df.columns:
                    sample_name = f"Sample{row['No']}"
                self.sample_names.append(sample_name)
            print(f"\nExtracted compositions:")
            for i, (name, comp) in enumerate(zip(self.sample_names, self.compositions)):
                print(f"  {name}: HBA={comp[0]:.4f}, HNA={comp[1]:.4f}, "
                      f"TA={comp[2]:.4f}, HQ={comp[3]:.4f}")
            return True
        except Exception as e:
            print(f"Error loading file: {e}")
            return False

    def get_compositions(self):
        return self.compositions

    def get_composition_dataframe(self):
        data = []
        for i, (name, comp) in enumerate(zip(self.sample_names, self.compositions)):
            data.append({'SampleName': name, 'HBA': comp[0], 'HNA': comp[1],
                         'TA': comp[2], 'HQ': comp[3], 'Sum': sum(comp)})
        return pd.DataFrame(data)


# ==================== Feature extractor ====================
class CorrectFeatureExtractor:
    """Fully consistent with training: weighted mean / std / max / min / range / interactions / aggregates."""

    def __init__(self, feature_names):
        self.feature_names = feature_names
        self.feature_indices = FEATURE_INDEX_MAP
        self.monomer_features_cache = {}
        print(f"Feature extractor initialized, feature count: {len(self.feature_names)}")

    def _extract_monomer_features(self, smiles):
        if smiles in self.monomer_features_cache:
            return self.monomer_features_cache[smiles]
        try:
            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                return None
            f = []
            f.append(Descriptors.MolWt(mol))                                   # 0
            rot = Descriptors.NumRotatableBonds(mol)
            f.append(rot)                                                      # 1
            ha = mol.GetNumHeavyAtoms()
            f.append(ha)                                                       # 2
            tpsa = Descriptors.TPSA(mol)
            f.append(tpsa)                                                     # 3
            f.append(Crippen.MolLogP(mol))                                     # 4
            f.append(Descriptors.NumHDonors(mol))                              # 5
            f.append(Descriptors.NumHAcceptors(mol))                           # 6
            arom = sum(1 for a in mol.GetAtoms() if a.GetIsAromatic())
            f.append(arom / max(ha, 1))                                        # 7
            f.append(Descriptors.RingCount(mol))                               # 8
            f.append((ha - rot) / max(ha, 1))                                  # 9
            f.append(tpsa / max(Descriptors.MolWt(mol), 1))                    # 10
            f.append(Descriptors.Chi0(mol))                                    # 11
            f.append(Crippen.MolMR(mol))                                       # 12
            f.append((ha ** (1/3)) / max(rot + 1, 1))                          # 13
            f.append(rot / max(ha, 1))                                         # 14
            arr = np.array(f)
            self.monomer_features_cache[smiles] = arr
            return arr
        except Exception:
            return None

    def _calculate_polymer_features(self, mf, ratios):
        pf = []
        n_mono = mf.shape[0]
        # 1) 15 weighted means
        for i in range(mf.shape[1]):
            pf.append(float(np.sum(mf[:, i] * ratios)))
        # 2) 10 weighted stds
        if n_mono > 1:
            for i in range(min(10, mf.shape[1])):
                mu = np.sum(mf[:, i] * ratios)
                var = np.sum(ratios * (mf[:, i] - mu) ** 2)
                pf.append(float(np.sqrt(var)))
        else:
            pf.extend([0.0] * 10)
        # 3) 5 max
        for i in range(min(5, mf.shape[1])):
            pf.append(float(np.max(mf[:, i])))
        # 4) 5 min
        for i in range(min(5, mf.shape[1])):
            pf.append(float(np.min(mf[:, i])))
        # 5) 5 range
        for i in range(min(5, mf.shape[1])):
            pf.append(float(np.max(mf[:, i]) - np.min(mf[:, i])))
        # 6) 5 interactions
        mw_m   = float(np.sum(mf[:, 0] * ratios))
        rot_m  = float(np.sum(mf[:, 1] * ratios))
        tpsa_m = float(np.sum(mf[:, 3] * ratios))
        arom_m = float(np.sum(mf[:, 7] * ratios))
        rig_m  = float(np.sum(mf[:, 9] * ratios))
        pf.append(mw_m * rig_m)
        pf.append(mw_m * arom_m)
        pf.append(rig_m * arom_m)
        pf.append(tpsa_m / max(rot_m, 0.1))
        pf.append(mw_m / max(rot_m, 0.1))
        # 7) 3 aggregates
        pf.append(float(n_mono))
        pf.append(float(np.sum(mf[:, 0])))
        pf.append(float(np.sum(mf[:, 7])))
        return np.array(pf)

    def extract_features(self, monomer_composition, monomer_smiles_dict):
        smiles_list, ratios = [], []
        for monomer, ratio in zip(['HBA', 'HNA', 'TA', 'HQ'], monomer_composition):
            if ratio > 0.001 and monomer in monomer_smiles_dict:
                smiles_list.append(monomer_smiles_dict[monomer])
                ratios.append(ratio)
        if not smiles_list:
            return None
        ratios = np.array(ratios)
        ratios = ratios / ratios.sum() if ratios.sum() > 0 else np.ones(len(smiles_list)) / len(smiles_list)

        mono_feats = [self._extract_monomer_features(s) for s in smiles_list]
        mono_feats = [f for f in mono_feats if f is not None]
        if not mono_feats:
            return None
        mf = np.array(mono_feats)
        polymer_features = self._calculate_polymer_features(mf, ratios)

        selected = []
        for fname in self.feature_names:
            idx = self.feature_indices.get(fname, -1)
            if 0 <= idx < len(polymer_features):
                selected.append(polymer_features[idx])
            else:
                selected.append(0.0)
        return np.array(selected)


# ==================== GAN models ====================
class ImprovedGenerator(nn.Module):
    def __init__(self, latent_dim, noise_dim, output_dim=4, hidden_dim=256, dropout_rate=0.2):
        super().__init__()
        input_dim = latent_dim + noise_dim
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.BatchNorm1d(hidden_dim),
            nn.LeakyReLU(0.2, inplace=True), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim * 2), nn.BatchNorm1d(hidden_dim * 2),
            nn.LeakyReLU(0.2, inplace=True), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim * 2, hidden_dim), nn.BatchNorm1d(hidden_dim),
            nn.LeakyReLU(0.2, inplace=True), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim // 2), nn.BatchNorm1d(hidden_dim // 2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(hidden_dim // 2, output_dim), nn.Softmax(dim=1),
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1); nn.init.constant_(m.bias, 0)

    def forward(self, z):
        return self.model(z)


class ImprovedDiscriminator(nn.Module):
    def __init__(self, input_dim=4, hidden_dim=256, dropout_rate=0.2):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim * 2), nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim * 2, hidden_dim), nn.LeakyReLU(0.2, inplace=True),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim // 2), nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(hidden_dim // 2, 1),
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def forward(self, x):
        return self.model(x)


class ImprovedGANTrainer:
    def __init__(self, config, real_data, monomer_ranges):
        self.config = config
        self.real_data = real_data
        self.monomer_ranges = monomer_ranges
        self.device = torch.device("cuda" if config['use_cuda'] else "cpu")
        print(f"Initializing GAN trainer, device: {self.device}")

        self.generator = ImprovedGenerator(
            config['latent_dim'], config['noise_dim'], 4,
            config['generator_hidden'], config['dropout_rate']).to(self.device)
        self.discriminator = ImprovedDiscriminator(
            4, config['discriminator_hidden'], config['dropout_rate']).to(self.device)

        self.optimizer_G = optim.AdamW(self.generator.parameters(),
                                       lr=config['learning_rate'],
                                       betas=(config['beta1'], config['beta2']),
                                       weight_decay=1e-4)
        self.optimizer_D = optim.AdamW(self.discriminator.parameters(),
                                       lr=config['learning_rate'],
                                       betas=(config['beta1'], config['beta2']),
                                       weight_decay=1e-4)
        self.scheduler_G = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer_G, T_max=config['epochs'], eta_min=1e-6)
        self.scheduler_D = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer_D, T_max=config['epochs'], eta_min=1e-6)

        self._create_dataloader()
        self.history = {'d_losses': [], 'g_losses': [], 'w_distances': [],
                        'gp_values': [], 'diversity_scores': []}

    def _create_dataloader(self):
        ds = TensorDataset(torch.FloatTensor(self.real_data))
        self.dataloader = DataLoader(ds, batch_size=self.config['batch_size'],
                                     shuffle=True, num_workers=0,
                                     drop_last=True,
                                     pin_memory=self.config['use_cuda'])

    def _compute_gradient_penalty(self, real_samples, fake_samples):
        alpha = torch.rand(real_samples.size(0), 1).to(self.device)
        interp = (alpha * real_samples + (1 - alpha) * fake_samples).requires_grad_(True)
        d_interp = self.discriminator(interp)
        grads = torch.autograd.grad(outputs=d_interp, inputs=interp,
                                    grad_outputs=torch.ones_like(d_interp).to(self.device),
                                    create_graph=True, retain_graph=True, only_inputs=True)[0]
        return ((grads.norm(2, dim=1) - 1) ** 2).mean()

    def _calculate_diversity_score(self, samples):
        if len(samples) < 2:
            return 0.0
        from sklearn.metrics.pairwise import pairwise_distances
        d = pairwise_distances(samples, metric='euclidean')
        np.fill_diagonal(d, 0)
        return float(np.mean(d[d > 0]))

    def train_epoch(self, epoch):
        d_losses, g_losses, w_distances, gp_values = [], [], [], []
        all_fake = []
        for _, (real_batch,) in enumerate(self.dataloader):
            real_batch = real_batch.to(self.device)
            bs = real_batch.size(0)

            for _ in range(self.config['n_critic']):
                self.optimizer_D.zero_grad()
                noise = torch.randn(bs, self.config['noise_dim']).to(self.device)
                latent = torch.randn(bs, self.config['latent_dim']).to(self.device)
                z = torch.cat([latent, noise], dim=1)
                fake = self.generator(z).detach()
                real_v = self.discriminator(real_batch)
                fake_v = self.discriminator(fake)
                w = real_v.mean() - fake_v.mean()
                gp = self._compute_gradient_penalty(real_batch.data, fake.data)
                d_loss = -w + self.config['gradient_penalty_weight'] * gp
                d_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.discriminator.parameters(), 1.0)
                self.optimizer_D.step()
                d_losses.append(d_loss.item()); w_distances.append(w.item())
                gp_values.append(gp.item())

            self.optimizer_G.zero_grad()
            noise = torch.randn(bs, self.config['noise_dim']).to(self.device)
            latent = torch.randn(bs, self.config['latent_dim']).to(self.device)
            z = torch.cat([latent, noise], dim=1)
            fake = self.generator(z)
            all_fake.append(fake.cpu().detach().numpy())
            g_loss = -self.discriminator(fake).mean()
            g_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.generator.parameters(), 1.0)
            self.optimizer_G.step()
            g_losses.append(g_loss.item())

        if all_fake:
            self.history['diversity_scores'].append(
                self._calculate_diversity_score(np.vstack(all_fake)))
        self.history['d_losses'].append(np.mean(d_losses))
        self.history['g_losses'].append(np.mean(g_losses))
        self.history['w_distances'].append(np.mean(w_distances))
        self.history['gp_values'].append(np.mean(gp_values))
        return (np.mean(d_losses), np.mean(g_losses),
                np.mean(w_distances), np.mean(gp_values))

    def train(self):
        print(f"\nStarting GAN training for {self.config['epochs']} epochs...")
        start = time.time()
        best_div = 0
        for epoch in range(self.config['epochs']):
            d_loss, g_loss, w, gp = self.train_epoch(epoch)
            self.scheduler_G.step(); self.scheduler_D.step()
            if (epoch + 1) % self.config['sample_interval'] == 0:
                lr = self.optimizer_G.param_groups[0]['lr']
                div = self.history['diversity_scores'][-1]
                print(f"Epoch {epoch+1:3d}/{self.config['epochs']} | "
                      f"D_loss: {d_loss:.4f} | G_loss: {g_loss:.4f} | "
                      f"W: {w:.4f} | GP: {gp:.4f} | Div: {div:.4f} | LR: {lr:.2e}")
                if div > best_div:
                    best_div = div
                    self.save_models(path='gan_models/best')
        print(f"\nGAN training complete, took {time.time()-start:.1f}s")
        self.plot_training_history()

    def generate_samples(self, n_samples, temperature=1.0):
        self.generator.eval()
        with torch.no_grad():
            noise = torch.randn(n_samples, self.config['noise_dim']).to(self.device)
            latent = torch.randn(n_samples, self.config['latent_dim']).to(self.device)
            z = torch.cat([latent, noise], dim=1)
            gen = self.generator(z).cpu().numpy()
            if temperature != 1.0:
                gen = np.power(gen, 1 / temperature)
                gen = gen / gen.sum(axis=1, keepdims=True)
            gen = np.array([self._apply_monomer_constraints(s) for s in gen])
        self.generator.train()
        return gen

    def _apply_monomer_constraints(self, comp):
        c = np.copy(comp)
        for i, m in enumerate(['HBA', 'HNA', 'TA', 'HQ']):
            c[i] = np.clip(c[i], self.monomer_ranges[m]['min'] * 0.9,
                           self.monomer_ranges[m]['max'] * 1.1)
        c = np.maximum(c, 0.001)
        return c / c.sum()

    def plot_training_history(self):
        fig, axes = plt.subplots(2, 3, figsize=(15, 8))
        axes[0, 0].plot(self.history['d_losses']); axes[0, 0].set_title('D loss')
        axes[0, 1].plot(self.history['g_losses']); axes[0, 1].set_title('G loss')
        axes[0, 2].plot(self.history['w_distances']); axes[0, 2].set_title('W distance')
        axes[1, 0].plot(self.history['gp_values']); axes[1, 0].set_title('GP')
        if self.history['diversity_scores']:
            axes[1, 1].plot(self.history['diversity_scores'])
            axes[1, 1].set_title('Diversity')
        axes[1, 2].axis('off')
        for a in axes.flat:
            if a.axison:
                a.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig('improved_gan_training_history.png', dpi=150)
        plt.close()

    def save_models(self, path='gan_models'):
        os.makedirs(path, exist_ok=True)
        torch.save({'model_state_dict': self.generator.state_dict(),
                    'config': self.config, 'history': self.history},
                   os.path.join(path, 'generator.pth'))
        torch.save({'model_state_dict': self.discriminator.state_dict(),
                    'config': self.config},
                   os.path.join(path, 'discriminator.pth'))

    def load_models(self, path='gan_models'):
        g = torch.load(os.path.join(path, 'generator.pth'))
        self.generator.load_state_dict(g['model_state_dict'])
        d = torch.load(os.path.join(path, 'discriminator.pth'))
        self.discriminator.load_state_dict(d['model_state_dict'])
        print(f"Models loaded from {path}")


# ==================== Tg predictor ====================
class LargeScaleTgPredictor:
    def __init__(self, model_path, scaler_path, feature_names):
        print(f"Initializing Tg predictor...")
        print(f"  model: {model_path}")
        print(f"  scaler: {scaler_path}")
        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)
        self.feature_extractor = CorrectFeatureExtractor(feature_names)

        if hasattr(self.scaler, 'n_features_in_'):
            self.expected_features = self.scaler.n_features_in_
        elif hasattr(self.scaler, 'mean_'):
            self.expected_features = len(self.scaler.mean_)
        else:
            self.expected_features = len(feature_names)
        print(f"  scaler expected feature count: {self.expected_features}")
        print(f"✓ Model loaded")

    def predict_tg_batch(self, compositions, monomer_smiles_dict, batch_size=2000):
        n = len(compositions)
        print(f"Batch predicting Tg for {n} samples...")
        preds = []
        valid, invalid = 0, 0
        for i in range(0, n, batch_size):
            batch = compositions[i:i+batch_size]
            feats = []
            for comp in batch:
                f = self.feature_extractor.extract_features(comp, monomer_smiles_dict)
                if f is not None:
                    feats.append(f); valid += 1
                else:
                    invalid += 1
            if not feats:
                continue
            feats = np.array(feats)
            if feats.shape[1] != self.expected_features:
                if feats.shape[1] > self.expected_features:
                    feats = feats[:, :self.expected_features]
                else:
                    pad = np.zeros((feats.shape[0], self.expected_features - feats.shape[1]))
                    feats = np.hstack([feats, pad])
            try:
                preds.extend(self.model.predict(self.scaler.transform(feats)))
            except Exception as e:
                print(f"  Error in prediction batch {i//batch_size+1}: {e}")
            processed = min(i+batch_size, n)
            if processed % 5000 == 0 or processed >= n:
                print(f"  Progress: {processed}/{n} ({processed/n*100:.1f}%)")
        preds = np.array(preds)
        if len(preds):
            print(f"Prediction complete: valid {len(preds)}, invalid {invalid}")
            print(f"  Tg range: {preds.min():.1f} - {preds.max():.1f}°C, "
                  f"mean {preds.mean():.1f}±{preds.std():.1f}°C")
        return preds


# ==================== Monomer range controller ====================
class HardCodedRangeController:
    def __init__(self):
        self.monomer_order = HARD_CODED_RANGES['monomer_order']
        self.ranges = HARD_CODED_RANGES['ranges']
        self.monomer_info = HARD_CODED_RANGES['monomer_info']
        self.monomer_smiles_dict = {k: v['smiles'] for k, v in self.monomer_info.items()}
        self.display_ranges()

    def display_ranges(self):
        print("\nMonomer ratio ranges:")
        for m in self.monomer_order:
            r = self.ranges[m]
            print(f"  {m}: {r['min']:.2f}-{r['max']:.2f} (mean {r['mean']:.2f})")

    def get_valid_composition(self, comp):
        c = np.copy(comp)
        for i, m in enumerate(self.monomer_order):
            c[i] = np.clip(c[i], self.ranges[m]['min'] * 0.9,
                           self.ranges[m]['max'] * 1.1)
        c = np.maximum(c, 0.001)
        return c / c.sum()


# ==================== Similarity analyzer ====================
class MoleculeSimilarityAnalyzer:
    def __init__(self, target_compositions, target_names=None):
        self.target_compositions = np.array(target_compositions)
        self.target_names = (target_names if target_names is not None
                             else [f"Target{i+1}" for i in range(len(target_compositions))])
        print(f"\nSimilarity analyzer initialized, target sample count: {len(self.target_compositions)}")

    def calculate_similarities(self, gen, method='euclidean'):
        if method == 'cosine':
            return cosine_similarity(gen, self.target_compositions)
        if method == 'manhattan':
            d = cdist(gen, self.target_compositions, metric='cityblock')
        else:
            d = cdist(gen, self.target_compositions, metric='euclidean')
        return 1.0 / (1.0 + d)

    def find_similar_molecules(self, gen_comps, gen_tg, similarity_threshold=0.8,
                               top_n_per_target=50, method='euclidean'):
        sims = self.calculate_similarities(gen_comps, method)
        result = {f"Target_{name}": [] for name in self.target_names}
        for i, (tc, tn) in enumerate(zip(self.target_compositions, self.target_names)):
            col = sims[:, i]
            above = np.where(col >= similarity_threshold)[0]
            if len(above) > 0:
                order = above[np.argsort(-col[above])][:top_n_per_target]
            else:
                order = np.argsort(-col)[:top_n_per_target]
            for idx in order:
                result[f"Target_{tn}"].append({
                    'SampleID': f"GenSample_{idx+1:06d}",
                    'HBA_Ratio': gen_comps[idx][0],
                    'HNA_Ratio': gen_comps[idx][1],
                    'TA_Ratio': gen_comps[idx][2],
                    'HQ_Ratio': gen_comps[idx][3],
                    'Sum': float(np.sum(gen_comps[idx])),
                    'Predicted_Tg_C': float(gen_tg[idx]),
                    'Similarity': float(col[idx]),
                    'Target_HBA': tc[0], 'Target_HNA': tc[1],
                    'Target_TA': tc[2], 'Target_HQ': tc[3],
                })
        return result, sims


# ==================== Main program ====================
def main():
    print("=" * 80)
    print("Improved GAN-based tetrapolymer composition generation system (adapted to new LightGBM model directory)")
    print(f"MODEL_PATH = {MODEL_PATH}")
    print("=" * 80)
    start_time = time.time()

    # 1) Load selected molecules
    print("\n1. Loading selected molecules")
    loader = SelectedMoleculesLoader(SELECTED_MOLECULES_FILE)
    if loader.load():
        target_compositions = loader.get_compositions()
        target_names = loader.sample_names
    else:
        print("Using default reference samples")
        target_compositions = [[0.40, 0.18, 0.24, 0.18],
                               [0.45, 0.16, 0.23, 0.16],
                               [0.54, 0.15, 0.15, 0.15]]
        target_names = ["Ref1", "Ref2", "Ref3"]

    # 2) Monomer ranges
    print("\n2. Initializing monomer ranges")
    range_ctrl = HardCodedRangeController()

    # 3) Real data
    print("\n3. Preparing real data")
    alphas_list = [
        [5.0, 1.5, 2.0, 1.5], [4.5, 2.5, 1.5, 1.5],
        [4.0, 2.0, 2.5, 1.5], [4.5, 1.5, 1.5, 2.5],
        [3.5, 3.0, 2.0, 1.5], [5.5, 1.5, 1.5, 1.5],
        [4.0, 2.5, 2.0, 1.5], [4.0, 2.0, 2.0, 2.0],
        [3.5, 2.5, 2.5, 1.5], [4.0, 2.0, 1.5, 2.5],
    ]
    real = []
    for _ in range(2000):
        a = np.array(alphas_list[np.random.randint(len(alphas_list))]) * (1 + 0.2 * np.random.randn(4))
        a = np.maximum(a, 1.0)
        real.append(range_ctrl.get_valid_composition(np.random.dirichlet(a)))
    real_arr = np.array(real)
    print(f"Real sample count: {len(real_arr)}")

    # 4) Train GAN
    print("\n4. Training GAN")
    trainer = ImprovedGANTrainer(GAN_CONFIG, real_arr, range_ctrl.ranges)
    train_new = (input("Train a new GAN? (y/n, default y): ") or "y").lower() in ('y', 'yes', '1')
    if train_new:
        trainer.train()
        if (input("Save GAN? (y/n, default y): ") or "y").lower() in ('y', 'yes', '1'):
            trainer.save_models()
    else:
        try:
            trainer.load_models()
        except Exception as e:
            print(f"Loading failed, using random initialization: {e}")

    # 5) Generation parameters
    print("\n5. Generation parameters")
    try:
        n_gen = int(input("Generation count [10000]: ") or "10000")
        sim_thr = float(input("Similarity threshold [0.85]: ") or "0.85")
        top_n = int(input("Keep per target [50]: ") or "50")
        temp = float(input("Generation temperature [1.0]: ") or "1.0")
        sim_method = input("Similarity method [euclidean/cosine/manhattan] (euclidean): ") or "euclidean"
    except Exception:
        n_gen, sim_thr, top_n, temp, sim_method = 10000, 0.85, 50, 1.0, "euclidean"
    print(f"  Generate {n_gen}, threshold {sim_thr}, top_n {top_n}, T={temp}, method={sim_method}")

    # 6) GAN generation
    print("\n6. Generating samples")
    gen = []
    batch = 1000
    for i in range(0, n_gen, batch):
        cur = min(batch, n_gen - i)
        with torch.no_grad():
            noise = torch.randn(cur, GAN_CONFIG['noise_dim']).to(trainer.device)
            latent = torch.randn(cur, GAN_CONFIG['latent_dim']).to(trainer.device)
            z = torch.cat([latent, noise], dim=1)
            b = trainer.generator(z).cpu().numpy()
        if temp != 1.0:
            b = np.power(b, 1 / temp)
            b = b / b.sum(axis=1, keepdims=True)
        for s in b:
            gen.append(range_ctrl.get_valid_composition(s))
    gen_arr = np.array(gen)
    uniq = len(np.unique(gen_arr, axis=0))
    print(f"Generation complete: {len(gen_arr)}, unique {uniq} ({uniq/len(gen_arr)*100:.1f}%)")

    # 7) Tg prediction
    print("\n7. Initializing Tg predictor")
    predictor = LargeScaleTgPredictor(MODEL_PATH, SCALER_PATH, CORRECT_FEATURES)
    print("\n8. Batch predicting Tg")
    tg_preds = predictor.predict_tg_batch(gen_arr, range_ctrl.monomer_smiles_dict, batch_size=5000)

    # 9) Similarity
    print("\n9. Finding similar molecules")
    analyzer = MoleculeSimilarityAnalyzer(target_compositions, target_names)
    similar, sims = analyzer.find_similar_molecules(gen_arr, tg_preds,
                                                    similarity_threshold=sim_thr,
                                                    top_n_per_target=top_n,
                                                    method=sim_method)
    total_sim = sum(len(v) for v in similar.values())
    print(f"Total similar samples: {total_sim}")

    # 10) Excel
    print("\n10. Exporting Excel")
    ts = time.strftime("%Y%m%d_%H%M%S")
    out_dir = f"GAN_Results_{ts}"
    os.makedirs(out_dir, exist_ok=True)
    excel = os.path.join(out_dir, f"All_Generated_Samples_{ts}.xlsx")
    with pd.ExcelWriter(excel, engine='openpyxl') as writer:
        n_show = min(10000, len(gen_arr))
        all_rows = []
        for i in range(n_show):
            row = {'SampleID': f"Sample_{i+1:06d}",
                   'HBA_Ratio': gen_arr[i][0], 'HNA_Ratio': gen_arr[i][1],
                   'TA_Ratio': gen_arr[i][2], 'HQ_Ratio': gen_arr[i][3],
                   'Sum': float(np.sum(gen_arr[i])),
                   'Predicted_Tg_C': float(tg_preds[i]) if i < len(tg_preds) else 0.0}
            for j, tn in enumerate(target_names):
                row[f'Similarity_to_{tn}'] = float(sims[i, j])
            all_rows.append(row)
        pd.DataFrame(all_rows).to_excel(writer, sheet_name='All_Generated_Samples', index=False)

        pd.DataFrame({
            'Statistic': ['Total GAN generations', 'Valid predictions', 'Total similar samples',
                          'Threshold', 'Temperature', 'Diversity %', 'Mean Tg', 'Tg std',
                          'Similarity method', 'Feature count'] +
                         [f'Similar count to {n}' for n in target_names],
            'Value': [len(gen_arr), len(tg_preds), total_sim, sim_thr, temp,
                      f"{uniq/len(gen_arr)*100:.1f}",
                      f"{tg_preds.mean():.1f}" if len(tg_preds) else 'N/A',
                      f"{tg_preds.std():.1f}" if len(tg_preds) else 'N/A',
                      sim_method, len(CORRECT_FEATURES)] +
                     [len(v) for v in similar.values()],
        }).to_excel(writer, sheet_name='Summary_Statistics', index=False)

        pd.DataFrame([{
            'TargetName': n, 'HBA': c[0], 'HNA': c[1], 'TA': c[2], 'HQ': c[3], 'Sum': sum(c)
        } for n, c in zip(target_names, target_compositions)]).to_excel(
            writer, sheet_name='Target_Samples', index=False)

        pd.DataFrame({'FeatureIndex': list(range(len(CORRECT_FEATURES))),
                      'FeatureName': CORRECT_FEATURES}).to_excel(
            writer, sheet_name='Feature_Info', index=False)

        for k, v in similar.items():
            if v:
                df = pd.DataFrame(v).sort_values('Similarity', ascending=False)
                df.to_excel(writer, sheet_name=k[:31], index=False)
    print(f"✓ Results saved: {excel}")

    # 11) Visualization
    print("\n11. Visualization")
    try:
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        if len(tg_preds):
            axes[0, 0].hist(tg_preds, bins=50, alpha=0.7, color='skyblue', edgecolor='black')
            axes[0, 0].set_title('Tg distribution of GAN-generated samples')
            axes[0, 0].set_xlabel('Predicted Tg (C)'); axes[0, 0].set_ylabel('Frequency')
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
        for i in range(4):
            axes[0, 1].hist(gen_arr[:10000, i], bins=30, alpha=0.5,
                            label=['HBA', 'HNA', 'TA', 'HQ'][i], color=colors[i])
        axes[0, 1].set_title('Monomer ratio distributions'); axes[0, 1].legend()
        counts = [len(v) for v in similar.values()]
        bars = axes[0, 2].bar(range(len(counts)), counts,
                              color=plt.cm.Set3(np.linspace(0, 1, len(counts))))
        axes[0, 2].set_xticks(range(len(counts)))
        axes[0, 2].set_xticklabels([f'T{i+1}' for i in range(len(counts))])
        axes[0, 2].set_title('Similar sample count per target')
        for b, c in zip(bars, counts):
            axes[0, 2].text(b.get_x()+b.get_width()/2, b.get_height()+0.5,
                            str(c), ha='center', va='bottom')
        if len(tg_preds):
            sc = axes[1, 0].scatter(gen_arr[:5000, 0], tg_preds[:5000],
                                    c=gen_arr[:5000, 1], cmap='viridis', s=10, alpha=0.5)
            axes[1, 0].set_xlabel('HBA'); axes[1, 0].set_ylabel('Predicted Tg (C)')
            plt.colorbar(sc, ax=axes[1, 0])
        if trainer.history['diversity_scores']:
            axes[1, 1].plot(trainer.history['diversity_scores'])
            axes[1, 1].set_title('Diversity')
        if total_sim > 0:
            all_s = [s['Similarity'] for v in similar.values() for s in v]
            axes[1, 2].hist(all_s, bins=20, alpha=0.7, color='mediumpurple', edgecolor='black')
            axes[1, 2].set_title('Similarity distribution')
        for a in axes.flat:
            if a.axison:
                a.grid(True, alpha=0.3)
        plt.tight_layout()
        chart = os.path.join(out_dir, f"GAN_Results_{ts}.png")
        plt.savefig(chart, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"✓ Chart saved: {chart}")
    except Exception as e:
        print(f"Plotting error: {e}")

    print(f"\n12. Done, took {time.time()-start_time:.1f}s")
    print(f"Output directory: {out_dir}")


if __name__ == "__main__":
    print(f"Start time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    try:
        main()
    except KeyboardInterrupt:
        print("\nUser interrupted")
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
    print("\nPress Enter to exit...")
    input()