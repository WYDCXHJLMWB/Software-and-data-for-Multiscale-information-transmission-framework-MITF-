# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 21:17:53 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 16:24:31 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 15:20:47 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Polymer Tg Prediction Model - Group Split + Genetic Algorithm + Original Data Augmentation
Added cross-validation and test set prediction output
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GroupKFold, train_test_split, KFold, cross_val_score, GridSearchCV, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor
from sklearn.neighbors import NearestNeighbors
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')
import os
from datetime import datetime
import joblib
import random
import pickle
import json

# RDKit
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen

# Genetic algorithm library
from deap import base, creator, tools

# Set Chinese font
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


# ==================== Data Processor ====================

class GroupDataProcessor:
    """Data processor supporting group-based splitting"""
    
    def __init__(self, data_file="LCP-Tg0110.xlsx"):
        self.data_file = data_file
        self.df = None
        self.X = None
        self.y = None
        self.groups = None
        self.feature_names = []
        self.original_smiles = []
        
    def load_and_extract_features(self):
        """Load data and extract all features"""
        print(f"Loading data: {self.data_file}")
        self.df = pd.read_excel(self.data_file)
        
        # Identify columns
        tg_col = None
        monomer_cols = []
        id_col = None
        name_col = None
        
        for col in self.df.columns:
            col_lower = str(col).lower()
            if 'tg' in col_lower or 'glass' in col_lower:
                tg_col = col
            elif 'monomer' in col_lower or 'smiles' in col_lower:
                monomer_cols.append(col)
            elif 'id' in col_lower or 'number' in col_lower:
                id_col = col
            elif 'name' in col_lower or 'polymer' in col_lower:
                name_col = col
        
        if tg_col is None:
            tg_col = self.df.columns[0]
        
        print(f"Tg column: {tg_col}")
        print(f"Monomer columns: {monomer_cols}")
        
        # Clean data
        self.df = self.df.dropna(subset=[tg_col])
        self.df = self.df[pd.to_numeric(self.df[tg_col], errors='coerce').notna()]
        
        all_features = []
        all_tg = []
        all_groups = []
        all_smiles_info = []
        
        for idx, row in self.df.iterrows():
            try:
                tg = float(row[tg_col])
                
                # Extract monomer SMILES
                monomers = []
                for col in monomer_cols:
                    if pd.notna(row[col]):
                        smiles = str(row[col]).strip()
                        if smiles and smiles != 'nan':
                            monomers.append(smiles)
                
                if not monomers:
                    continue
                
                # Generate group labels
                if id_col and pd.notna(row[id_col]):
                    group = str(row[id_col])
                elif name_col and pd.notna(row[name_col]):
                    group = str(row[name_col])
                else:
                    sorted_smiles = sorted(monomers)
                    group = '|'.join(sorted_smiles)
                
                all_smiles_info.append({
                    'index': idx,
                    'smiles_list': monomers,
                    'tg_value': tg,
                    'group': group
                })
                
                # Extract features for each monomer
                mono_features_list = []
                for smiles in monomers:
                    feats = self._extract_monomer_features(smiles)
                    if feats is not None:
                        mono_features_list.append(feats)
                
                if not mono_features_list:
                    continue
                
                mono_features = np.array(mono_features_list)
                polymer_features = self._calculate_enhanced_polymer_features(mono_features, monomers)
                
                all_features.append(polymer_features)
                all_tg.append(tg)
                all_groups.append(group)
                
            except Exception as e:
                continue
        
        self.X = np.array(all_features)
        self.y = np.array(all_tg)
        self.groups = np.array(all_groups)
        self.original_smiles = all_smiles_info
        self._generate_enhanced_feature_names()
        
        print(f"\nOriginal data statistics:")
        print(f"  Total samples: {len(self.y)}")
        print(f"  Total features: {self.X.shape[1]}")
        print(f"  Number of groups: {len(np.unique(self.groups))}")
        print(f"  Tg range: {self.y.min():.1f} - {self.y.max():.1f} °C")
        print(f"  Tg mean: {self.y.mean():.1f} ± {self.y.std():.1f} °C")
        
        return self
    
    def _extract_monomer_features(self, smiles):
        """Extract 15 features from a monomer"""
        try:
            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                return None
            
            features = []
            features.append(Descriptors.MolWt(mol))
            features.append(Descriptors.NumRotatableBonds(mol))
            features.append(mol.GetNumHeavyAtoms())
            features.append(Descriptors.TPSA(mol))
            features.append(Crippen.MolLogP(mol))
            features.append(Descriptors.NumHDonors(mol))
            features.append(Descriptors.NumHAcceptors(mol))
            
            aromatic_atoms = sum(1 for atom in mol.GetAtoms() if atom.GetIsAromatic())
            heavy_atoms = mol.GetNumHeavyAtoms()
            features.append(aromatic_atoms / max(heavy_atoms, 1))
            
            features.append(Descriptors.RingCount(mol))
            
            rotatable = Descriptors.NumRotatableBonds(mol)
            features.append((heavy_atoms - rotatable) / max(heavy_atoms, 1))
            features.append(Descriptors.TPSA(mol) / max(Descriptors.MolWt(mol), 1))
            features.append(Descriptors.Chi0(mol))
            features.append(Crippen.MolMR(mol))
            features.append((heavy_atoms ** (1/3)) / max(rotatable + 1, 1))
            features.append(rotatable / max(heavy_atoms, 1))
            
            return np.array(features)
        except Exception as e:
            return None
    
    def _calculate_enhanced_polymer_features(self, mono_features, monomers):
        """Calculate enhanced polymer features"""
        polymer_features = []
        
        # Mean values (15)
        for i in range(mono_features.shape[1]):
            polymer_features.append(np.mean(mono_features[:, i]))
        
        # Standard deviations (10)
        if len(monomers) > 1:
            for i in range(min(10, mono_features.shape[1])):
                polymer_features.append(np.std(mono_features[:, i]))
        else:
            polymer_features.extend([0] * 10)
        
        # Maximum values (5)
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.max(mono_features[:, i]))
        
        # Minimum values (5)
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.min(mono_features[:, i]))
        
        # Range values (5)
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.max(mono_features[:, i]) - np.min(mono_features[:, i]))
        
        # Interaction features (5)
        mw_mean = np.mean(mono_features[:, 0])
        rigid_mean = np.mean(mono_features[:, 9])
        aromatic_mean = np.mean(mono_features[:, 7])
        tpsa_mean = np.mean(mono_features[:, 3])
        rotatable_mean = np.mean(mono_features[:, 1])
        
        polymer_features.append(mw_mean * rigid_mean)
        polymer_features.append(mw_mean * aromatic_mean)
        polymer_features.append(rigid_mean * aromatic_mean)
        polymer_features.append(tpsa_mean / max(rotatable_mean, 0.1))
        polymer_features.append(mw_mean / max(rotatable_mean, 0.1))
        
        # Aggregation features (3)
        polymer_features.append(len(monomers))
        polymer_features.append(np.sum(mono_features[:, 0]))
        polymer_features.append(np.sum(mono_features[:, 7]))
        
        return np.array(polymer_features)
    
    def _generate_enhanced_feature_names(self):
        """Generate enhanced feature names"""
        base_names = [
            'MolecularWeight', 'RotatableBonds', 'HeavyAtoms', 'TPSA', 'LogP',
            'HDonors', 'HAcceptors', 'AromaticRatio', 'RingCount',
            'RigidityIndex', 'PolarityIndex', 'TopologicalIndex', 'MolarRefractivity',
            'ShapeIndex', 'FlexibilityIndex'
        ]
        
        self.feature_names = []
        
        for name in base_names:
            self.feature_names.append(f"Mean_{name}")
        
        for i in range(10):
            self.feature_names.append(f"Std_{base_names[i]}")
        
        for i in range(5):
            self.feature_names.append(f"Max_{base_names[i]}")
        
        for i in range(5):
            self.feature_names.append(f"Min_{base_names[i]}")
        
        for i in range(5):
            self.feature_names.append(f"Range_{base_names[i]}")
        
        self.feature_names.extend([
            'MW_x_Rigidity', 'MW_x_Aromaticity', 'Rigidity_x_Aromaticity',
            'Polarity_Flexibility', 'MW_Flexibility'
        ])
        
        self.feature_names.extend(['MonomerCount', 'TotalMW', 'TotalAromaticity'])


# ==================== Data Augmentation ====================

class DataAugmentor:
    """Data augmentation"""
    
    def __init__(self, augment_factor=3.0, random_state=42):
        self.augment_factor = augment_factor
        self.random_state = random_state
        np.random.seed(random_state)
        random.seed(random_state)
        
    def add_gaussian_noise(self, X, noise_level=0.02):
        """Add small Gaussian noise"""
        X_std = np.std(X, axis=0)
        noise = np.random.normal(0, noise_level * X_std, X.shape)
        return X + noise
    
    def add_uniform_noise(self, X, noise_level=0.02):
        """Add uniform noise"""
        X_range = np.max(X, axis=0) - np.min(X, axis=0)
        noise = np.random.uniform(-noise_level * X_range, noise_level * X_range, X.shape)
        return X + noise
    
    def smote_like_augmentation(self, X, y, k=5, n_synthetic=None):
        """SMOTE-like data augmentation"""
        n_samples = len(X)
        if n_synthetic is None:
            n_synthetic = n_samples
        
        nn = NearestNeighbors(n_neighbors=min(k+1, n_samples), metric='euclidean')
        nn.fit(X)
        distances, indices = nn.kneighbors(X)
        
        X_aug = []
        y_aug = []
        
        for _ in range(n_synthetic):
            idx = np.random.randint(n_samples)
            neighbor_idx = np.random.choice(indices[idx, 1:])
            alpha = np.random.uniform(0.3, 0.7)
            
            X_new = alpha * X[idx] + (1 - alpha) * X[neighbor_idx]
            y_new = alpha * y[idx] + (1 - alpha) * y[neighbor_idx]
            
            X_aug.append(X_new)
            y_aug.append(y_new)
        
        return np.array(X_aug), np.array(y_aug)
    
    def augment_training_data(self, X_train, y_train):
        """Augment training data to specified multiplier"""
        original_size = len(X_train)
        target_size = int(original_size * self.augment_factor)
        n_synthetic = target_size - original_size
        
        print(f"\n{'='*50}")
        print("Data Augmentation")
        print(f"{'='*50}")
        print(f"Original training set: {original_size} samples")
        print(f"Target training set: {target_size} samples (augmentation factor: {self.augment_factor}x)")
        print(f"Need to generate: {n_synthetic} samples")
        
        if n_synthetic <= 0:
            return X_train, y_train
        
        n_noise1 = n_synthetic // 3
        n_noise2 = n_synthetic // 3
        n_smote = n_synthetic - n_noise1 - n_noise2
        
        X_aug_list = [X_train]
        y_aug_list = [y_train]
        
        if n_noise1 > 0:
            X_noise = self.add_gaussian_noise(X_train[:n_noise1], noise_level=0.02)
            X_aug_list.append(X_noise)
            y_aug_list.append(y_train[:n_noise1])
        
        if n_noise2 > 0:
            X_noise = self.add_uniform_noise(X_train[:n_noise2], noise_level=0.02)
            X_aug_list.append(X_noise)
            y_aug_list.append(y_train[:n_noise2])
        
        if n_smote > 0:
            X_syn, y_syn = self.smote_like_augmentation(X_train, y_train, k=5, n_synthetic=n_smote)
            X_aug_list.append(X_syn)
            y_aug_list.append(y_syn)
        
        X_augmented = np.vstack(X_aug_list)
        y_augmented = np.concatenate(y_aug_list)
        
        print(f"Augmented training set: {len(X_augmented)} samples")
        print(f"Tg range: {y_augmented.min():.1f} - {y_augmented.max():.1f}°C")
        print(f"Tg mean: {y_augmented.mean():.1f} ± {y_augmented.std():.1f}°C")
        
        return X_augmented, y_augmented


# ==================== Pearson Filter ====================

class PearsonFilter:
    """Pearson correlation-based redundant feature removal"""
    
    def __init__(self, threshold=0.9):
        self.threshold = threshold
        self.selected_indices = None
        self.selected_names = None
        
    def fit(self, X, feature_names):
        """Select features based on inter-feature correlation"""
        print(f"\n{'='*50}")
        print("Stage 1: Pearson Correlation Redundancy Removal")
        print(f"{'='*50}")
        
        n_features = X.shape[1]
        corr_matrix = np.corrcoef(X.T)
        
        to_remove = set()
        for i in range(n_features):
            for j in range(i+1, n_features):
                if abs(corr_matrix[i, j]) > self.threshold:
                    if j not in to_remove and i not in to_remove:
                        to_remove.add(j)
        
        self.selected_indices = [i for i in range(n_features) if i not in to_remove]
        self.selected_names = [feature_names[i] for i in self.selected_indices]
        
        print(f"Original features: {n_features}")
        print(f"Removed features: {len(to_remove)}")
        print(f"Retained features: {len(self.selected_indices)}")
        
        return self.selected_indices, self.selected_names


# ==================== Genetic Algorithm Feature Selection (Group Version) ====================

class GAFeatureSelectorGroup:
    """Genetic algorithm feature selector - using group cross-validation"""
    
    def __init__(self, X_train, y_train, groups_train, feature_names, 
                 population_size=40, n_generations=30, 
                 min_features=6, max_features=10, random_state=42):
        
        self.X_train = X_train
        self.y_train = y_train
        self.groups_train = groups_train
        self.feature_names = feature_names
        self.n_features = X_train.shape[1]
        self.min_features = min_features
        self.max_features = max_features
        self.population_size = population_size
        self.n_generations = n_generations
        self.random_state = random_state
        
        random.seed(random_state)
        np.random.seed(random_state)
        
        try:
            creator.create("FitnessMax", base.Fitness, weights=(1.0,))
            creator.create("Individual", list, fitness=creator.FitnessMax)
        except:
            pass
        
        self.toolbox = base.Toolbox()
        self.toolbox.register("attr_bool", random.randint, 0, 1)
        self.toolbox.register("individual", tools.initRepeat, creator.Individual,
                             self.toolbox.attr_bool, n=self.n_features)
        self.toolbox.register("population", tools.initRepeat, list, self.toolbox.individual)
        self.toolbox.register("mate", tools.cxTwoPoint)
        self.toolbox.register("mutate", tools.mutFlipBit, indpb=0.1)
        self.toolbox.register("select", tools.selTournament, tournsize=3)
        self.toolbox.register("evaluate", self._fitness_function)
        
        self.best_features = None
        self.best_fitness = -np.inf
        self.history = []
        
    def _fitness_function(self, individual):
        """Fitness function: R² from group cross-validation"""
        mask = np.array(individual, dtype=bool)
        n_selected = np.sum(mask)
        
        if n_selected < self.min_features or n_selected > self.max_features:
            return -10.0,
        
        X_selected = self.X_train[:, mask]
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_selected)
        
        model = lgb.LGBMRegressor(
            n_estimators=100,
            max_depth=3,
            learning_rate=0.05,
            num_leaves=8,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=self.random_state,
            n_jobs=-1,
            verbose=-1
        )
        
        try:
            unique_groups = np.unique(self.groups_train)
            n_splits = min(5, len(unique_groups))
            if n_splits < 2:
                return -10.0,
            
            gkf = GroupKFold(n_splits=n_splits)
            group_labels = pd.factorize(self.groups_train)[0]
            
            cv_scores = cross_val_score(
                model, X_scaled, self.y_train,
                cv=gkf, groups=group_labels,
                scoring='r2'
            )
            fitness = np.mean(cv_scores)
            return fitness,
        except:
            return -10.0,
    
    def run(self, verbose=True):
        """Run genetic algorithm"""
        print(f"\n{'='*50}")
        print("Stage 2: Genetic Algorithm Feature Selection (Group CV)")
        print(f"{'='*50}")
        print(f"Current features: {self.n_features}")
        print(f"Target features: {self.min_features}-{self.max_features}")
        
        population = self.toolbox.population(n=self.population_size)
        
        for gen in range(self.n_generations):
            fitnesses = list(map(self.toolbox.evaluate, population))
            for ind, fit in zip(population, fitnesses):
                ind.fitness.values = fit
            
            fits = [ind.fitness.values[0] for ind in population]
            best_gen = max(fits)
            self.history.append(best_gen)
            
            if verbose and (gen + 1) % 5 == 0:
                print(f"  Generation {gen+1:2d}: Best fitness={best_gen:.4f}")
            
            offspring = self.toolbox.select(population, len(population))
            offspring = list(map(self.toolbox.clone, offspring))
            
            for child1, child2 in zip(offspring[::2], offspring[1::2]):
                if random.random() < 0.7:
                    self.toolbox.mate(child1, child2)
                    del child1.fitness.values
                    del child2.fitness.values
            
            for mutant in offspring:
                if random.random() < 0.1:
                    self.toolbox.mutate(mutant)
                    del mutant.fitness.values
            
            invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
            fitnesses = map(self.toolbox.evaluate, invalid_ind)
            for ind, fit in zip(invalid_ind, fitnesses):
                ind.fitness.values = fit
            
            population[:] = offspring
        
        best_individual = tools.selBest(population, 1)[0]
        self.best_fitness = best_individual.fitness.values[0]
        self.best_features = np.where(np.array(best_individual, dtype=bool))[0]
        
        print(f"\nBest fitness (Group CV R²) = {self.best_fitness:.4f}")
        print(f"Selected features = {len(self.best_features)}")
        
        return self.best_features, self.best_fitness


# ==================== Group Model Trainer ====================

class GroupModelTrainer:
    """Model trainer with group split + original data augmentation + genetic algorithm"""
    
    def __init__(self, augment_factor=3.0, random_state=42):
        self.augment_factor = augment_factor
        self.random_state = random_state
        self.best_model = None
        self.best_model_name = None
        self.best_test_r2 = -np.inf
        self.scaler = StandardScaler()
        self.final_features = None
        self.final_feature_names = None
        self.pearson_indices = None
        self.pearson_names = None
        self.augmentor = DataAugmentor(augment_factor=augment_factor, random_state=random_state)
        self.all_models = {}
        self.feature_info = {}
        self.X_train_aug = None
        self.y_train_aug = None
        self.all_original_feature_names = None
        
        print(f"\n{'='*70}")
        print(f"Group Model Training Configuration")
        print(f"{'='*70}")
        print(f"Data augmentation factor: {augment_factor}x")
        print(f"Random seed: {random_state}")
    
    def train(self, X, y, groups, feature_names, test_size=0.15):
        """Train model - using group split"""
        print("\n" + "="*70)
        print("Starting Model Training (Group Split)")
        print("="*70)
        
        self.all_original_feature_names = feature_names
        self.feature_info['all_feature_names'] = feature_names
        
        # ========== Group Split ==========
        print("\nSplitting data by groups...")
        unique_groups = np.unique(groups)
        n_groups = len(unique_groups)
        n_test_groups = max(1, int(n_groups * test_size))
        
        # Split by Tg mean stratification
        group_tg_means = {}
        for g in unique_groups:
            mask = groups == g
            group_tg_means[g] = np.mean(y[mask])
        
        sorted_by_tg = sorted(unique_groups, key=lambda g: group_tg_means[g])
        
        # Select test groups
        test_groups = set()
        step = max(1, len(sorted_by_tg) / n_test_groups)
        for i in range(n_test_groups):
            idx = int(i * step + step/2)
            idx = min(idx, len(sorted_by_tg) - 1)
            test_groups.add(sorted_by_tg[idx])
        
        # Build split
        train_mask = np.array([g not in test_groups for g in groups])
        test_mask = np.array([g in test_groups for g in groups])
        
        X_train, X_test = X[train_mask], X[test_mask]
        y_train, y_test = y[train_mask], y[test_mask]
        groups_train = groups[train_mask]
        groups_test = groups[test_mask]
        
        print(f"\nGroup split results:")
        print(f"  Total groups: {n_groups}")
        print(f"  Training groups: {n_groups - len(test_groups)}")
        print(f"  Test groups: {len(test_groups)}")
        print(f"  Training samples: {len(y_train)}")
        print(f"  Test samples: {len(y_test)}")
        
        # Save test set info for output
        self.X_test_raw = X_test
        self.y_test_raw = y_test
        self.groups_test_raw = groups_test
        
        # ========== Save original training data ==========
        X_train_original = X_train.copy()
        y_train_original = y_train.copy()
        
        # ========== Stage 1: Pearson Correlation Filter ==========
        pearson = PearsonFilter(threshold=0.9)
        pearson_indices, pearson_names = pearson.fit(X_train, feature_names)
        
        self.pearson_indices = pearson_indices
        self.pearson_names = pearson_names
        
        print(f"\n{'='*50}")
        print("Pearson Correlation Filter Results:")
        print(f"{'='*50}")
        print(f"Original features: {len(feature_names)}")
        print(f"Features after Pearson filter: {len(pearson_names)}")
        
        X_train_pearson = X_train[:, pearson_indices]
        X_test_pearson = X_test[:, pearson_indices]
        
        # ========== Data Augmentation ==========
        X_train_aug, y_train_aug = self.augmentor.augment_training_data(X_train_pearson, y_train)
        
        self.X_train_aug = X_train_aug
        self.y_train_aug = y_train_aug
        
        # Extend groups_train to match augmented data
        n_original = len(X_train_pearson)
        n_aug = len(X_train_aug) - n_original
        
        groups_train_aug = list(groups_train)
        for i in range(n_aug):
            idx = np.random.randint(n_original)
            groups_train_aug.append(groups_train[idx])
        groups_train_aug = np.array(groups_train_aug)
        
        # ========== Stage 2: Genetic Algorithm Feature Selection ==========
        ga = GAFeatureSelectorGroup(
            X_train=X_train_aug,
            y_train=y_train_aug,
            groups_train=groups_train_aug,
            feature_names=pearson_names,
            min_features=6,
            max_features=10,
            population_size=40,
            n_generations=30,
            random_state=self.random_state
        )
        
        ga_features, ga_fitness = ga.run()
        
        self.final_features = [pearson_indices[i] for i in ga_features]
        self.final_feature_names = [feature_names[i] for i in self.final_features]
        
        print(f"\n{'='*70}")
        print("【Final Selected Features】")
        print(f"{'='*70}")
        print(f"Number of selected features: {len(self.final_feature_names)}")
        print("\nFeature list:")
        for i, (idx, name) in enumerate(zip(self.final_features, self.final_feature_names)):
            print(f"{i+1:2d}. Feature index: {idx:3d} | Feature name: {name}")
        print(f"{'='*70}\n")
        
        # ========== Apply Feature Selection ==========
        X_train_final = X_train_aug[:, ga_features]
        X_test_final = X_test[:, self.final_features]
        
        # ========== Standardization ==========
        X_train_scaled = self.scaler.fit_transform(X_train_final)
        X_test_scaled = self.scaler.transform(X_test_final)
        
        # ========== Train Multiple Models ==========
        models = {
            'LightGBM': lgb.LGBMRegressor(
                n_estimators=200, max_depth=4, learning_rate=0.05, num_leaves=15,
                subsample=0.8, colsample_bytree=0.8, reg_alpha=0.1, reg_lambda=1.0,
                random_state=self.random_state, n_jobs=-1, verbose=-1
            ),
            'RandomForest': RandomForestRegressor(
                n_estimators=200, max_depth=6, min_samples_split=5, min_samples_leaf=2,
                random_state=self.random_state, n_jobs=-1
            ),
            'GradientBoosting': GradientBoostingRegressor(
                n_estimators=200, max_depth=4, learning_rate=0.05, subsample=0.8,
                random_state=self.random_state
            ),
            'ExtraTrees': ExtraTreesRegressor(
                n_estimators=200, max_depth=6, min_samples_split=5, min_samples_leaf=2,
                random_state=self.random_state, n_jobs=-1
            ),
            'Ridge': Ridge(alpha=10.0, random_state=self.random_state),
            'SVR_rbf': SVR(kernel='rbf', C=100, gamma='scale', epsilon=0.1),
            'MLP': MLPRegressor(
                hidden_layer_sizes=(100, 50),
                activation='relu',
                solver='adam',
                alpha=0.001,
                batch_size=32,
                learning_rate='constant',
                learning_rate_init=0.001,
                max_iter=500,
                shuffle=True,
                random_state=self.random_state,
                early_stopping=True,
                validation_fraction=0.1,
                n_iter_no_change=10,
                verbose=False
            ),
        }
        
        results = []
        cv_predictions_aug = pd.DataFrame()
        test_predictions = pd.DataFrame()
        
        cv_predictions_aug['True_AugmentedTrain'] = y_train_aug
        test_predictions['True_TestSet'] = y_test
        
        # Store predictions for each model
        all_cv_predictions = {}
        all_test_predictions = {}
        
        for name, model in models.items():
            # Hyperparameter optimization
            if name == 'LightGBM':
                param_grid = {'max_depth': [3, 4, 5], 'learning_rate': [0.03, 0.05, 0.07], 
                              'n_estimators': [150, 200, 250], 'num_leaves': [10, 15, 20]}
                grid_search = GridSearchCV(model, param_grid, cv=5, scoring='r2', n_jobs=-1)
                grid_search.fit(X_train_scaled, y_train_aug)
                best_model = grid_search.best_estimator_
                print(f"\n{name} Best params: {grid_search.best_params_}")
            elif name == 'Ridge':
                param_grid = {'alpha': [0.1, 1.0, 10.0, 50.0, 100.0]}
                grid_search = GridSearchCV(model, param_grid, cv=5, scoring='r2', n_jobs=-1)
                grid_search.fit(X_train_scaled, y_train_aug)
                best_model = grid_search.best_estimator_
                print(f"\n{name} Best params: {grid_search.best_params_}")
            elif name == 'SVR_rbf':
                param_grid = {'C': [1, 10, 100, 1000], 'gamma': ['scale', 'auto', 0.01, 0.1]}
                grid_search = GridSearchCV(model, param_grid, cv=5, scoring='r2', n_jobs=-1)
                grid_search.fit(X_train_scaled, y_train_aug)
                best_model = grid_search.best_estimator_
                print(f"\n{name} Best params: {grid_search.best_params_}")
            elif name == 'MLP':
                param_grid = {
                    'hidden_layer_sizes': [(50,), (100,), (50, 30), (100, 50)],
                    'learning_rate_init': [0.0005, 0.001, 0.005],
                    'alpha': [0.0001, 0.001, 0.01]
                }
                grid_search = GridSearchCV(model, param_grid, cv=5, scoring='r2', n_jobs=-1)
                grid_search.fit(X_train_scaled, y_train_aug)
                best_model = grid_search.best_estimator_
                print(f"\n{name} Best params: {grid_search.best_params_}")
            elif name == 'ExtraTrees':
                param_grid = {'n_estimators': [100, 200, 300], 'max_depth': [4, 6, 8]}
                grid_search = GridSearchCV(model, param_grid, cv=5, scoring='r2', n_jobs=-1)
                grid_search.fit(X_train_scaled, y_train_aug)
                best_model = grid_search.best_estimator_
                print(f"\n{name} Best params: {grid_search.best_params_}")
            else:
                best_model = model
                best_model.fit(X_train_scaled, y_train_aug)
            
            self.all_models[name] = best_model
            
            # ========== Cross-validation prediction (5-fold) ==========
            cv = KFold(n_splits=5, shuffle=True, random_state=self.random_state)
            y_cv_pred_aug = cross_val_predict(best_model, X_train_scaled, y_train_aug, cv=cv)
            
            # Save cross-validation predictions
            all_cv_predictions[name] = y_cv_pred_aug
            
            # ========== Original training set prediction ==========
            X_train_original_scaled = self.scaler.transform(X_train_pearson[:, ga_features])
            y_train_pred_original = best_model.predict(X_train_original_scaled)
            
            # ========== Test set prediction ==========
            y_test_pred = best_model.predict(X_test_scaled)
            all_test_predictions[name] = y_test_pred
            
            # ========== Metric Calculation ==========
            cv_r2_aug = r2_score(y_train_aug, y_cv_pred_aug)
            cv_rmse_aug = np.sqrt(mean_squared_error(y_train_aug, y_cv_pred_aug))
            
            train_r2_original = r2_score(y_train, y_train_pred_original)
            train_rmse_original = np.sqrt(mean_squared_error(y_train, y_train_pred_original))
            
            test_r2 = r2_score(y_test, y_test_pred)
            test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
            test_mae = mean_absolute_error(y_test, y_test_pred)
            
            gap = train_r2_original - test_r2
            
            # Fitting status determination
            if name == 'Ridge':
                if gap > 0.1:
                    fit_status = "Overfitting"
                elif gap < -0.15:
                    fit_status = "Underfitting"
                elif test_r2 > 0.7 and gap < 0.1:
                    fit_status = "Good"
                else:
                    fit_status = "Acceptable"
            else:
                if gap > 0.15:
                    fit_status = "Overfitting"
                elif gap < -0.1:
                    fit_status = "Underfitting"
                elif test_r2 > 0.75 and gap < 0.1:
                    fit_status = "Good"
                else:
                    fit_status = "Acceptable"
            
            results.append({
                'Model': name,
                'AugmentedTrain_CV_R2': cv_r2_aug,
                'AugmentedTrain_CV_RMSE': cv_rmse_aug,
                'OriginalTrain_R2': train_r2_original,
                'OriginalTrain_RMSE': train_rmse_original,
                'Test_R2': test_r2,
                'Test_RMSE': test_rmse,
                'Test_MAE': test_mae,
                'Train_Test_Gap': gap,
                'Fit_Status': fit_status,
                'Model_Object': best_model
            })
            
            print(f"\n{name}:")
            print(f"  Augmented Train CV R² = {cv_r2_aug:.4f}, CV RMSE = {cv_rmse_aug:.2f}°C")
            print(f"  Original Train R² = {train_r2_original:.4f}, RMSE = {train_rmse_original:.2f}°C")
            print(f"  Test R² = {test_r2:.4f}, RMSE = {test_rmse:.2f}°C")
            print(f"  Fit Status: {fit_status}")
            
            cv_predictions_aug[f'{name}_Prediction'] = y_cv_pred_aug
            test_predictions[f'{name}_Prediction'] = y_test_pred
            
            # Select best model
            score = test_r2
            if fit_status == "Overfitting":
                score *= 0.7
            elif fit_status == "Good":
                score *= 1.1
            if name == 'Ridge' and test_r2 < 0.6:
                score *= 0.8
            
            if score > self.best_test_r2:
                self.best_test_r2 = score
                self.best_model = best_model
                self.best_model_name = name
                self.best_result = results[-1]
        
        # ========== Save Prediction Results to CSV ==========
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        model_dir = f"GroupModel_Augment{self.augment_factor}x_{timestamp}"
        os.makedirs(model_dir, exist_ok=True)
        
        # 1. Save cross-validation predictions (augmented training set)
        cv_pred_df = pd.DataFrame()
        cv_pred_df['True_Value'] = y_train_aug
        for name in self.all_models.keys():
            if name in all_cv_predictions:
                cv_pred_df[f'{name}_Prediction'] = all_cv_predictions[name]
                cv_pred_df[f'{name}_Residual'] = y_train_aug - all_cv_predictions[name]
        
        cv_pred_df.to_csv(os.path.join(model_dir, "CrossValidation_Predictions_AugmentedTrain.csv"), index=False, encoding='utf-8-sig')
        print(f"\nCross-validation predictions saved: CrossValidation_Predictions_AugmentedTrain.csv")
        
        # 2. Save test set predictions
        test_pred_df = pd.DataFrame()
        test_pred_df['True_Value'] = y_test
        test_pred_df['Group'] = groups_test
        
        # Add original data index (if available)
        if hasattr(self, 'X_test_raw'):
            test_pred_df['Sample_Index'] = range(len(y_test))
        
        for name in self.all_models.keys():
            if name in all_test_predictions:
                test_pred_df[f'{name}_Prediction'] = all_test_predictions[name]
                test_pred_df[f'{name}_Residual'] = y_test - all_test_predictions[name]
                test_pred_df[f'{name}_AbsError'] = np.abs(y_test - all_test_predictions[name])
        
        # Add best model predictions (separate column for easy viewing)
        if self.best_model_name in all_test_predictions:
            test_pred_df['BestModel_Prediction'] = all_test_predictions[self.best_model_name]
            test_pred_df['BestModel_Residual'] = y_test - all_test_predictions[self.best_model_name]
            test_pred_df['BestModel_AbsError'] = np.abs(y_test - all_test_predictions[self.best_model_name])
        
        test_pred_df.to_csv(os.path.join(model_dir, "TestSet_Predictions.csv"), index=False, encoding='utf-8-sig')
        print(f"Test set predictions saved: TestSet_Predictions.csv")
        
        # 3. Save all model performance comparison
        results_df = pd.DataFrame([
            {k: v for k, v in r.items() if k != 'Model_Object'}
            for r in results
        ])
        results_df.to_csv(os.path.join(model_dir, "Model_Performance_Comparison.csv"), index=False, encoding='utf-8-sig')
        print(f"Model performance comparison saved: Model_Performance_Comparison.csv")
        
        # 4. Save prediction statistics summary
        stats_summary = []
        for name in self.all_models.keys():
            if name in all_test_predictions:
                preds = all_test_predictions[name]
                residuals = y_test - preds
                stats_summary.append({
                    'Model': name,
                    'Test_R2': r2_score(y_test, preds),
                    'Test_RMSE': np.sqrt(mean_squared_error(y_test, preds)),
                    'Test_MAE': mean_absolute_error(y_test, preds),
                    'Pred_Mean': np.mean(preds),
                    'Pred_Std': np.std(preds),
                    'Residual_Mean': np.mean(residuals),
                    'Residual_Std': np.std(residuals),
                    'Max_AbsError': np.max(np.abs(residuals)),
                    'Min_AbsError': np.min(np.abs(residuals))
                })
        
        stats_df = pd.DataFrame(stats_summary)
        stats_df.to_csv(os.path.join(model_dir, "Prediction_Statistics_Summary.csv"), index=False, encoding='utf-8-sig')
        print(f"Prediction statistics summary saved: Prediction_Statistics_Summary.csv")
        
        # 5. Save final selected features
        features_df = pd.DataFrame({
            'Index': range(1, len(self.final_feature_names) + 1),
            'Feature_ID': self.final_features,
            'Feature_Name': self.final_feature_names
        })
        features_df.to_csv(os.path.join(model_dir, "Final_Selected_Features.csv"), index=False, encoding='utf-8-sig')
        print(f"Final selected features saved: Final_Selected_Features.csv")
        
        if self.pearson_names is not None:
            pearson_df = pd.DataFrame({
                'Index': range(1, len(self.pearson_names) + 1),
                'Feature_ID': self.pearson_indices,
                'Feature_Name': self.pearson_names
            })
            pearson_df.to_csv(os.path.join(model_dir, "Pearson_Filtered_Features.csv"), index=False, encoding='utf-8-sig')
            print(f"Pearson filtered features saved: Pearson_Filtered_Features.csv")
        
        # ========== Save Augmented Training Set and Test Set Combined Dataset (for SHAP analysis) ==========
        print("\n" + "="*50)
        print("Saving Augmented Training Set and Test Set Combined Dataset")
        print("="*50)
        
        try:
            # Get Pearson filtered feature names
            pearson_feature_names = self.pearson_names
            n_pearson_features = len(pearson_feature_names)
            
            # 1. Create augmented training set DataFrame
            train_aug_df = pd.DataFrame()
            train_aug_df['Data_Source'] = ['Augmented_Training'] * len(y_train_aug)
            train_aug_df['Tg_True'] = y_train_aug
            
            # Add Pearson filtered features
            for i, feat_name in enumerate(pearson_feature_names):
                if i < X_train_aug.shape[1]:
                    train_aug_df[feat_name] = X_train_aug[:, i]
                else:
                    train_aug_df[feat_name] = 0
            
            # 2. Create test set DataFrame
            X_test_pearson = X_test[:, self.pearson_indices]
            
            test_df = pd.DataFrame()
            test_df['Data_Source'] = ['Test_Set'] * len(y_test)
            test_df['Tg_True'] = y_test
            
            # Add Pearson filtered features
            for i, feat_name in enumerate(pearson_feature_names):
                if i < X_test_pearson.shape[1]:
                    test_df[feat_name] = X_test_pearson[:, i]
                else:
                    test_df[feat_name] = 0
            
            # 3. Combine augmented training set and test set
            combined_df = pd.concat([train_aug_df, test_df], ignore_index=True)
            
            # 4. Save combined dataset
            combined_csv_path = os.path.join(model_dir, "AugmentedTrain_TestSet_Combined.csv")
            combined_df.to_csv(combined_csv_path, index=False, encoding='utf-8-sig')
            print(f"Augmented training and test set combined dataset saved: {combined_csv_path}")
            
            # 5. Save augmented training set and test set separately
            train_aug_csv_path = os.path.join(model_dir, "Augmented_Training_Set_Features.csv")
            train_aug_df.to_csv(train_aug_csv_path, index=False, encoding='utf-8-sig')
            print(f"Augmented training set saved: {train_aug_csv_path}")
            
            test_csv_path = os.path.join(model_dir, "Test_Set_Features.csv")
            test_df.to_csv(test_csv_path, index=False, encoding='utf-8-sig')
            print(f"Test set saved: {test_csv_path}")
            
            # 6. Save as numpy format
            # Save GA-selected features (10 features) - these are what the model actually uses
            X_train_final = X_train_aug[:, ga_features]  # 168 x 10
            np.save(os.path.join(model_dir, "X_train_aug_pearson.npy"), X_train_final)
            np.save(os.path.join(model_dir, "y_train_aug.npy"), y_train_aug)
            np.save(os.path.join(model_dir, "X_test_pearson.npy"), X_test_pearson)
            np.save(os.path.join(model_dir, "y_test.npy"), y_test)
            print(f"Augmented training and test sets saved as numpy format")
            print(f"   X_train_aug_pearson.npy shape: {X_train_final.shape} (filtered features)")
            
            # 7. Save dataset statistics
            stats_data = {
                'Dataset': ['Augmented_Training', 'Test_Set', 'Combined'],
                'Samples': [len(y_train_aug), len(y_test), len(y_train_aug) + len(y_test)],
                'Tg_Mean(C)': [
                    np.mean(y_train_aug), 
                    np.mean(y_test), 
                    np.mean(np.concatenate([y_train_aug, y_test]))
                ],
                'Tg_Std(C)': [
                    np.std(y_train_aug), 
                    np.std(y_test), 
                    np.std(np.concatenate([y_train_aug, y_test]))
                ],
                'Tg_Min(C)': [
                    np.min(y_train_aug), 
                    np.min(y_test), 
                    np.min(np.concatenate([y_train_aug, y_test]))
                ],
                'Tg_Max(C)': [
                    np.max(y_train_aug), 
                    np.max(y_test), 
                    np.max(np.concatenate([y_train_aug, y_test]))
                ],
            }
            stats_df = pd.DataFrame(stats_data)
            stats_csv_path = os.path.join(model_dir, "Dataset_Statistics.csv")
            stats_df.to_csv(stats_csv_path, index=False, encoding='utf-8-sig')
            print(f"Dataset statistics saved: {stats_csv_path}")
            
            print(f"\nDataset statistics:")
            print(f"  Augmented Training: {len(y_train_aug)} samples, Tg mean: {np.mean(y_train_aug):.1f}°C")
            print(f"  Test Set: {len(y_test)} samples, Tg mean: {np.mean(y_test):.1f}°C")
            print(f"  Combined: {len(y_train_aug) + len(y_test)} samples, Tg mean: {np.mean(np.concatenate([y_train_aug, y_test])):.1f}°C")
            print(f"  Features (after Pearson filter): {len(pearson_feature_names)}")
            
        except Exception as e:
            print(f"Warning: Error saving combined dataset: {e}")
            import traceback
            traceback.print_exc()
        
        # ========== Save Models ==========
        for name, model in self.all_models.items():
            joblib.dump(model, os.path.join(model_dir, f"{name}_model.pkl"))
        
        joblib.dump(self.best_model, os.path.join(model_dir, "best_model.pkl"))
        joblib.dump(self.scaler, os.path.join(model_dir, "scaler.pkl"))
        
        group_info = {
            'n_groups': n_groups,
            'n_train_groups': n_groups - len(test_groups),
            'n_test_groups': len(test_groups),
            'test_groups': list(test_groups)
        }
        
        self.feature_info.update({
            'final_features': self.final_features,
            'final_feature_names': self.final_feature_names,
            'pearson_indices': self.pearson_indices,
            'pearson_names': self.pearson_names,
            'all_original_feature_names': self.all_original_feature_names,
            'n_features': len(self.final_features),
            'best_model_name': self.best_model_name,
            'best_test_r2': self.best_result['Test_R2'],
            'best_test_rmse': self.best_result['Test_RMSE'],
            'best_fit_status': self.best_result['Fit_Status'],
            'augment_factor': self.augment_factor,
            'random_state': self.random_state,
            'model_names': list(self.all_models.keys()),
            'training_results': results,
            'group_info': group_info
        })
        
        with open(os.path.join(model_dir, "feature_info.pkl"), 'wb') as f:
            pickle.dump(self.feature_info, f)
        
        print(f"\n{'='*50}")
        print(f"Best Model: {self.best_model_name}")
        print(f"Test R² = {self.best_result['Test_R2']:.4f}")
        print(f"Test RMSE = {self.best_result['Test_RMSE']:.2f}°C")
        print(f"Fit Status: {self.best_result['Fit_Status']}")
        print(f"Final selected features: {len(self.final_features)}")
        print(f"Model saved to: {model_dir}")
        print(f"{'='*50}")
        
        # Plotting
        X_test_final_scaled = self.scaler.transform(X_test[:, self.final_features])
        y_test_pred = self.best_model.predict(X_test_final_scaled)
        self._plot_results(y_test, y_test_pred, model_dir)
        
        return model_dir
    
    def _plot_results(self, y_true, y_pred, save_dir):
        """Plot prediction results"""
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        
        ax1 = axes[0]
        ax1.scatter(y_true, y_pred, alpha=0.7, s=60)
        min_val = min(y_true.min(), y_pred.min())
        max_val = max(y_true.max(), y_pred.max())
        ax1.plot([min_val, max_val], [min_val, max_val], 'r--', lw=2, label='Ideal Line')
        ax1.set_xlabel('True Tg (°C)')
        ax1.set_ylabel('Predicted Tg (°C)')
        ax1.set_title(f'Test Set Prediction\nR² = {r2_score(y_true, y_pred):.4f}, RMSE = {np.sqrt(mean_squared_error(y_true, y_pred)):.2f}°C')
        ax1.grid(True, alpha=0.3)
        ax1.legend()
        
        ax2 = axes[1]
        residuals = y_true - y_pred
        ax2.hist(residuals, bins=10, alpha=0.7, color='steelblue', edgecolor='black')
        ax2.axvline(x=0, color='r', linestyle='--', linewidth=2)
        ax2.set_xlabel('Residual (°C)')
        ax2.set_ylabel('Frequency')
        ax2.set_title(f'Residual Distribution\nMean = {np.mean(residuals):.2f}°C, Std = {np.std(residuals):.2f}°C')
        ax2.grid(True, alpha=0.3)
        
        ax3 = axes[2]
        indices = np.arange(len(y_true))
        width = 0.35
        ax3.bar(indices - width/2, y_true, width, label='True', alpha=0.7)
        ax3.bar(indices + width/2, y_pred, width, label='Predicted', alpha=0.7)
        ax3.set_xlabel('Sample')
        ax3.set_ylabel('Tg (°C)')
        ax3.set_title('True vs Predicted Comparison')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, "Results_Plot.png"), dpi=300)
        plt.show()


# ==================== Feature Extractor ====================

class FeatureExtractor:
    def __init__(self):
        pass
    
    def extract_monomer_features(self, smiles):
        """Extract 15 features from a monomer"""
        try:
            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                return None
            
            features = []
            features.append(Descriptors.MolWt(mol))
            features.append(Descriptors.NumRotatableBonds(mol))
            features.append(mol.GetNumHeavyAtoms())
            features.append(Descriptors.TPSA(mol))
            features.append(Crippen.MolLogP(mol))
            features.append(Descriptors.NumHDonors(mol))
            features.append(Descriptors.NumHAcceptors(mol))
            
            aromatic_atoms = sum(1 for atom in mol.GetAtoms() if atom.GetIsAromatic())
            heavy_atoms = mol.GetNumHeavyAtoms()
            features.append(aromatic_atoms / max(heavy_atoms, 1))
            
            features.append(Descriptors.RingCount(mol))
            
            rotatable = Descriptors.NumRotatableBonds(mol)
            features.append((heavy_atoms - rotatable) / max(heavy_atoms, 1))
            features.append(Descriptors.TPSA(mol) / max(Descriptors.MolWt(mol), 1))
            features.append(Descriptors.Chi0(mol))
            features.append(Crippen.MolMR(mol))
            features.append((heavy_atoms ** (1/3)) / max(rotatable + 1, 1))
            features.append(rotatable / max(heavy_atoms, 1))
            
            return np.array(features)
        except:
            return None
    
    def extract_polymer_features(self, smiles_list, ratios=None):
        """Extract all features for a polymer"""
        mono_features_list = []
        for smiles in smiles_list:
            feats = self.extract_monomer_features(smiles)
            if feats is not None:
                mono_features_list.append(feats)
        
        if not mono_features_list:
            return None
        
        mono_features = np.array(mono_features_list)
        
        if ratios is None:
            ratios = np.ones(len(smiles_list)) / len(smiles_list)
        else:
            ratios = np.array(ratios) / sum(ratios)
        
        polymer_features = []
        
        for i in range(mono_features.shape[1]):
            polymer_features.append(np.sum(mono_features[:, i] * ratios))
        
        if len(smiles_list) > 1:
            for i in range(min(10, mono_features.shape[1])):
                polymer_features.append(np.std(mono_features[:, i]))
        else:
            polymer_features.extend([0] * 10)
        
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.max(mono_features[:, i]))
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.min(mono_features[:, i]))
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.max(mono_features[:, i]) - np.min(mono_features[:, i]))
        
        mw_mean = np.sum(mono_features[:, 0] * ratios)
        rigid_mean = np.sum(mono_features[:, 9] * ratios)
        aromatic_mean = np.sum(mono_features[:, 7] * ratios)
        tpsa_mean = np.sum(mono_features[:, 3] * ratios)
        rotatable_mean = np.sum(mono_features[:, 1] * ratios)
        
        polymer_features.append(mw_mean * rigid_mean)
        polymer_features.append(mw_mean * aromatic_mean)
        polymer_features.append(rigid_mean * aromatic_mean)
        polymer_features.append(tpsa_mean / max(rotatable_mean, 0.1))
        polymer_features.append(mw_mean / max(rotatable_mean, 0.1))
        
        polymer_features.append(len(smiles_list))
        polymer_features.append(np.sum(mono_features[:, 0]))
        polymer_features.append(np.sum(mono_features[:, 7]))
        
        return np.array(polymer_features)


# ==================== Predictor ====================

class Predictor:
    def __init__(self, model_dir):
        self.model_dir = model_dir
        
        with open(os.path.join(model_dir, "feature_info.pkl"), 'rb') as f:
            self.feature_info = pickle.load(f)
        
        self.final_features = self.feature_info['final_features']
        self.final_feature_names = self.feature_info['final_feature_names']
        self.model_names = self.feature_info.get('model_names', ['LightGBM'])
        
        self.pearson_indices = self.feature_info.get('pearson_indices', None)
        self.pearson_names = self.feature_info.get('pearson_names', None)
        self.all_original_feature_names = self.feature_info.get('all_original_feature_names', None)
        
        self.scaler = joblib.load(os.path.join(model_dir, "scaler.pkl"))
        
        self.models = {}
        for name in self.model_names:
            try:
                model_path = os.path.join(model_dir, f"{name}_model.pkl")
                if os.path.exists(model_path):
                    self.models[name] = joblib.load(model_path)
                else:
                    self.models[name] = joblib.load(os.path.join(model_dir, "best_model.pkl"))
            except:
                continue
        
        self.feature_extractor = FeatureExtractor()
        
        print(f"\n{'='*50}")
        print("Predictor initialized successfully")
        print(f"{'='*50}")
        print(f"Loaded models: {len(self.models)}")
        print(f"Best model: {self.feature_info['best_model_name']}")
        print(f"Test R² = {self.feature_info['best_test_r2']:.4f}")
        print(f"Features used: {len(self.final_feature_names)}")
    
    def predict_with_all_models(self, smiles_list, ratios=None):
        all_features = self.feature_extractor.extract_polymer_features(smiles_list, ratios)
        if all_features is None:
            return None
        
        selected_features = all_features[self.final_features]
        features_scaled = self.scaler.transform(selected_features.reshape(1, -1))
        
        predictions = {}
        for name, model in self.models.items():
            pred = model.predict(features_scaled)[0]
            predictions[name] = round(pred, 2)
        
        return predictions
    
    def predict_samples_from_dataframe(self, df):
        print("\n" + "="*70)
        print("Predicting molecules from Excel file")
        print("="*70)
        
        monomer_cols = []
        ratio_cols = []
        
        for col in df.columns:
            col_lower = str(col).lower()
            if 'monomer' in col_lower or 'smiles' in col_lower:
                monomer_cols.append(col)
            elif 'ratio' in col_lower:
                ratio_cols.append(col)
        
        print(f"Monomer columns found: {monomer_cols}")
        print(f"Ratio columns found: {ratio_cols}")
        
        results_data = []
        
        for idx, row in df.iterrows():
            smiles_list = []
            ratios = []
            
            for m_col in monomer_cols:
                if pd.notna(row[m_col]) and str(row[m_col]).strip() and str(row[m_col]).strip() != 'nan':
                    smiles_list.append(str(row[m_col]).strip())
            
            if ratio_cols:
                for r_col in ratio_cols:
                    if pd.notna(row[r_col]):
                        try:
                            ratios.append(float(row[r_col]))
                        except:
                            ratios.append(0)
            
            if not smiles_list:
                continue
            
            preds = self.predict_with_all_models(smiles_list, ratios if ratios else None)
            
            if preds is not None:
                row_data = {}
                
                for col in df.columns:
                    row_data[col] = row[col]
                
                for model_name, pred_value in preds.items():
                    row_data[f'{model_name}_Predicted_Tg(C)'] = pred_value
                
                pred_values = list(preds.values())
                row_data['AllModels_Avg_Tg(C)'] = round(np.mean(pred_values), 2)
                row_data['BestModel_Predicted_Tg(C)'] = preds.get(self.feature_info['best_model_name'], pred_values[0])
                
                results_data.append(row_data)
                
                print(f"\nSample {idx+1}:")
                print(f"  SMILES: {'; '.join(smiles_list)}")
                if ratios:
                    print(f"  Ratios: {ratios}")
                print(f"  Best model prediction: {row_data['BestModel_Predicted_Tg(C)']}°C")
                print(f"  All models average: {row_data['AllModels_Avg_Tg(C)']}°C")
            else:
                print(f"\nSample {idx+1}: Prediction failed")
        
        results_df = pd.DataFrame(results_data)
        return results_df


# ==================== Prediction Output Generator ====================

class PredictionOutputGenerator:
    def __init__(self, predictor, save_dir):
        self.predictor = predictor
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)
    
    def generate_prediction_report(self, samples_df, results_df):
        print(f"\n{'='*70}")
        print("Generating Comprehensive Prediction Report")
        print(f"{'='*70}")
        
        excel_file = os.path.join(self.save_dir, "Comprehensive_Prediction_Report.xlsx")
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            results_df.to_excel(writer, sheet_name='Prediction_Results', index=False)
            
            model_performance = self._get_model_performance_data()
            if model_performance:
                pd.DataFrame(model_performance).to_excel(writer, sheet_name='Model_Performance', index=False)
            
            stats_df = self._calculate_prediction_statistics(results_df)
            stats_df.to_excel(writer, sheet_name='Prediction_Statistics', index=False)
            
            final_features_df = pd.DataFrame({
                'Index': range(1, len(self.predictor.final_feature_names) + 1),
                'Feature_ID': self.predictor.final_features,
                'Feature_Name': self.predictor.final_feature_names
            })
            final_features_df.to_excel(writer, sheet_name='Final_Selected_Features', index=False)
        
        csv_file = os.path.join(self.save_dir, "Prediction_Results.csv")
        results_df.to_csv(csv_file, index=False, encoding='utf-8-sig')
        
        print(f"Excel report saved: {excel_file}")
        print(f"CSV results saved: {csv_file}")
        
        return {'excel': excel_file, 'csv': csv_file}
    
    def _get_model_performance_data(self):
        try:
            feature_info = self.predictor.feature_info
            training_results = feature_info.get('training_results', [])
            for r in training_results:
                if 'Model_Object' in r:
                    del r['Model_Object']
            return training_results
        except:
            return []
    
    def _calculate_prediction_statistics(self, results_df):
        stats = []
        pred_columns = [col for col in results_df.columns if 'Predicted_Tg' in col and 'Avg' not in col and 'Best' not in col]
        
        for col in pred_columns:
            model_name = col.replace('_Predicted_Tg(C)', '').strip()
            preds = results_df[col].values
            stats.append({
                'Model_Name': model_name,
                'Pred_Mean(C)': np.mean(preds),
                'Pred_Std(C)': np.std(preds),
                'Pred_Min(C)': np.min(preds),
                'Pred_Max(C)': np.max(preds),
            })
        
        return pd.DataFrame(stats)


# ==================== Main Program ====================

def main():
    print("="*70)
    print("Polymer Tg Prediction Model - Group Split + Genetic Algorithm + Original Data Augmentation")
    print("="*70)
    
    AUGMENT_FACTOR = 3.0
    RANDOM_STATE = 69
    
    print(f"\nCurrent configuration:")
    print(f"  Data augmentation factor: {AUGMENT_FACTOR}x")
    print(f"  Random seed: {RANDOM_STATE}")
    
    train_data_file = "LCP-Tg0110.xlsx"
    predict_file = "Selected_Molecules.xlsx"
    
    if not os.path.exists(train_data_file):
        print(f"Error: Training data file '{train_data_file}' does not exist!")
        return
    
    print(f"\n{'='*70}")
    print("Step 1: Loading training data and training model (Group Split)")
    print(f"{'='*70}")
    
    processor = GroupDataProcessor(train_data_file)
    processor.load_and_extract_features()
    
    trainer = GroupModelTrainer(
        augment_factor=AUGMENT_FACTOR,
        random_state=RANDOM_STATE
    )
    model_dir = trainer.train(processor.X, processor.y, processor.groups, processor.feature_names)
    
    # If prediction file exists, perform prediction
    if os.path.exists(predict_file):
        print(f"\n{'='*70}")
        print("Step 2: Loading molecules for prediction")
        print(f"{'='*70}")
        
        predict_df = pd.read_excel(predict_file)
        print(f"Successfully loaded {len(predict_df)} samples for prediction")
        
        predictor = Predictor(model_dir)
        results_df = predictor.predict_samples_from_dataframe(predict_df)
        
        if len(results_df) > 0:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_dir = f"Prediction_Results_{timestamp}"
            output_generator = PredictionOutputGenerator(predictor, output_dir)
            output_generator.generate_prediction_report(predict_df, results_df)
            
            print(f"\n{'='*70}")
            print("Prediction Results Summary:")
            print(f"{'='*70}")
            
            best_pred_col = 'BestModel_Predicted_Tg(C)'
            if best_pred_col in results_df.columns:
                best_preds = results_df[best_pred_col].values
                print(f"\nHighest predicted Tg: {np.max(best_preds):.2f}°C")
                print(f"Lowest predicted Tg: {np.min(best_preds):.2f}°C")
                print(f"Average predicted Tg: {np.mean(best_preds):.2f}°C")
    
    print(f"\n{'='*70}")
    print("Program execution completed!")
    print("="*70)


if __name__ == "__main__":
    main()