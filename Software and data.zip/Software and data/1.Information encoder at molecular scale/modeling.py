# -*- coding: utf-8 -*-
"""
nested_cv_group.py
Nested GroupKFold evaluation for polymer Tg prediction.
Adapted for LCP-Tg0110.xlsx with columns:
    Polymer_ID | Tg | step | temperature | Molar Ratio1..4 | 单体1..4
(also supports Sheet2 style: Monomer1..4 | Monomer Ratio1..4)

NEW in this version:
  - After nested CV, retrains all 7 models on the full dataset
  - Saves all 7 model pkl files + scaler.pkl + feature_info.pkl
  - Saves X_train_aug_pearson.npy / y_train_aug.npy for SHAP
  - Predicts new molecules in Selected_Molecules.xlsx -> Predicted_Tg.csv
"""

import os
import re
import random
import pickle
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import lightgbm as lgb
import joblib
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import GroupKFold, cross_val_score, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import (RandomForestRegressor,
                              GradientBoostingRegressor,
                              ExtraTreesRegressor)
from sklearn.neighbors import NearestNeighbors
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor

from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen
from deap import base, creator, tools

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


# =====================================================================
# 1) GroupDataProcessor
# =====================================================================
class GroupDataProcessor:
    def __init__(self, data_file="Your data path", sheet_name=0):
        self.data_file = data_file
        self.sheet_name = sheet_name
        self.df = None
        self.X = None
        self.y = None
        self.groups = None
        self.feature_names = []
        self.original_smiles = []

    def _identify_columns(self):
        cols = list(self.df.columns)
        tg_col = None
        for c in cols:
            cl = str(c).lower().strip()
            if cl == 'tg' or 'glass' in cl:
                tg_col = c
                break

        monomer_cols, ratio_cols = [], []
        for c in cols:
            s = str(c)
            if (re.search(r'(monomer|smiles)', s, re.IGNORECASE)
                    and not re.search(r'ratio', s, re.IGNORECASE)):
                monomer_cols.append(c)
            elif re.search(r'(ratio)', s, re.IGNORECASE):
                ratio_cols.append(c)

        def _sort_key(c):
            m = re.search(r'(\d+)', str(c))
            return int(m.group(1)) if m else 0
        monomer_cols = sorted(monomer_cols, key=_sort_key)
        ratio_cols = sorted(ratio_cols, key=_sort_key)

        id_col = None
        for c in cols:
            cl = str(c).lower().strip()
            if cl == 'polymer_id' or cl == 'id':
                id_col = c
                break

        if tg_col is None:
            tg_col = cols[1] if len(cols) > 1 else cols[0]

        print(f"Tg column       : {tg_col}")
        print(f"Monomer columns : {monomer_cols}")
        print(f"Ratio columns   : {ratio_cols}")
        print(f"ID column       : {id_col}")

        if len(monomer_cols) == 0:
            raise ValueError(
                "No monomer column identified! Please check whether headers "
                "contain 'Monomer' or 'smiles'."
                f" Current columns: {cols}")
        return tg_col, monomer_cols, ratio_cols, id_col

    def load_and_extract_features(self):
        print(f"Loading data: {self.data_file} (sheet={self.sheet_name})")
        self.df = pd.read_excel(self.data_file, sheet_name=self.sheet_name)
        tg_col, monomer_cols, ratio_cols, id_col = self._identify_columns()

        self.df = self.df.dropna(subset=[tg_col])
        self.df = self.df[pd.to_numeric(self.df[tg_col], errors='coerce').notna()]

        all_features, all_tg, all_groups, all_smiles_info = [], [], [], []
        for idx, row in self.df.iterrows():
            try:
                tg = float(row[tg_col])
                monomers, ratios = [], []
                for m_col, r_col in zip(monomer_cols, ratio_cols):
                    smi = row[m_col]
                    if pd.isna(smi):
                        continue
                    smi = str(smi).strip()
                    if not smi or smi.lower() == 'nan':
                        continue
                    monomers.append(smi)
                    if r_col is not None and pd.notna(row[r_col]):
                        try:
                            ratios.append(float(row[r_col]))
                        except Exception:
                            ratios.append(1.0)
                    else:
                        ratios.append(1.0)

                if len(monomers) == 0:
                    continue

                mono_feats, valid_idx = [], []
                for k, s in enumerate(monomers):
                    f = self._extract_monomer_features(s)
                    if f is not None:
                        mono_feats.append(f)
                        valid_idx.append(k)
                if len(mono_feats) == 0:
                    continue

                mf = np.array(mono_feats)
                r = np.array([ratios[i] for i in valid_idx], dtype=float)
                if r.sum() <= 0:
                    r = np.ones(len(mono_feats))
                r = r / r.sum()

                pf = self._calculate_enhanced_polymer_features(mf, r)

                if id_col is not None and pd.notna(row[id_col]):
                    group = f"PID_{row[id_col]}"
                else:
                    group = '|'.join(sorted(monomers))

                all_smiles_info.append({'index': idx,
                                        'smiles_list': monomers,
                                        'ratios': ratios,
                                        'tg_value': tg,
                                        'group': group})
                all_features.append(pf)
                all_tg.append(tg)
                all_groups.append(group)
            except Exception:
                continue

        if len(all_features) == 0:
            raise ValueError(
                "No valid samples after feature extraction! Please check "
                "whether monomer SMILES are valid RDKit-parsable strings.")

        self.X = np.array(all_features)
        self.y = np.array(all_tg)
        self.groups = np.array(all_groups)
        self.original_smiles = all_smiles_info
        self._generate_enhanced_feature_names()

        print(f"\nOriginal data statistics:")
        print(f"  Total samples : {len(self.y)}")
        print(f"  Total features: {self.X.shape[1]}")
        print(f"  Number of groups: {len(np.unique(self.groups))}")
        print(f"  Tg range: {self.y.min():.1f} - {self.y.max():.1f} C")
        print(f"  Tg mean : {self.y.mean():.1f} +/- {self.y.std():.1f} C")
        return self

    def _extract_monomer_features(self, smiles):
        try:
            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                return None
            f = []
            f.append(Descriptors.MolWt(mol))
            f.append(Descriptors.NumRotatableBonds(mol))
            f.append(mol.GetNumHeavyAtoms())
            f.append(Descriptors.TPSA(mol))
            f.append(Crippen.MolLogP(mol))
            f.append(Descriptors.NumHDonors(mol))
            f.append(Descriptors.NumHAcceptors(mol))
            arom = sum(1 for a in mol.GetAtoms() if a.GetIsAromatic())
            ha = mol.GetNumHeavyAtoms()
            f.append(arom / max(ha, 1))
            f.append(Descriptors.RingCount(mol))
            rot = Descriptors.NumRotatableBonds(mol)
            f.append((ha - rot) / max(ha, 1))
            f.append(Descriptors.TPSA(mol) / max(Descriptors.MolWt(mol), 1))
            f.append(Descriptors.Chi0(mol))
            f.append(Crippen.MolMR(mol))
            f.append((ha ** (1/3)) / max(rot + 1, 1))
            f.append(rot / max(ha, 1))
            return np.array(f)
        except Exception:
            return None

    def _calculate_enhanced_polymer_features(self, mono_features, ratios):
        pf = []
        n_mono = mono_features.shape[0]
        for i in range(mono_features.shape[1]):
            pf.append(float(np.sum(mono_features[:, i] * ratios)))
        if n_mono > 1:
            for i in range(min(10, mono_features.shape[1])):
                mu = np.sum(mono_features[:, i] * ratios)
                var = np.sum(ratios * (mono_features[:, i] - mu) ** 2)
                pf.append(float(np.sqrt(var)))
        else:
            pf.extend([0.0] * 10)
        for i in range(min(5, mono_features.shape[1])):
            pf.append(float(np.max(mono_features[:, i])))
        for i in range(min(5, mono_features.shape[1])):
            pf.append(float(np.min(mono_features[:, i])))
        for i in range(min(5, mono_features.shape[1])):
            pf.append(float(np.max(mono_features[:, i]) - np.min(mono_features[:, i])))
        mw_m   = float(np.sum(mono_features[:, 0] * ratios))
        rot_m  = float(np.sum(mono_features[:, 1] * ratios))
        tpsa_m = float(np.sum(mono_features[:, 3] * ratios))
        arom_m = float(np.sum(mono_features[:, 7] * ratios))
        rig_m  = float(np.sum(mono_features[:, 9] * ratios))
        pf.append(mw_m * rig_m)
        pf.append(mw_m * arom_m)
        pf.append(rig_m * arom_m)
        pf.append(tpsa_m / max(rot_m, 0.1))
        pf.append(mw_m / max(rot_m, 0.1))
        pf.append(float(n_mono))
        pf.append(float(np.sum(mono_features[:, 0])))
        pf.append(float(np.sum(mono_features[:, 7])))
        return np.array(pf)

    def _generate_enhanced_feature_names(self):
        base = ['MolecularWeight', 'RotatableBonds', 'HeavyAtoms', 'TPSA', 'LogP',
                'HDonors', 'HAcceptors', 'AromaticRatio', 'RingCount',
                'RigidityIndex', 'PolarityIndex', 'TopologicalIndex',
                'MolarRefractivity', 'ShapeIndex', 'FlexibilityIndex']
        self.feature_names = []
        for n in base:
            self.feature_names.append(f"Mean_{n}")
        for i in range(10):
            self.feature_names.append(f"Std_{base[i]}")
        for i in range(5):
            self.feature_names.append(f"Max_{base[i]}")
        for i in range(5):
            self.feature_names.append(f"Min_{base[i]}")
        for i in range(5):
            self.feature_names.append(f"Range_{base[i]}")
        self.feature_names.extend(['MW_x_Rigidity', 'MW_x_Aromaticity',
                                   'Rigidity_x_Aromaticity',
                                   'Polarity_Flexibility', 'MW_Flexibility'])
        self.feature_names.extend(['MonomerCount', 'TotalMW', 'TotalAromaticity'])


# =====================================================================
# 2) DataAugmentor
# =====================================================================
class DataAugmentor:
    def __init__(self, augment_factor=3.0, random_state=42):
        self.augment_factor = augment_factor
        self.random_state = random_state
        np.random.seed(random_state)
        random.seed(random_state)

    def add_gaussian_noise(self, X, noise_level=0.02):
        X_std = np.std(X, axis=0)
        noise = np.random.normal(0, noise_level * X_std, X.shape)
        return X + noise

    def add_uniform_noise(self, X, noise_level=0.02):
        X_range = np.max(X, axis=0) - np.min(X, axis=0)
        noise = np.random.uniform(-noise_level * X_range,
                                  noise_level * X_range, X.shape)
        return X + noise

    def smote_like_augmentation(self, X, y, k=5, n_synthetic=None):
        n = len(X)
        if n_synthetic is None:
            n_synthetic = n
        nn = NearestNeighbors(n_neighbors=min(k + 1, n), metric='euclidean')
        nn.fit(X)
        _, indices = nn.kneighbors(X)
        Xa, ya = [], []
        for _ in range(n_synthetic):
            i = np.random.randint(n)
            j = np.random.choice(indices[i, 1:])
            a = np.random.uniform(0.3, 0.7)
            Xa.append(a * X[i] + (1 - a) * X[j])
            ya.append(a * y[i] + (1 - a) * y[j])
        return np.array(Xa), np.array(ya)

    def augment_training_data(self, X_train, y_train):
        n0 = len(X_train)
        target = int(n0 * self.augment_factor)
        n_new = target - n0
        if n_new <= 0:
            return X_train, y_train
        n1 = n_new // 3
        n2 = n_new // 3
        n3 = n_new - n1 - n2
        Xs, ys = [X_train], [y_train]
        if n1 > 0:
            Xs.append(self.add_gaussian_noise(X_train[:n1], 0.02))
            ys.append(y_train[:n1])
        if n2 > 0:
            Xs.append(self.add_uniform_noise(X_train[:n2], 0.02))
            ys.append(y_train[:n2])
        if n3 > 0:
            Xa, ya = self.smote_like_augmentation(X_train, y_train, 5, n3)
            Xs.append(Xa); ys.append(ya)
        return np.vstack(Xs), np.concatenate(ys)


# =====================================================================
# 3) PearsonFilter
# =====================================================================
class PearsonFilter:
    def __init__(self, threshold=0.9):
        self.threshold = threshold
        self.selected_indices = None
        self.selected_names = None

    def fit(self, X, feature_names):
        n = X.shape[1]
        with np.errstate(invalid='ignore', divide='ignore'):
            corr = np.corrcoef(X.T)
        corr = np.nan_to_num(corr, nan=0.0)
        remove = set()
        for i in range(n):
            for j in range(i + 1, n):
                if abs(corr[i, j]) > self.threshold:
                    if j not in remove and i not in remove:
                        remove.add(j)
        self.selected_indices = [i for i in range(n) if i not in remove]
        self.selected_names = [feature_names[i] for i in self.selected_indices]
        return self.selected_indices, self.selected_names


# =====================================================================
# 4) GAFeatureSelectorGroup
# =====================================================================
class GAFeatureSelectorGroup:
    def __init__(self, X_train, y_train, groups_train, feature_names,
                 population_size=40, n_generations=30,
                 min_features=6, max_features=10, random_state=42):
        self.X_train = X_train
        self.y_train = y_train
        self.groups_train = groups_train
        self.feature_names = feature_names
        self.n_features = X_train.shape[1]
        self.min_features = min_features
        self.max_features = max_features
        self.population_size = population_size
        self.n_generations = n_generations
        self.random_state = random_state
        random.seed(random_state)
        np.random.seed(random_state)
        try:
            creator.create("FitnessMax", base.Fitness, weights=(1.0,))
            creator.create("Individual", list, fitness=creator.FitnessMax)
        except Exception:
            pass
        self.toolbox = base.Toolbox()
        self.toolbox.register("attr_bool", random.randint, 0, 1)
        self.toolbox.register("individual", tools.initRepeat, creator.Individual,
                              self.toolbox.attr_bool, n=self.n_features)
        self.toolbox.register("population", tools.initRepeat, list,
                              self.toolbox.individual)
        self.toolbox.register("mate", tools.cxTwoPoint)
        self.toolbox.register("mutate", tools.mutFlipBit, indpb=0.1)
        self.toolbox.register("select", tools.selTournament, tournsize=3)
        self.toolbox.register("evaluate", self._fitness_function)
        self.best_features = None
        self.best_fitness = -np.inf
        self.history = []

    def _fitness_function(self, individual):
        mask = np.array(individual, dtype=bool)
        n_sel = int(np.sum(mask))
        if n_sel < self.min_features or n_sel > self.max_features:
            return -10.0,
        Xs = self.X_train[:, mask]
        scaler = StandardScaler()
        Xs = scaler.fit_transform(Xs)
        model = lgb.LGBMRegressor(
            n_estimators=100, max_depth=3, learning_rate=0.05,
            num_leaves=8, subsample=0.8, colsample_bytree=0.8,
            random_state=self.random_state, n_jobs=-1, verbose=-1)
        try:
            ug = np.unique(self.groups_train)
            n_splits = min(5, len(ug))
            if n_splits < 2:
                return -10.0,
            gkf = GroupKFold(n_splits=n_splits)
            labels = pd.factorize(self.groups_train)[0]
            scores = cross_val_score(model, Xs, self.y_train,
                                     cv=gkf, groups=labels, scoring='r2')
            return float(np.mean(scores)),
        except Exception:
            return -10.0,

    def run(self, verbose=True):
        pop = self.toolbox.population(n=self.population_size)
        for gen in range(self.n_generations):
            fit = list(map(self.toolbox.evaluate, pop))
            for ind, f in zip(pop, fit):
                ind.fitness.values = f
            if verbose and (gen + 1) % 5 == 0:
                print(f"  Gen {gen+1:2d}: best={max(i.fitness.values[0] for i in pop):.4f}")
            off = self.toolbox.select(pop, len(pop))
            off = list(map(self.toolbox.clone, off))
            for c1, c2 in zip(off[::2], off[1::2]):
                if random.random() < 0.7:
                    self.toolbox.mate(c1, c2)
                    del c1.fitness.values; del c2.fitness.values
            for m in off:
                if random.random() < 0.1:
                    self.toolbox.mutate(m)
                    del m.fitness.values
            inv = [ind for ind in off if not ind.fitness.valid]
            for ind, f in zip(inv, map(self.toolbox.evaluate, inv)):
                ind.fitness.values = f
            pop[:] = off
        best = tools.selBest(pop, 1)[0]
        self.best_fitness = best.fitness.values[0]
        self.best_features = np.where(np.array(best, dtype=bool))[0]
        if verbose:
            print(f"  GA best fitness(GroupCV R2)={self.best_fitness:.4f}, "
                  f"selected={len(self.best_features)}")
        return self.best_features, self.best_fitness


# =====================================================================
# 5) Model zoo & parameter grids
# =====================================================================
def get_model_zoo(seed):
    return {
        'LightGBM': lgb.LGBMRegressor(
            n_estimators=200, max_depth=4, learning_rate=0.05, num_leaves=15,
            subsample=0.8, colsample_bytree=0.8, reg_alpha=0.1, reg_lambda=1.0,
            random_state=seed, n_jobs=-1, verbose=-1),
        'RandomForest': RandomForestRegressor(
            n_estimators=200, max_depth=6, min_samples_split=5, min_samples_leaf=2,
            random_state=seed, n_jobs=-1),
        'GradientBoosting': GradientBoostingRegressor(
            n_estimators=200, max_depth=4, learning_rate=0.05, subsample=0.8,
            random_state=seed),
        'ExtraTrees': ExtraTreesRegressor(
            n_estimators=200, max_depth=6, min_samples_split=5, min_samples_leaf=2,
            random_state=seed, n_jobs=-1),
        'Ridge': Ridge(alpha=10.0, random_state=seed),
        'SVR_rbf': SVR(kernel='rbf', C=100, gamma='scale', epsilon=0.1),
        'MLP': MLPRegressor(
            hidden_layer_sizes=(100, 50), activation='relu', solver='adam',
            alpha=0.001, batch_size=32, learning_rate='constant',
            learning_rate_init=0.001, max_iter=500, shuffle=True,
            random_state=seed, early_stopping=True, validation_fraction=0.1,
            n_iter_no_change=10, verbose=False),
    }


def get_param_grids():
    return {
        'LightGBM': {'max_depth': [3, 4, 5],
                     'learning_rate': [0.03, 0.05, 0.07],
                     'n_estimators': [150, 200, 250],
                     'num_leaves': [10, 15, 20]},
        'Ridge':    {'alpha': [0.1, 1.0, 10.0, 50.0, 100.0]},
        'SVR_rbf':  {'C': [1, 10, 100, 1000],
                     'gamma': ['scale', 'auto', 0.01, 0.1]},
        'MLP':      {'hidden_layer_sizes': [(50,), (100,), (50, 30), (100, 50)],
                     'learning_rate_init': [0.0005, 0.001, 0.005],
                     'alpha': [0.0001, 0.001, 0.01]},
        'ExtraTrees': {'n_estimators': [100, 200, 300],
                       'max_depth': [4, 6, 8]},
    }


# =====================================================================
# 6) Single-fold pipeline (strictly uses only outer training fold)
# =====================================================================
def run_one_fold(X_tr, y_tr, g_tr, X_va, y_va, g_va,
                 feature_names, seed, fold_id, verbose_ga=True):
    print(f"\n{'#'*70}\n# OUTER FOLD {fold_id}\n{'#'*70}")
    print(f"Train: {len(y_tr)} samples / {len(np.unique(g_tr))} groups")
    print(f"Valid: {len(y_va)} samples / {len(np.unique(g_va))} groups")

    pearson = PearsonFilter(threshold=0.9)
    p_idx, p_names = pearson.fit(X_tr, feature_names)
    print(f"Pearson: {len(feature_names)} -> {len(p_names)} features")
    X_tr_p = X_tr[:, p_idx]
    X_va_p = X_va[:, p_idx]

    aug = DataAugmentor(augment_factor=3.0, random_state=seed)
    X_tr_aug, y_tr_aug = aug.augment_training_data(X_tr_p, y_tr)
    n_orig = len(X_tr_p)
    n_new = len(X_tr_aug) - n_orig
    g_tr_aug = list(g_tr)
    for _ in range(n_new):
        g_tr_aug.append(g_tr[np.random.randint(n_orig)])
    g_tr_aug = np.array(g_tr_aug)
    print(f"Augment: {n_orig} -> {len(y_tr_aug)} samples")

    ga = GAFeatureSelectorGroup(
        X_train=X_tr_aug, y_train=y_tr_aug, groups_train=g_tr_aug,
        feature_names=p_names, population_size=40, n_generations=30,
        min_features=6, max_features=10, random_state=seed)
    ga_feats_local, ga_fit = ga.run(verbose=verbose_ga)
    final_idx = [p_idx[i] for i in ga_feats_local]
    final_names = [feature_names[i] for i in final_idx]
    print(f"GA: selected {len(final_idx)} features")

    X_tr_f = X_tr_aug[:, ga_feats_local]
    X_va_f = X_va[:, final_idx]

    scaler = StandardScaler()
    X_tr_s = scaler.fit_transform(X_tr_f)
    X_va_s = scaler.transform(X_va_f)

    zoo = get_model_zoo(seed)
    grids = get_param_grids()
    preds, models, params = {}, {}, {}
    for name, base in zoo.items():
        if name in grids:
            gs = GridSearchCV(base, grids[name], cv=5,
                              scoring='r2', n_jobs=-1)
            gs.fit(X_tr_s, y_tr_aug)
            best = gs.best_estimator_
            params[name] = gs.best_params_
        else:
            base.fit(X_tr_s, y_tr_aug)
            best = base
            params[name] = {}
        preds[name] = best.predict(X_va_s)
        models[name] = best
        r2 = r2_score(y_va, preds[name])
        print(f"  {name:<16} fold R2 = {r2:.4f}")

    return preds, models, params, final_names


# =====================================================================
# 7) Retrain all 7 models on full data, save all pkl + training data npy
# =====================================================================
def train_and_save_all_models(processor, save_dir,
                               random_state=69, augment_factor=3.0):
    """
    Run once on all data (Pearson -> augmentation -> GA -> 7 models),
    save 7 model pkl files + scaler + feature_info.pkl + training data npy.
    """
    print(f"\n{'='*70}")
    print("Retrain 7 models on ALL data and save pkl files")
    print(f"{'='*70}")
    os.makedirs(save_dir, exist_ok=True)

    X, y, groups = processor.X, processor.y, processor.groups
    feature_names = processor.feature_names

    # 1) Pearson
    pearson = PearsonFilter(threshold=0.9)
    p_idx, p_names = pearson.fit(X, feature_names)
    print(f"Pearson: {len(feature_names)} -> {len(p_names)} features")
    X_p = X[:, p_idx]

    # 2) Augmentation
    np.random.seed(random_state)
    random.seed(random_state)
    aug = DataAugmentor(augment_factor=augment_factor,
                        random_state=random_state)
    X_aug, y_aug = aug.augment_training_data(X_p, y)
    n_orig = len(X_p)
    n_new = len(X_aug) - n_orig
    g_aug = list(groups)
    for _ in range(n_new):
        g_aug.append(groups[np.random.randint(n_orig)])
    g_aug = np.array(g_aug)
    print(f"Augment: {n_orig} -> {len(y_aug)} samples")

    # 3) GA
    ga = GAFeatureSelectorGroup(
        X_train=X_aug, y_train=y_aug, groups_train=g_aug,
        feature_names=p_names, population_size=40, n_generations=30,
        min_features=6, max_features=10, random_state=random_state)
    ga_feats_local, ga_fit = ga.run(verbose=True)
    final_idx = [p_idx[k] for k in ga_feats_local]
    final_names = [feature_names[i] for i in final_idx]
    print(f"\nGA selected {len(final_idx)} features:")
    for i, (idx, name) in enumerate(zip(final_idx, final_names), 1):
        print(f"  {i:2d}. [{idx:3d}] {name}")

    X_final = X_aug[:, ga_feats_local]

    # 4) Scaling
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_final)

    # 5) Train 7 models and save pkl
    zoo = get_model_zoo(random_state)
    grids = get_param_grids()
    trained_models, cv_scores = {}, {}
    for name, base in zoo.items():
        print(f"\n--- {name} ---")
        if name in grids:
            gs = GridSearchCV(base, grids[name], cv=5,
                              scoring='r2', n_jobs=-1)
            gs.fit(X_scaled, y_aug)
            trained_models[name] = gs.best_estimator_
            cv_scores[name] = float(gs.best_score_)
            print(f"  best params: {gs.best_params_}")
            print(f"  full-data CV R2: {gs.best_score_:.4f}")
        else:
            base.fit(X_scaled, y_aug)
            trained_models[name] = base
            cv_scores[name] = float('nan')
            print(f"  fitted (no grid)")

    # Save all model pkl files
    for name, model in trained_models.items():
        joblib.dump(model, os.path.join(save_dir, f"{name}_model.pkl"))
        print(f"  saved {name}_model.pkl")
    joblib.dump(scaler, os.path.join(save_dir, "scaler.pkl"))
    print(f"  saved scaler.pkl")

    # ===== Save augmented training data (for SHAP analysis) =====
    np.save(os.path.join(save_dir, "X_train_aug_pearson.npy"), X_aug)
    np.save(os.path.join(save_dir, "y_train_aug.npy"), y_aug)
    np.save(os.path.join(save_dir, "ga_selected_indices_in_pearson.npy"),
            np.array(ga_feats_local, dtype=int))
    print(f"  saved X_train_aug_pearson.npy / y_train_aug.npy")

    # feature_info.pkl
    feature_info = {
        'final_features': final_idx,
        'final_feature_names': final_names,
        'pearson_indices': p_idx,
        'pearson_names': p_names,
        'all_original_feature_names': feature_names,
        'n_features': len(final_idx),
        'model_names': list(trained_models.keys()),
        'augment_factor': augment_factor,
        'random_state': random_state,
        'full_data_cv_r2': {k: (float(v) if not np.isnan(v) else None)
                            for k, v in cv_scores.items()},
        'n_original_samples': int(n_orig),
        'n_augmented_samples': int(len(y_aug)),
    }
    with open(os.path.join(save_dir, "feature_info.pkl"), 'wb') as f:
        pickle.dump(feature_info, f)
    print(f"  saved feature_info.pkl")

    pd.DataFrame({
        'Index': range(1, len(final_names) + 1),
        'Feature_ID': final_idx,
        'Feature_Name': final_names,
    }).to_csv(os.path.join(save_dir, "Final_Selected_Features.csv"),
              index=False, encoding='utf-8-sig')

    print(f"\nAll models saved to: {save_dir}")
    return save_dir, trained_models, scaler, feature_info


# =====================================================================
# 8) Predictor (load pkl to predict new molecules)
# =====================================================================
class FinalPredictor:
    def __init__(self, model_dir):
        self.model_dir = model_dir
        with open(os.path.join(model_dir, "feature_info.pkl"), 'rb') as f:
            self.info = pickle.load(f)
        self.final_features = self.info['final_features']
        self.scaler = joblib.load(os.path.join(model_dir, "scaler.pkl"))
        self.models = {}
        for name in self.info['model_names']:
            p = os.path.join(model_dir, f"{name}_model.pkl")
            if os.path.exists(p):
                self.models[name] = joblib.load(p)
        print(f"FinalPredictor loaded: {len(self.models)} models "
              f"from {model_dir}")

    def _extract_monomer_features(self, smiles):
        try:
            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                return None
            f = []
            f.append(Descriptors.MolWt(mol))
            f.append(Descriptors.NumRotatableBonds(mol))
            f.append(mol.GetNumHeavyAtoms())
            f.append(Descriptors.TPSA(mol))
            f.append(Crippen.MolLogP(mol))
            f.append(Descriptors.NumHDonors(mol))
            f.append(Descriptors.NumHAcceptors(mol))
            arom = sum(1 for a in mol.GetAtoms() if a.GetIsAromatic())
            ha = mol.GetNumHeavyAtoms()
            f.append(arom / max(ha, 1))
            f.append(Descriptors.RingCount(mol))
            rot = Descriptors.NumRotatableBonds(mol)
            f.append((ha - rot) / max(ha, 1))
            f.append(Descriptors.TPSA(mol) / max(Descriptors.MolWt(mol), 1))
            f.append(Descriptors.Chi0(mol))
            f.append(Crippen.MolMR(mol))
            f.append((ha ** (1/3)) / max(rot + 1, 1))
            f.append(rot / max(ha, 1))
            return np.array(f)
        except Exception:
            return None

    def _extract_polymer_features(self, smiles_list, ratios=None):
        mono_feats, valid_idx = [], []
        for k, s in enumerate(smiles_list):
            f = self._extract_monomer_features(s)
            if f is not None:
                mono_feats.append(f); valid_idx.append(k)
        if not mono_feats:
            return None
        mf = np.array(mono_feats)
        if ratios is None:
            r = np.ones(len(mono_feats))
        else:
            r = np.array([ratios[i] for i in valid_idx if i < len(ratios)],
                         dtype=float)
            if len(r) != len(mono_feats):
                r = np.ones(len(mono_feats))
        if r.sum() <= 0:
            r = np.ones(len(mono_feats))
        r = r / r.sum()

        pf = []
        n_mono = mf.shape[0]
        for i in range(mf.shape[1]):
            pf.append(float(np.sum(mf[:, i] * r)))
        if n_mono > 1:
            for i in range(min(10, mf.shape[1])):
                mu = np.sum(mf[:, i] * r)
                var = np.sum(r * (mf[:, i] - mu) ** 2)
                pf.append(float(np.sqrt(var)))
        else:
            pf.extend([0.0] * 10)
        for i in range(min(5, mf.shape[1])):
            pf.append(float(np.max(mf[:, i])))
        for i in range(min(5, mf.shape[1])):
            pf.append(float(np.min(mf[:, i])))
        for i in range(min(5, mf.shape[1])):
            pf.append(float(np.max(mf[:, i]) - np.min(mf[:, i])))
        mw_m   = float(np.sum(mf[:, 0] * r))
        rot_m  = float(np.sum(mf[:, 1] * r))
        tpsa_m = float(np.sum(mf[:, 3] * r))
        arom_m = float(np.sum(mf[:, 7] * r))
        rig_m  = float(np.sum(mf[:, 9] * r))
        pf.append(mw_m * rig_m)
        pf.append(mw_m * arom_m)
        pf.append(rig_m * arom_m)
        pf.append(tpsa_m / max(rot_m, 0.1))
        pf.append(mw_m / max(rot_m, 0.1))
        pf.append(float(n_mono))
        pf.append(float(np.sum(mf[:, 0])))
        pf.append(float(np.sum(mf[:, 7])))
        return np.array(pf)

    def predict_one(self, smiles_list, ratios=None):
        feats = self._extract_polymer_features(smiles_list, ratios)
        if feats is None:
            return None
        x = feats[self.final_features].reshape(1, -1)
        x = self.scaler.transform(x)
        out = {name: float(m.predict(x)[0]) for name, m in self.models.items()}
        out['Avg'] = float(np.mean(list(out.values())))
        return out

    def predict_dataframe(self, df, out_csv=None, best_model_name=None):
        monomer_cols, ratio_cols = [], []
        for c in df.columns:
            s = str(c)
            if re.search(r'(monomer|smiles)', s, re.IGNORECASE) and \
               not re.search(r'ratio', s, re.IGNORECASE):
                monomer_cols.append(c)
            elif re.search(r'(ratio)', s, re.IGNORECASE):
                ratio_cols.append(c)

        def _k(c):
            m = re.search(r'(\d+)', str(c))
            return int(m.group(1)) if m else 0
        monomer_cols = sorted(monomer_cols, key=_k)
        ratio_cols = sorted(ratio_cols, key=_k)

        rows = []
        for _, row in df.iterrows():
            smis, rs = [], []
            for mc, rc in zip(monomer_cols, ratio_cols):
                v = row[mc]
                if pd.isna(v):
                    continue
                v = str(v).strip()
                if not v or v.lower() == 'nan':
                    continue
                smis.append(v)
                if pd.notna(row[rc]):
                    try:
                        rs.append(float(row[rc]))
                    except Exception:
                        rs.append(1.0)
                else:
                    rs.append(1.0)
            if not smis:
                continue
            preds = self.predict_one(smis, rs if rs else None)
            if preds is None:
                continue
            out = {c: row[c] for c in df.columns}
            for k, v in preds.items():
                out[f'{k}_Pred_Tg'] = round(v, 2)
            if best_model_name and best_model_name in preds:
                out['BestModel_Pred_Tg'] = round(preds[best_model_name], 2)
            rows.append(out)

        res = pd.DataFrame(rows)
        if out_csv:
            res.to_csv(out_csv, index=False, encoding='utf-8-sig')
            print(f"Saved predictions -> {out_csv}")
        return res


# =====================================================================
# 9) Main
# =====================================================================
def main():
    print("=" * 70)
    print("Nested GroupKFold Evaluation (adapted to LCP-Tg0110.xlsx)")
    print("=" * 70)

    TRAIN_FILE = "Your data path"
    PREDICT_FILE = "Selected_Molecules.xlsx"
    RANDOM_STATE = 69
    N_OUTER = 5

    out_dir = f"NestedCV_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.makedirs(out_dir, exist_ok=True)

    processor = GroupDataProcessor(TRAIN_FILE, sheet_name=0)
    processor.load_and_extract_features()
    X, y, groups = processor.X, processor.y, processor.groups
    feature_names = processor.feature_names

    model_names = list(get_model_zoo(RANDOM_STATE).keys())
    oof_pred = {m: np.full(len(y), np.nan) for m in model_names}
    oof_fold = np.zeros(len(y), dtype=int)

    all_feats, all_params = [], []
    gkf = GroupKFold(n_splits=N_OUTER)

    for k, (tr, va) in enumerate(gkf.split(X, y, groups=groups), start=1):
        oof_fold[va] = k
        preds_k, _, params_k, feats_k = run_one_fold(
            X[tr], y[tr], groups[tr], X[va], y[va], groups[va],
            feature_names, seed=RANDOM_STATE + k, fold_id=k)
        for m in model_names:
            oof_pred[m][va] = preds_k[m]
        all_feats.append(feats_k)
        all_params.append(params_k)

    # ---- Summarize OOF ----
    print(f"\n{'='*70}\nNESTED-CV OOF PERFORMANCE\n{'='*70}")
    rows = []
    for m in model_names:
        p = oof_pred[m]
        r2 = r2_score(y, p)
        rmse = np.sqrt(mean_squared_error(y, p))
        mae = mean_absolute_error(y, p)
        rows.append({'Model': m, 'NestedCV_R2': r2,
                     'NestedCV_RMSE': rmse, 'NestedCV_MAE': mae})
        print(f"{m:<16}  R2={r2:.4f}  RMSE={rmse:.2f}  MAE={mae:.2f}")

    res_df = pd.DataFrame(rows).sort_values('NestedCV_R2', ascending=False)
    res_df.to_csv(os.path.join(out_dir, "NestedCV_Model_Performance.csv"),
                  index=False, encoding='utf-8-sig')

    oof_df = pd.DataFrame({'Group': groups, 'Outer_Fold': oof_fold, 'Tg_True': y})
    for m in model_names:
        oof_df[f'{m}_OOF_Pred'] = oof_pred[m]
        oof_df[f'{m}_Residual'] = y - oof_pred[m]
    oof_df.to_csv(os.path.join(out_dir, "NestedCV_OOF_Predictions.csv"),
                  index=False, encoding='utf-8-sig')

    feat_rows = []
    for k, feats in enumerate(all_feats, start=1):
        for f in feats:
            feat_rows.append({'Outer_Fold': k, 'Selected_Feature': f})
    pd.DataFrame(feat_rows).to_csv(
        os.path.join(out_dir, "NestedCV_Selected_Features_PerFold.csv"),
        index=False, encoding='utf-8-sig')

    with open(os.path.join(out_dir, "NestedCV_Params_PerFold.pkl"), 'wb') as f:
        pickle.dump({'params': all_params, 'features': all_feats}, f)

    best = res_df.iloc[0]['Model']
    p = oof_pred[best]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
    ax[0].scatter(y, p, s=40, alpha=0.75)
    lo, hi = min(y.min(), p.min()), max(y.max(), p.max())
    ax[0].plot([lo, hi], [lo, hi], 'r--')
    ax[0].set_xlabel('True Tg (C)'); ax[0].set_ylabel('OOF Predicted Tg (C)')
    ax[0].set_title(f"{best} Nested-CV\nR2={r2_score(y, p):.4f}")
    ax[0].grid(alpha=0.3)
    ax[1].hist(y - p, bins=15, color='steelblue', edgecolor='black', alpha=0.8)
    ax[1].axvline(0, color='r', ls='--')
    ax[1].set_xlabel('Residual (C)'); ax[1].set_ylabel('Count')
    ax[1].set_title('OOF residuals'); ax[1].grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "NestedCV_OOF_Plot.png"), dpi=300)
    plt.close()

    print(f"\nNested-CV outputs: {out_dir}")

    # ============================================================
    # Retrain 7 models on full data and save all pkl (with npy)
    # ============================================================
    final_model_dir = os.path.join(
        out_dir, f"FinalModels_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    final_model_dir, trained_models, scaler, feat_info = train_and_save_all_models(
        processor, final_model_dir,
        random_state=RANDOM_STATE, augment_factor=3.0)

    feat_info['best_among_compared_models'] = best
    feat_info['nested_cv_r2_best'] = float(res_df.iloc[0]['NestedCV_R2'])
    feat_info['nested_cv_rmse_best'] = float(res_df.iloc[0]['NestedCV_RMSE'])
    feat_info['nested_cv_mae_best'] = float(res_df.iloc[0]['NestedCV_MAE'])
    with open(os.path.join(final_model_dir, "feature_info.pkl"), 'wb') as f:
        pickle.dump(feat_info, f)

    bp = os.path.join(final_model_dir, f"{best}_model.pkl")
    if os.path.exists(bp):
        joblib.dump(joblib.load(bp),
                    os.path.join(final_model_dir, "best_model.pkl"))
        print(f"best_model.pkl saved (= {best})")

    if os.path.exists(PREDICT_FILE):
        print(f"\n{'='*70}\nPredicting: {PREDICT_FILE}\n{'='*70}")
        pred = FinalPredictor(final_model_dir)
        pred.predict_dataframe(
            pd.read_excel(PREDICT_FILE),
            out_csv=os.path.join(out_dir, "Predicted_Tg.csv"),
            best_model_name=best)
    else:
        print(f"\n[Info] {PREDICT_FILE} not found; skipping prediction.")

    print(f"\n{'='*70}\nDONE\n"
          f"  Nested-CV table : {out_dir}/NestedCV_Model_Performance.csv\n"
          f"  Deployment dir  : {final_model_dir}\n"
          f"  All model pkls  : {final_model_dir}/*_model.pkl\n"
          f"  Training npy    : {final_model_dir}/X_train_aug_pearson.npy\n"
          f"  New predictions : {out_dir}/Predicted_Tg.csv (if input exists)\n"
          f"{'='*70}")


if __name__ == "__main__":
    main()