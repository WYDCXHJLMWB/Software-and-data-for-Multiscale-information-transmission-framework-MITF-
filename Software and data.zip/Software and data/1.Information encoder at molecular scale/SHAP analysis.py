# -*- coding: utf-8 -*-
"""
Independent SHAP Analysis Script - For analyzing trained LightGBM model

Data source priority:
  1) X_train_aug_pearson.npy + y_train_aug.npy in model_dir
  2) Rebuild from raw Excel using the same
     Pearson -> Augment pipeline as training
"""

import os
import re
import random
import pickle
import warnings
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import shap
import joblib
import gc

from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen
from sklearn.neighbors import NearestNeighbors

warnings.filterwarnings('ignore')

plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 12
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['xtick.labelsize'] = 11
plt.rcParams['ytick.labelsize'] = 11
plt.rcParams['legend.fontsize'] = 11
plt.rcParams['figure.titlesize'] = 16


# =====================================================================
# Feature extraction / Pearson / Augmentation (consistent with training)
# =====================================================================
class GroupDataProcessor:
    def __init__(self, data_file, sheet_name=0):
        self.data_file = data_file
        self.sheet_name = sheet_name
        self.df = None
        self.X = None
        self.y = None
        self.groups = None
        self.feature_names = []

    def _identify_columns(self):
        cols = list(self.df.columns)
        tg_col = None
        for c in cols:
            cl = str(c).lower().strip()
            if cl == 'tg' or 'glass' in cl:
                tg_col = c
                break
        monomer_cols, ratio_cols = [], []
        for c in cols:
            s = str(c)
            if (re.search(r'(monomer|smiles)', s, re.IGNORECASE)
                    and not re.search(r'ratio', s, re.IGNORECASE)):
                monomer_cols.append(c)
            elif re.search(r'(ratio)', s, re.IGNORECASE):
                ratio_cols.append(c)

        def _sort_key(c):
            m = re.search(r'(\d+)', str(c))
            return int(m.group(1)) if m else 0
        monomer_cols = sorted(monomer_cols, key=_sort_key)
        ratio_cols = sorted(ratio_cols, key=_sort_key)

        id_col = None
        for c in cols:
            cl = str(c).lower().strip()
            if cl == 'polymer_id' or cl == 'id':
                id_col = c
                break
        if tg_col is None:
            tg_col = cols[1] if len(cols) > 1 else cols[0]
        if len(monomer_cols) == 0:
            raise ValueError("No monomer column identified; please check headers.")
        return tg_col, monomer_cols, ratio_cols, id_col

    def load_and_extract_features(self):
        self.df = pd.read_excel(self.data_file, sheet_name=self.sheet_name)
        tg_col, monomer_cols, ratio_cols, id_col = self._identify_columns()
        self.df = self.df.dropna(subset=[tg_col])
        self.df = self.df[pd.to_numeric(self.df[tg_col], errors='coerce').notna()]

        all_features, all_tg, all_groups = [], [], []
        for idx, row in self.df.iterrows():
            try:
                tg = float(row[tg_col])
                monomers, ratios = [], []
                for m_col, r_col in zip(monomer_cols, ratio_cols):
                    smi = row[m_col]
                    if pd.isna(smi):
                        continue
                    smi = str(smi).strip()
                    if not smi or smi.lower() == 'nan':
                        continue
                    monomers.append(smi)
                    if r_col is not None and pd.notna(row[r_col]):
                        try:
                            ratios.append(float(row[r_col]))
                        except Exception:
                            ratios.append(1.0)
                    else:
                        ratios.append(1.0)
                if not monomers:
                    continue
                mono_feats, valid_idx = [], []
                for k, s in enumerate(monomers):
                    f = self._extract_monomer_features(s)
                    if f is not None:
                        mono_feats.append(f)
                        valid_idx.append(k)
                if not mono_feats:
                    continue
                mf = np.array(mono_feats)
                r = np.array([ratios[i] for i in valid_idx], dtype=float)
                if r.sum() <= 0:
                    r = np.ones(len(mono_feats))
                r = r / r.sum()
                pf = self._calculate_enhanced_polymer_features(mf, r)
                if id_col is not None and pd.notna(row[id_col]):
                    group = f"PID_{row[id_col]}"
                else:
                    group = '|'.join(sorted(monomers))
                all_features.append(pf)
                all_tg.append(tg)
                all_groups.append(group)
            except Exception:
                continue
        if not all_features:
            raise ValueError("No valid samples after feature extraction.")
        self.X = np.array(all_features)
        self.y = np.array(all_tg)
        self.groups = np.array(all_groups)
        self._generate_enhanced_feature_names()
        return self

    def _extract_monomer_features(self, smiles):
        try:
            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                return None
            f = []
            f.append(Descriptors.MolWt(mol))
            f.append(Descriptors.NumRotatableBonds(mol))
            f.append(mol.GetNumHeavyAtoms())
            f.append(Descriptors.TPSA(mol))
            f.append(Crippen.MolLogP(mol))
            f.append(Descriptors.NumHDonors(mol))
            f.append(Descriptors.NumHAcceptors(mol))
            arom = sum(1 for a in mol.GetAtoms() if a.GetIsAromatic())
            ha = mol.GetNumHeavyAtoms()
            f.append(arom / max(ha, 1))
            f.append(Descriptors.RingCount(mol))
            rot = Descriptors.NumRotatableBonds(mol)
            f.append((ha - rot) / max(ha, 1))
            f.append(Descriptors.TPSA(mol) / max(Descriptors.MolWt(mol), 1))
            f.append(Descriptors.Chi0(mol))
            f.append(Crippen.MolMR(mol))
            f.append((ha ** (1/3)) / max(rot + 1, 1))
            f.append(rot / max(ha, 1))
            return np.array(f)
        except Exception:
            return None

    def _calculate_enhanced_polymer_features(self, mono_features, ratios):
        pf = []
        n_mono = mono_features.shape[0]
        for i in range(mono_features.shape[1]):
            pf.append(float(np.sum(mono_features[:, i] * ratios)))
        if n_mono > 1:
            for i in range(min(10, mono_features.shape[1])):
                mu = np.sum(mono_features[:, i] * ratios)
                var = np.sum(ratios * (mono_features[:, i] - mu) ** 2)
                pf.append(float(np.sqrt(var)))
        else:
            pf.extend([0.0] * 10)
        for i in range(min(5, mono_features.shape[1])):
            pf.append(float(np.max(mono_features[:, i])))
        for i in range(min(5, mono_features.shape[1])):
            pf.append(float(np.min(mono_features[:, i])))
        for i in range(min(5, mono_features.shape[1])):
            pf.append(float(np.max(mono_features[:, i]) - np.min(mono_features[:, i])))
        mw_m = float(np.sum(mono_features[:, 0] * ratios))
        rot_m = float(np.sum(mono_features[:, 1] * ratios))
        tpsa_m = float(np.sum(mono_features[:, 3] * ratios))
        arom_m = float(np.sum(mono_features[:, 7] * ratios))
        rig_m = float(np.sum(mono_features[:, 9] * ratios))
        pf.append(mw_m * rig_m)
        pf.append(mw_m * arom_m)
        pf.append(rig_m * arom_m)
        pf.append(tpsa_m / max(rot_m, 0.1))
        pf.append(mw_m / max(rot_m, 0.1))
        pf.append(float(n_mono))
        pf.append(float(np.sum(mono_features[:, 0])))
        pf.append(float(np.sum(mono_features[:, 7])))
        return np.array(pf)

    def _generate_enhanced_feature_names(self):
        base = ['MolecularWeight', 'RotatableBonds', 'HeavyAtoms', 'TPSA', 'LogP',
                'HDonors', 'HAcceptors', 'AromaticRatio', 'RingCount',
                'RigidityIndex', 'PolarityIndex', 'TopologicalIndex',
                'MolarRefractivity', 'ShapeIndex', 'FlexibilityIndex']
        self.feature_names = []
        for n in base:
            self.feature_names.append(f"Mean_{n}")
        for i in range(10):
            self.feature_names.append(f"Std_{base[i]}")
        for i in range(5):
            self.feature_names.append(f"Max_{base[i]}")
        for i in range(5):
            self.feature_names.append(f"Min_{base[i]}")
        for i in range(5):
            self.feature_names.append(f"Range_{base[i]}")
        self.feature_names.extend(['MW_x_Rigidity', 'MW_x_Aromaticity',
                                   'Rigidity_x_Aromaticity',
                                   'Polarity_Flexibility', 'MW_Flexibility'])
        self.feature_names.extend(['MonomerCount', 'TotalMW', 'TotalAromaticity'])


class PearsonFilter:
    def __init__(self, threshold=0.9):
        self.threshold = threshold

    def fit(self, X, feature_names):
        n = X.shape[1]
        with np.errstate(invalid='ignore', divide='ignore'):
            corr = np.corrcoef(X.T)
        corr = np.nan_to_num(corr, nan=0.0)
        remove = set()
        for i in range(n):
            for j in range(i + 1, n):
                if abs(corr[i, j]) > self.threshold:
                    if j not in remove and i not in remove:
                        remove.add(j)
        idx = [i for i in range(n) if i not in remove]
        names = [feature_names[i] for i in idx]
        return idx, names


class DataAugmentor:
    def __init__(self, augment_factor=3.0, random_state=42):
        self.augment_factor = augment_factor
        np.random.seed(random_state)
        random.seed(random_state)

    def add_gaussian_noise(self, X, noise_level=0.02):
        X_std = np.std(X, axis=0)
        return X + np.random.normal(0, noise_level * X_std, X.shape)

    def add_uniform_noise(self, X, noise_level=0.02):
        X_range = np.max(X, axis=0) - np.min(X, axis=0)
        return X + np.random.uniform(-noise_level * X_range,
                                     noise_level * X_range, X.shape)

    def smote_like_augmentation(self, X, y, k=5, n_synthetic=None):
        n = len(X)
        if n_synthetic is None:
            n_synthetic = n
        nn = NearestNeighbors(n_neighbors=min(k + 1, n), metric='euclidean')
        nn.fit(X)
        _, indices = nn.kneighbors(X)
        Xa, ya = [], []
        for _ in range(n_synthetic):
            i = np.random.randint(n)
            j = np.random.choice(indices[i, 1:])
            a = np.random.uniform(0.3, 0.7)
            Xa.append(a * X[i] + (1 - a) * X[j])
            ya.append(a * y[i] + (1 - a) * y[j])
        return np.array(Xa), np.array(ya)

    def augment_training_data(self, X_train, y_train):
        n0 = len(X_train)
        target = int(n0 * self.augment_factor)
        n_new = target - n0
        if n_new <= 0:
            return X_train, y_train
        n1 = n_new // 3
        n2 = n_new // 3
        n3 = n_new - n1 - n2
        Xs, ys = [X_train], [y_train]
        if n1 > 0:
            Xs.append(self.add_gaussian_noise(X_train[:n1], 0.02))
            ys.append(y_train[:n1])
        if n2 > 0:
            Xs.append(self.add_uniform_noise(X_train[:n2], 0.02))
            ys.append(y_train[:n2])
        if n3 > 0:
            Xa, ya = self.smote_like_augmentation(X_train, y_train, 5, n3)
            Xs.append(Xa); ys.append(ya)
        return np.vstack(Xs), np.concatenate(ys)


# =====================================================================
# SHAP Analyzer
# =====================================================================
class SHAPAnalyzer:
    def __init__(self, model_dir, model_filename="LightGBM_model.pkl",
                 raw_excel_path=None):
        self.model_dir = model_dir
        self.model_filename = model_filename
        self.raw_excel_path = raw_excel_path

        # Canonical English feature names (used as fallback / alias resolution)
        self.english_feature_names = [
            "Mean_MolecularWeight", "Mean_RotatableBonds", "Mean_HeavyAtomCount",
            "Mean_TPSA", "Mean_LogP", "Mean_HBondDonors", "Mean_HBondAcceptors",
            "Mean_AromaticRatio", "Mean_RingCount", "Mean_RigidityIndex",
            "Mean_PolarityIndex", "Mean_TopologicalIndex", "Mean_MolarRefractivity",
            "Mean_ShapeIndex", "Mean_FlexibilityIndex", "Std_MolecularWeight",
            "Std_RotatableBonds", "Std_HeavyAtomCount", "Std_TPSA", "Std_LogP",
            "Std_HBondDonors", "Std_HBondAcceptors", "Std_AromaticRatio",
            "Std_RingCount", "Std_RigidityIndex", "Max_MolecularWeight",
            "Max_RotatableBonds", "Max_HeavyAtomCount", "Max_TPSA", "Max_LogP",
            "Min_MolecularWeight", "Min_RotatableBonds", "Min_HeavyAtomCount",
            "Min_TPSA", "Min_LogP", "Range_MolecularWeight", "Range_RotatableBonds",
            "Range_HeavyAtomCount", "Range_TPSA", "Range_LogP",
            "MolecularWeight×Rigidity", "MolecularWeight×Aromaticity",
            "Rigidity×Aromaticity", "Polarity/Flexibility", "MolecularWeight/Flexibility",
            "MonomerCount", "TotalMolecularWeight", "TotalAromaticity"
        ]

        self.model_path = os.path.join(model_dir, model_filename)
        self.scaler_path = os.path.join(model_dir, "scaler.pkl")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_dir = os.path.join(
            model_dir, f"shap_analysis_lightgbm_{timestamp}")
        os.makedirs(self.output_dir, exist_ok=True)

        self.feature_info = {}
        self.final_features = []
        self.final_feature_names = []
        self.pearson_names = []
        self.pearson_indices = []
        self.all_original_feature_names = []
        self.best_model_name = "LightGBM"
        self.model = None
        self.scaler = None
        self.X_train_aug = None
        self.y_train_aug = None
        self.X_train_aug_pearson = None
        self.final_indices_in_pearson = []
        self.explainer = None
        self.shap_values_train = None
        self.X_train_sample = None
        self.y_train_sample = None
        self.expected_value = None

        print("=" * 80)
        print("Polymer Tg Prediction Model - LightGBM Model SHAP Analysis")
        print("=" * 80)
        print(f"Model directory : {model_dir}")
        print(f"Output directory: {self.output_dir}")
        print("=" * 80)

        self._load_model_and_data()

    def _load_model_and_data(self):
        print("\n" + "-" * 50)
        print("Loading model and feature info")
        print("-" * 50)

        info_path = os.path.join(self.model_dir, "feature_info.pkl")
        if os.path.exists(info_path):
            try:
                with open(info_path, 'rb') as f:
                    self.feature_info = pickle.load(f)
                self.final_features = self.feature_info.get('final_features', [])
                self.final_feature_names = self.feature_info.get('final_feature_names', [])
                self.pearson_names = self.feature_info.get('pearson_names', [])
                self.pearson_indices = self.feature_info.get('pearson_indices', [])
                self.all_original_feature_names = self.feature_info.get(
                    'all_original_feature_names', [])
                self.best_model_name = self.feature_info.get(
                    'best_among_compared_models',
                    self.feature_info.get('best_model_name', 'LightGBM'))
                # Normalize feature names: if a name is not in the canonical
                # English list, fall back to the canonical name at the same
                # position in all_original_feature_names (for artifacts that
                # were created with legacy names).
                converted = []
                for name in self.final_feature_names:
                    if name in self.english_feature_names:
                        converted.append(name)
                    elif name in self.all_original_feature_names:
                        pos = self.all_original_feature_names.index(name)
                        if pos < len(self.english_feature_names):
                            converted.append(self.english_feature_names[pos])
                        else:
                            converted.append(name)
                    else:
                        converted.append(name)
                self.final_feature_names = converted
                print("✅ feature_info.pkl loaded")
                print(f"Best model: {self.best_model_name}")
            except Exception as e:
                print(f"⚠️ Error loading feature_info.pkl: {e}")
        else:
            print("⚠️ feature_info.pkl not found; will infer from model")

        if not os.path.exists(self.model_path):
            cands = [f for f in os.listdir(self.model_dir)
                     if 'LightGBM' in f and f.endswith('.pkl')]
            if cands:
                self.model_path = os.path.join(self.model_dir, cands[0])
            elif os.path.exists(os.path.join(self.model_dir, "best_model.pkl")):
                self.model_path = os.path.join(self.model_dir, "best_model.pkl")
            else:
                raise FileNotFoundError(f"Model not found: {self.model_path}")
        self.model = joblib.load(self.model_path)
        print(f"✅ Model loaded: {type(self.model).__name__}")

        if not os.path.exists(self.scaler_path):
            raise FileNotFoundError(f"Scaler not found: {self.scaler_path}")
        self.scaler = joblib.load(self.scaler_path)
        print("✅ Scaler loaded")

        if not self.final_features:
            n_in = getattr(self.model, 'n_features_in_', None)
            if n_in is None:
                n_in = len(self.final_feature_names) or 10
            self.final_features = list(range(n_in))
            self.final_feature_names = self.english_feature_names[:n_in]

        self._load_training_data()

        print(f"\n[Final Selected Features] ({len(self.final_feature_names)}):")
        for i, (idx, name) in enumerate(zip(self.final_features,
                                            self.final_feature_names)):
            print(f"  {i+1:2d}. [Original idx {idx:3d}] {name}")

    def _load_training_data(self):
        print("\n" + "-" * 50)
        print("Loading training data")
        print("-" * 50)

        self.X_train_aug = None
        self.y_train_aug = None
        self.X_train_aug_pearson = None
        self.final_indices_in_pearson = []

        x_aug_p = os.path.join(self.model_dir, "X_train_aug_pearson.npy")
        y_aug_p = os.path.join(self.model_dir, "y_train_aug.npy")
        if os.path.exists(x_aug_p) and os.path.exists(y_aug_p):
            try:
                X_aug = np.load(x_aug_p)
                y_aug = np.load(y_aug_p)
                self.X_train_aug_pearson = X_aug
                self.y_train_aug = y_aug
                self.final_indices_in_pearson = self._map_final_to_pearson()
                if self.final_indices_in_pearson:
                    self.X_train_aug = X_aug[:, self.final_indices_in_pearson]
                else:
                    self.X_train_aug = X_aug
                print(f"✅ Loaded X_train_aug_pearson.npy: "
                      f"{self.X_train_aug.shape}")
                return
            except Exception as e:
                print(f"⚠️ Failed to load .npy: {e}")
                self.X_train_aug = None
                self.y_train_aug = None

        x_aug_p = os.path.join(self.model_dir, "X_train_aug.npy")
        if os.path.exists(x_aug_p) and os.path.exists(y_aug_p):
            try:
                X_aug = np.load(x_aug_p)
                y_aug = np.load(y_aug_p)
                self.X_train_aug_pearson = X_aug
                self.y_train_aug = y_aug
                self.final_indices_in_pearson = self._map_final_to_pearson()
                if self.final_indices_in_pearson:
                    self.X_train_aug = X_aug[:, self.final_indices_in_pearson]
                else:
                    self.X_train_aug = X_aug
                print(f"✅ Loaded X_train_aug.npy: {self.X_train_aug.shape}")
                return
            except Exception as e:
                print(f"⚠️ Failed to load X_train_aug.npy: {e}")

        if self.raw_excel_path and os.path.exists(self.raw_excel_path):
            try:
                self._rebuild_from_excel(self.raw_excel_path)
                if self.X_train_aug is not None:
                    print(f"✅ Rebuilt training set from Excel: "
                          f"{self.X_train_aug.shape}")
                    return
            except Exception as e:
                print(f"⚠️ Rebuild from Excel failed: {e}")

        raise RuntimeError(
            "Unable to obtain training data. Please ensure the model "
            "directory contains X_train_aug_pearson.npy / y_train_aug.npy, "
            "or provide raw_excel_path to rebuild from raw Excel.")

    def _map_final_to_pearson(self):
        if not self.pearson_indices:
            return []
        pearson_list = list(self.pearson_indices)
        positions = []
        for feat_idx in self.final_features:
            if feat_idx in pearson_list:
                positions.append(pearson_list.index(feat_idx))
        if len(positions) != len(self.final_features):
            return []
        return positions

    def _rebuild_from_excel(self, excel_path):
        print(f"\nRebuilding training data from: {excel_path}")
        proc = GroupDataProcessor(excel_path, sheet_name=0)
        proc.load_and_extract_features()

        if not self.pearson_indices:
            pf = PearsonFilter(threshold=0.9)
            p_idx, p_names = pf.fit(proc.X, proc.feature_names)
        else:
            p_idx = list(self.pearson_indices)
            p_names = (self.pearson_names
                       if self.pearson_names
                       else [proc.feature_names[i] for i in p_idx])

        X_p = proc.X[:, p_idx]
        aug_factor = float(self.feature_info.get('augment_factor', 3.0))
        seed = int(self.feature_info.get('random_state', 42))
        aug = DataAugmentor(augment_factor=aug_factor, random_state=seed)
        X_aug, y_aug = aug.augment_training_data(X_p, proc.y)

        self.X_train_aug_pearson = X_aug
        self.y_train_aug = y_aug
        self.pearson_indices = p_idx
        self.pearson_names = p_names
        self.final_indices_in_pearson = self._map_final_to_pearson()
        if self.final_indices_in_pearson:
            self.X_train_aug = X_aug[:, self.final_indices_in_pearson]
        else:
            self.X_train_aug = X_aug

    def create_explainer(self):
        print("\n" + "-" * 50)
        print("Creating SHAP explainer")
        print("-" * 50)
        if self.X_train_aug is None:
            print("❌ No training data")
            return False
        model_type = type(self.model).__name__
        print(f"Model type: {model_type}")
        try:
            if any(k in model_type for k in
                   ['LGBM', 'LightGBM', 'RandomForest', 'ExtraTrees',
                    'GradientBoosting', 'DecisionTree', 'XGB', 'CatBoost']):
                print("Using TreeExplainer")
                self.explainer = shap.TreeExplainer(self.model)
            else:
                print("Using KernelExplainer")
                X_scaled = self.scaler.transform(self.X_train_aug)
                bg = X_scaled[:min(100, len(X_scaled))]
                self.explainer = shap.KernelExplainer(self.model.predict, bg)
            ev = getattr(self.explainer, 'expected_value', None)
            if ev is None:
                self.expected_value = (float(np.mean(self.y_train_aug))
                                       if self.y_train_aug is not None else 150.0)
            else:
                if hasattr(ev, '__iter__'):
                    ev = ev[0]
                self.expected_value = float(ev)
            print(f"✅ Explainer ready, baseline = {self.expected_value:.2f}°C")
            return True
        except Exception as e:
            print(f"❌ Explainer failed: {e}")
            return False

    def calculate_shap_values(self):
        print("\n" + "-" * 50)
        print("Calculating SHAP values")
        print("-" * 50)
        if self.explainer is None and not self.create_explainer():
            return False
        if self.X_train_aug is None:
            print("❌ No training data")
            return False

        X_scaled = self.scaler.transform(self.X_train_aug)
        self.X_train_sample = X_scaled
        self.y_train_sample = self.y_train_aug
        print(f"Using training set: {self.X_train_sample.shape[0]} samples")
        try:
            if isinstance(self.explainer, shap.KernelExplainer):
                nsamples = min(100, len(self.X_train_sample))
                self.shap_values_train = self.explainer.shap_values(
                    self.X_train_sample, nsamples=nsamples)
            else:
                self.shap_values_train = self.explainer.shap_values(
                    self.X_train_sample)
            print(f"✅ SHAP values shape: {self.shap_values_train.shape}")

            if self.shap_values_train.shape[1] != len(self.final_feature_names):
                if self.shap_values_train.shape[1] < len(self.final_feature_names):
                    self.final_feature_names = \
                        self.final_feature_names[:self.shap_values_train.shape[1]]
                else:
                    for i in range(len(self.final_feature_names),
                                   self.shap_values_train.shape[1]):
                        self.final_feature_names.append(f"Feature_{i}")
                print("✅ Adjusted feature names to match SHAP values")
            return True
        except Exception as e:
            print(f"❌ Error calculating SHAP values: {e}")
            return False

    # ---------- Plotting (bottom-left Feature Importance box removed) ----------
    def plot_combined_shap(self, top_n=15):
        print(f"\nCreating combined SHAP plot (Top {top_n} features)...")
        if self.shap_values_train is None:
            print("❌ Please calculate SHAP values first")
            return None

        try:
            importance = np.abs(self.shap_values_train).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1][:top_n]
            sorted_features = [self.final_feature_names[i] for i in sorted_idx]
            sorted_shap = self.shap_values_train[:, sorted_idx]
            sorted_X = self.X_train_sample[:, sorted_idx]
            X_train_df = pd.DataFrame(sorted_X, columns=sorted_features)

            plt.rcParams['font.size'] = 72
            plt.rcParams['axes.labelsize'] = 82
            plt.rcParams['axes.titlesize'] = 92
            plt.rcParams['xtick.labelsize'] = 72
            plt.rcParams['ytick.labelsize'] = 72

            fig = plt.figure(figsize=(45, 28))

            shap.summary_plot(sorted_shap, X_train_df,
                              feature_names=sorted_features,
                              show=False, max_display=top_n, plot_size=None,
                              color_bar=True, cmap=plt.cm.coolwarm)

            ax = plt.gca()
            ax.set_title(r'SHAP value of Glass Transition Temperature ($T_g$)',
                         fontsize=92, fontweight='bold',
                         fontname='Times New Roman', pad=60)
            ax.set_xlabel('SHAP value (impact on model output)',
                          fontsize=82, fontweight='bold',
                          fontname='Times New Roman', labelpad=55)
            ax.set_ylabel('Features', fontsize=82, fontweight='bold',
                          fontname='Times New Roman', labelpad=55)
            ax.tick_params(axis='x', labelsize=72, pad=20)
            for label in ax.get_xticklabels():
                label.set_fontname('Times New Roman')
                label.set_fontsize(72)
                label.set_fontweight('bold')
            ax.tick_params(axis='y', labelsize=72, pad=20)
            for label in ax.get_yticklabels():
                label.set_fontname('Times New Roman')
                label.set_fontsize(72)
                label.set_fontweight('bold')

            for collection in ax.collections:
                if hasattr(collection, 'set_sizes'):
                    try:
                        collection.set_sizes([600])
                    except Exception:
                        pass

            # colorbar styling
            cbar_ax = None
            for fig_ax in fig.get_axes():
                if fig_ax != ax:
                    cbar_ax = fig_ax
                    break
            if cbar_ax is not None:
                try:
                    cbar_ax.set_ylabel('Feature value', fontsize=68,
                                       fontweight='bold',
                                       fontname='Times New Roman', labelpad=50)
                    cbar_ax.tick_params(labelsize=60)
                    for label in cbar_ax.get_yticklabels():
                        label.set_fontname('Times New Roman')
                        label.set_fontsize(60)
                        label.set_fontweight('bold')
                except Exception:
                    pass

            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['left'].set_linewidth(3)
            ax.spines['bottom'].set_linewidth(3)

            plt.tight_layout()
            save_path = os.path.join(self.output_dir,
                                     'shap_combined_plot_LightGBM.png')
            plt.savefig(save_path, dpi=300, bbox_inches='tight',
                        format='png', pad_inches=1.0)
            plt.close()
            gc.collect()
            print(f"   ✅ Combined plot saved: {save_path}")
            return fig
        except Exception as e:
            print(f"   ❌ Failed: {e}")
            return None

    def _save_feature_importance(self):
        if self.shap_values_train is None:
            return
        shap_abs_mean = np.abs(self.shap_values_train).mean(axis=0)
        indices = np.argsort(shap_abs_mean)[::-1]
        valid_indices = indices[:min(len(indices),
                                     len(self.final_feature_names))]
        df = pd.DataFrame({
            'Rank': range(1, len(valid_indices) + 1),
            'Feature Name': [self.final_feature_names[i] for i in valid_indices],
            'Mean |SHAP|': shap_abs_mean[valid_indices],
            'Relative Importance (%)': (shap_abs_mean[valid_indices] /
                                        shap_abs_mean.sum() * 100)
        })
        csv_path = os.path.join(self.output_dir,
                                'lightgbm_feature_importance.csv')
        df.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"✅ Feature importance saved: {csv_path}")

        shap_df = pd.DataFrame(self.shap_values_train,
                               columns=self.final_feature_names)
        shap_df['True Tg'] = self.y_train_sample
        shap_csv = os.path.join(self.output_dir, 'shap_values_train.csv')
        shap_df.to_csv(shap_csv, index=False, encoding='utf-8-sig')
        print(f"✅ SHAP values saved: {shap_csv}")

        train_df = pd.DataFrame(self.X_train_aug,
                                columns=self.final_feature_names)
        train_df['True Tg'] = self.y_train_aug
        train_csv = os.path.join(self.output_dir, 'training_data.csv')
        train_df.to_csv(train_csv, index=False, encoding='utf-8-sig')
        print(f"✅ Training data saved: {train_csv}")

    def _generate_text_report(self):
        report = []
        report.append("=" * 80)
        report.append("LightGBM Model - SHAP Analysis Report")
        report.append("=" * 80)
        report.append(f"Generation time: "
                      f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(f"Model directory: {self.model_dir}")
        report.append("")
        report.append("[Model Info]")
        report.append(f"Model type: {type(self.model).__name__}")
        report.append(f"Best model (per nested CV): {self.best_model_name}")
        fdcv = self.feature_info.get('full_data_cv_r2', {}) or {}
        if 'LightGBM' in fdcv and fdcv['LightGBM'] is not None:
            report.append(f"Full-data CV R² (LightGBM): {fdcv['LightGBM']:.4f}")
        if self.feature_info.get('nested_cv_r2_best') is not None:
            report.append(f"Nested CV R² (best): "
                          f"{self.feature_info['nested_cv_r2_best']:.4f}")
            report.append(f"Nested CV RMSE (best): "
                          f"{self.feature_info['nested_cv_rmse_best']:.2f}°C")
        report.append("")
        report.append("[Feature Information]")
        report.append(f"Final selected features: {len(self.final_feature_names)}")
        report.append("")
        if self.shap_values_train is not None:
            report.append("[Feature Importance Ranking (Top 10)]")
            shap_abs_mean = np.abs(self.shap_values_train).mean(axis=0)
            indices = np.argsort(shap_abs_mean)[::-1]
            for i, idx in enumerate(indices[:10]):
                if idx < len(self.final_feature_names):
                    report.append(f"{i+1:2d}. "
                                  f"{self.final_feature_names[idx]}: "
                                  f"{shap_abs_mean[idx]:.4f}")
            report.append("")
        report.append("[Baseline Value]")
        if self.expected_value is not None:
            report.append(f"Expected value: {self.expected_value:.2f}°C")
        else:
            report.append("Expected value: N/A")
        report.append("")
        report.append("[Training Data]")
        report.append(f"Training samples: "
                      f"{len(self.X_train_aug) if self.X_train_aug is not None else 0}")
        report.append(f"Features: {len(self.final_feature_names)}")
        report.append("")
        report.append("=" * 80)

        path = os.path.join(self.output_dir, 'lightgbm_shap_report.txt')
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report))
        print(f"✅ Text report saved: {path}")

    def _save_data_overview(self):
        overview = {
            'Training samples': len(self.X_train_aug)
                                if self.X_train_aug is not None else 0,
            'Training set Tg mean': float(np.mean(self.y_train_aug))
                                    if self.y_train_aug is not None else 0,
            'Training set Tg std': float(np.std(self.y_train_aug))
                                   if self.y_train_aug is not None else 0,
        }
        df = pd.DataFrame([overview])
        path = os.path.join(self.output_dir, 'data_overview.csv')
        df.to_csv(path, index=False, encoding='utf-8-sig')
        print(f"✅ Data overview saved: {path}")

    def generate_full_report(self):
        print("\n" + "=" * 80)
        print("Generating Complete SHAP Analysis Report")
        print("=" * 80)
        if not self.calculate_shap_values():
            print("❌ SHAP value calculation failed")
            return False
        self.plot_combined_shap(
            top_n=min(15, self.shap_values_train.shape[1]))
        self._save_feature_importance()
        self._generate_text_report()
        self._save_data_overview()
        print("\n" + "=" * 80)
        print(f"✅ SHAP analysis completed! Results saved to: "
              f"{self.output_dir}")
        print("=" * 80)
        return True


# =====================================================================
# Main
# =====================================================================
def main():
    # Model directory to analyze
    base_dir = r"Your model results file path"
    model_filename = "LightGBM_model.pkl"
    # Optional: rebuild training set from raw Excel if .npy files are missing
    raw_excel_path = r"Your data path"

    print("=" * 80)
    print("Polymer Tg Prediction Model - LightGBM Model SHAP Analysis")
    print("=" * 80)
    print(f"Base directory : {base_dir}")
    print(f"Model file     : {model_filename}")
    print(f"Raw Excel (opt): {raw_excel_path}")

    if not os.path.exists(base_dir):
        print(f"❌ Directory not found: {base_dir}")
        return

    model_full_path = os.path.join(base_dir, model_filename)
    if not os.path.exists(model_full_path):
        print(f"❌ Model file not found: {model_full_path}")
        pkls = [f for f in os.listdir(base_dir) if f.endswith('.pkl')]
        print(f"Available .pkl files: {pkls}")
        return

    try:
        analyzer = SHAPAnalyzer(base_dir,
                                model_filename=model_filename,
                                raw_excel_path=raw_excel_path)
        analyzer.generate_full_report()
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()