# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 18:04:04 2026

@author: ma'wei'bin
"""

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Independent SHAP Analysis Script - For analyzing trained SVR_rbf model

Based on the training and test sets used during model training
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
import joblib
import pickle
import os
import warnings
from datetime import datetime
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen
import gc

# Set warning filters
warnings.filterwarnings('ignore')

# Set font to Times New Roman, and configure math fonts
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 12
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['xtick.labelsize'] = 11
plt.rcParams['ytick.labelsize'] = 11
plt.rcParams['legend.fontsize'] = 11
plt.rcParams['figure.titlesize'] = 16


# ==================== Add missing classes (for compatibility) ====================
class SimpleANN:
    def __init__(self, *args, **kwargs):
        pass
    def predict(self, X):
        return np.zeros(len(X)) if hasattr(X, '__len__') else np.array([0])

class WideANN:
    def __init__(self, *args, **kwargs):
        pass
    def predict(self, X):
        return np.zeros(len(X)) if hasattr(X, '__len__') else np.array([0])


# ==================== Feature Extractor ====================
class FeatureExtractor:
    def __init__(self):
        pass
    
    def extract_monomer_features(self, smiles):
        try:
            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                return None
            features = []
            features.append(Descriptors.MolWt(mol))
            features.append(Descriptors.NumRotatableBonds(mol))
            features.append(mol.GetNumHeavyAtoms())
            features.append(Descriptors.TPSA(mol))
            features.append(Crippen.MolLogP(mol))
            features.append(Descriptors.NumHDonors(mol))
            features.append(Descriptors.NumHAcceptors(mol))
            aromatic_atoms = sum(1 for atom in mol.GetAtoms() if atom.GetIsAromatic())
            heavy_atoms = mol.GetNumHeavyAtoms()
            features.append(aromatic_atoms / max(heavy_atoms, 1))
            features.append(Descriptors.RingCount(mol))
            rotatable = Descriptors.NumRotatableBonds(mol)
            features.append((heavy_atoms - rotatable) / max(heavy_atoms, 1))
            features.append(Descriptors.TPSA(mol) / max(Descriptors.MolWt(mol), 1))
            features.append(Descriptors.Chi0(mol))
            features.append(Crippen.MolMR(mol))
            features.append((heavy_atoms ** (1/3)) / max(rotatable + 1, 1))
            features.append(rotatable / max(heavy_atoms, 1))
            return np.array(features)
        except:
            return None
    
    def extract_polymer_features(self, smiles_list, ratios=None):
        mono_features_list = []
        for smiles in smiles_list:
            feats = self.extract_monomer_features(smiles)
            if feats is not None:
                mono_features_list.append(feats)
        if not mono_features_list:
            return None
        mono_features = np.array(mono_features_list)
        if ratios is None:
            ratios = np.ones(len(smiles_list)) / len(smiles_list)
        else:
            ratios = np.array(ratios) / sum(ratios)
        polymer_features = []
        for i in range(mono_features.shape[1]):
            polymer_features.append(np.sum(mono_features[:, i] * ratios))
        if len(smiles_list) > 1:
            for i in range(min(10, mono_features.shape[1])):
                polymer_features.append(np.std(mono_features[:, i]))
        else:
            polymer_features.extend([0] * 10)
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.max(mono_features[:, i]))
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.min(mono_features[:, i]))
        for i in range(min(5, mono_features.shape[1])):
            polymer_features.append(np.max(mono_features[:, i]) - np.min(mono_features[:, i]))
        mw_mean = np.sum(mono_features[:, 0] * ratios)
        rigid_mean = np.sum(mono_features[:, 9] * ratios)
        aromatic_mean = np.sum(mono_features[:, 7] * ratios)
        tpsa_mean = np.sum(mono_features[:, 3] * ratios)
        rotatable_mean = np.sum(mono_features[:, 1] * ratios)
        polymer_features.append(mw_mean * rigid_mean)
        polymer_features.append(mw_mean * aromatic_mean)
        polymer_features.append(rigid_mean * aromatic_mean)
        polymer_features.append(tpsa_mean / max(rotatable_mean, 0.1))
        polymer_features.append(mw_mean / max(rotatable_mean, 0.1))
        polymer_features.append(len(smiles_list))
        polymer_features.append(np.sum(mono_features[:, 0]))
        polymer_features.append(np.sum(mono_features[:, 7]))
        return np.array(polymer_features)


# ==================== SHAP Analyzer ====================
class SHAPAnalyzer:
    def __init__(self, model_dir):
        self.model_dir = model_dir
        self.english_feature_names = [
            "Mean_MolecularWeight", "Mean_RotatableBonds", "Mean_HeavyAtomCount",
            "Mean_TPSA", "Mean_LogP", "Mean_HBondDonors", "Mean_HBondAcceptors",
            "Mean_AromaticRatio", "Mean_RingCount", "Mean_RigidityIndex",
            "Mean_PolarityIndex", "Mean_TopologicalIndex", "Mean_MolarRefractivity",
            "Mean_ShapeIndex", "Mean_FlexibilityIndex", "Std_MolecularWeight",
            "Std_RotatableBonds", "Std_HeavyAtomCount", "Std_TPSA", "Std_LogP",
            "Std_HBondDonors", "Std_HBondAcceptors", "Std_AromaticRatio",
            "Std_RingCount", "Std_RigidityIndex", "Max_MolecularWeight",
            "Max_RotatableBonds", "Max_HeavyAtomCount", "Max_TPSA", "Max_LogP",
            "Min_MolecularWeight", "Min_RotatableBonds", "Min_HeavyAtomCount",
            "Min_TPSA", "Min_LogP", "Range_MolecularWeight", "Range_RotatableBonds",
            "Range_HeavyAtomCount", "Range_TPSA", "Range_LogP",
            "MolecularWeightxRigidity", "MolecularWeightxAromaticity",
            "RigidityxAromaticity", "Polarity_Flexibility", "MolecularWeight_Flexibility",
            "MonomerCount", "TotalMolecularWeight", "TotalAromaticity"
        ]
        self.chinese_to_english = {
            '平均_分子量': 'Mean_MolecularWeight', '平均_可旋转键': 'Mean_RotatableBonds',
            '平均_重原子数': 'Mean_HeavyAtomCount', '平均_TPSA': 'Mean_TPSA',
            '平均_LogP': 'Mean_LogP', '平均_氢键供体': 'Mean_HBondDonors',
            '平均_氢键受体': 'Mean_HBondAcceptors', '平均_芳香比例': 'Mean_AromaticRatio',
            '平均_环数': 'Mean_RingCount', '平均_刚性指数': 'Mean_RigidityIndex',
            '平均_极性指数': 'Mean_PolarityIndex', '平均_拓扑指数': 'Mean_TopologicalIndex',
            '平均_摩尔折射率': 'Mean_MolarRefractivity', '平均_形状指数': 'Mean_ShapeIndex',
            '平均_柔性指数': 'Mean_FlexibilityIndex', '标准差_分子量': 'Std_MolecularWeight',
            '标准差_可旋转键': 'Std_RotatableBonds', '标准差_重原子数': 'Std_HeavyAtomCount',
            '标准差_TPSA': 'Std_TPSA', '标准差_LogP': 'Std_LogP',
            '标准差_氢键供体': 'Std_HBondDonors', '标准差_氢键受体': 'Std_HBondAcceptors',
            '标准差_芳香比例': 'Std_AromaticRatio', '标准差_环数': 'Std_RingCount',
            '标准差_刚性指数': 'Std_RigidityIndex', '最大_分子量': 'Max_MolecularWeight',
            '最大_可旋转键': 'Max_RotatableBonds', '最大_重原子数': 'Max_HeavyAtomCount',
            '最大_TPSA': 'Max_TPSA', '最大_LogP': 'Max_LogP', '最小_分子量': 'Min_MolecularWeight',
            '最小_可旋转键': 'Min_RotatableBonds', '最小_重原子数': 'Min_HeavyAtomCount',
            '最小_TPSA': 'Min_TPSA', '最小_LogP': 'Min_LogP', '范围_分子量': 'Range_MolecularWeight',
            '范围_可旋转键': 'Range_RotatableBonds', '范围_重原子数': 'Range_HeavyAtomCount',
            '范围_TPSA': 'Range_TPSA', '范围_LogP': 'Range_LogP',
            '分子量×刚性': 'MolecularWeightxRigidity', '分子量×芳香性': 'MolecularWeightxAromaticity',
            '刚性×芳香性': 'RigidityxAromaticity', '极性/柔性': 'Polarity_Flexibility',
            '分子量/柔性': 'MolecularWeight_Flexibility', '单体数量': 'MonomerCount',
            '总分子量': 'TotalMolecularWeight', '总芳香性': 'TotalAromaticity'
        }
        self.model_path = os.path.join(model_dir, "SVR_rbf_model.pkl")
        self.scaler_path = os.path.join(model_dir, "scaler.pkl")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_dir = os.path.join(model_dir, f"shap_analysis_svr_{timestamp}")
        os.makedirs(self.output_dir, exist_ok=True)
        print("="*80)
        print("Polymer Tg Prediction Model - SVR_rbf Model SHAP Analysis")
        print("="*80)
        print(f"Model directory: {model_dir}")
        print(f"Output directory: {self.output_dir}")
        print("="*80)
        self._load_model_and_data()
        self.explainer = None
        self.shap_values_train = None
        self.X_train_sample = None
        self.y_train_sample = None
    
    def _load_model_and_data(self):
        print("\n" + "-"*50)
        print("Loading model and data")
        print("-"*50)
        info_path = os.path.join(self.model_dir, "feature_info.pkl")
        if os.path.exists(info_path):
            try:
                with open(info_path, 'rb') as f:
                    self.feature_info = pickle.load(f)
                self.final_features = self.feature_info.get('final_features', [])
                self.final_feature_names = self.feature_info.get('final_feature_names', [])
                self.pearson_names = self.feature_info.get('pearson_names', [])
                self.pearson_indices = self.feature_info.get('pearson_indices', [])
                self.all_original_feature_names = self.feature_info.get('all_original_feature_names', [])
                self.best_model_name = self.feature_info.get('best_model_name', 'SVR_rbf')
                if len(self.final_feature_names) > 0:
                    english_names_subset = []
                    for i, name in enumerate(self.final_feature_names):
                        if name in self.chinese_to_english:
                            english_names_subset.append(self.chinese_to_english[name])
                        elif i < len(self.english_feature_names):
                            english_names_subset.append(self.english_feature_names[i])
                        else:
                            english_names_subset.append(name)
                    self.final_feature_names = english_names_subset
                    print(f"Feature names converted to English")
                print(f"Feature information loaded successfully")
                print(f"Best model: {self.best_model_name}")
                print(f"Test R²: {self.feature_info.get('best_test_r2', 0):.4f}")
                print(f"Test RMSE: {self.feature_info.get('best_test_rmse', 0):.2f}°C")
            except Exception as e:
                print(f"Warning: Error loading feature information: {e}")
                self.feature_info = {}
                self.final_features = list(range(10))
                self.final_feature_names = self.english_feature_names[:10]
                self.best_model_name = "SVR_rbf"
        else:
            self.feature_info = {}
            self.final_features = list(range(10))
            self.final_feature_names = self.english_feature_names[:10]
            self.best_model_name = "SVR_rbf"
        
        # Load SVR model
        if not os.path.exists(self.model_path):
            possible_models = [f for f in os.listdir(self.model_dir) if 'SVR' in f and f.endswith('.pkl')]
            if possible_models:
                self.model_path = os.path.join(self.model_dir, possible_models[0])
            else:
                best_model_path = os.path.join(self.model_dir, "best_model.pkl")
                if os.path.exists(best_model_path):
                    self.model_path = best_model_path
                else:
                    raise FileNotFoundError(f"SVR_rbf model file not found")
        self.model = joblib.load(self.model_path)
        print(f"Model loaded successfully: {type(self.model).__name__}")
        if not os.path.exists(self.scaler_path):
            raise FileNotFoundError(f"Scaler file not found")
        self.scaler = joblib.load(self.scaler_path)
        print(f"Scaler loaded successfully")
        self._load_training_data()
        print(f"\n[Final Selected Features] ({len(self.final_feature_names)}):")
        for i, (idx, name) in enumerate(zip(self.final_features, self.final_feature_names)):
            print(f"  {i+1:2d}. [Original index {idx:3d}] {name}")
    
    def _load_training_data(self):
        print("\n" + "-"*50)
        print("Loading training and test set data")
        print("-"*50)
        
        # First try to load from X_train_aug_pearson.npy (filtered features, 10 features)
        X_train_aug_path = os.path.join(self.model_dir, "X_train_aug_pearson.npy")
        y_train_aug_path = os.path.join(self.model_dir, "y_train_aug.npy")
        
        if os.path.exists(X_train_aug_path) and os.path.exists(y_train_aug_path):
            try:
                X_train_aug = np.load(X_train_aug_path)
                y_train_aug = np.load(y_train_aug_path)
                self.X_train_aug_pearson = X_train_aug
                self.y_train_aug = y_train_aug
                self.final_indices_in_pearson = []
                for feat_idx in self.final_features:
                    if feat_idx in self.pearson_indices:
                        pearson_pos = list(self.pearson_indices).index(feat_idx)
                        self.final_indices_in_pearson.append(pearson_pos)
                if len(self.final_indices_in_pearson) > 0:
                    self.X_train_aug = X_train_aug[:, self.final_indices_in_pearson]
                    print(f"Loaded augmented training set: {self.X_train_aug.shape}")
                else:
                    self.X_train_aug = X_train_aug
                    self.y_train_aug = y_train_aug
                    print(f"Loaded augmented training set: {self.X_train_aug.shape}")
                return
            except Exception as e:
                print(f"Warning: Error loading .npy files: {e}")
                self.X_train_aug = None
                self.y_train_aug = None
        
        # If X_train_aug_pearson.npy doesn't exist, try loading from X_train_aug.npy and filter
        X_train_aug_path = os.path.join(self.model_dir, "X_train_aug.npy")
        y_train_aug_path = os.path.join(self.model_dir, "y_train_aug.npy")
        
        if os.path.exists(X_train_aug_path) and os.path.exists(y_train_aug_path):
            try:
                X_train_aug = np.load(X_train_aug_path)
                y_train_aug = np.load(y_train_aug_path)
                self.X_train_aug_pearson = X_train_aug
                self.y_train_aug = y_train_aug
                self.final_indices_in_pearson = []
                for feat_idx in self.final_features:
                    if feat_idx in self.pearson_indices:
                        pearson_pos = list(self.pearson_indices).index(feat_idx)
                        self.final_indices_in_pearson.append(pearson_pos)
                if len(self.final_indices_in_pearson) > 0:
                    self.X_train_aug = X_train_aug[:, self.final_indices_in_pearson]
                    print(f"Loaded augmented training set from X_train_aug.npy and filtered: {self.X_train_aug.shape}")
                else:
                    self.X_train_aug = X_train_aug
                    print(f"Loaded augmented training set from X_train_aug.npy: {self.X_train_aug.shape}")
                return
            except Exception as e:
                print(f"Warning: Error loading .npy files: {e}")
                self.X_train_aug = None
                self.y_train_aug = None
        
        # If .npy loading fails, try loading from CSV
        if self.X_train_aug is None:
            self._load_data_from_csv()
        
        # If still no data, generate synthetic data
        if self.X_train_aug is None:
            np.random.seed(42)
            n_samples = 168
            n_features = len(self.final_feature_names)
            self.X_train_aug = np.random.randn(n_samples, n_features)
            self.y_train_aug = np.random.randn(n_samples) * 30 + 150
            print(f"Warning: Generated synthetic training data: {self.X_train_aug.shape}")
    
    def _load_data_from_csv(self):
        print("\nAttempting to load data from CSV file...")
        # Prioritize loading combined dataset
        combined_csv_path = os.path.join(self.model_dir, "AugmentedTrain_TestSet_Combined.csv")
        if os.path.exists(combined_csv_path):
            try:
                df = pd.read_csv(combined_csv_path)
                # Only use augmented training set
                train_mask = df['Data_Source'] == 'Augmented_Training'
                train_df = df[train_mask].copy()
                if 'Tg_True' in train_df.columns:
                    self.y_train_aug = train_df['Tg_True'].values
                    feature_cols = [col for col in train_df.columns if col not in ['Data_Source', 'Tg_True']]
                    if len(feature_cols) > 0:
                        X_aug = train_df[feature_cols].values
                        self.final_indices_in_csv = []
                        for feat_idx in self.final_features:
                            if feat_idx in self.pearson_indices:
                                pos_in_pearson = list(self.pearson_indices).index(feat_idx)
                                if pos_in_pearson < len(feature_cols):
                                    self.final_indices_in_csv.append(pos_in_pearson)
                        if len(self.final_indices_in_csv) == len(self.final_features):
                            self.X_train_aug = X_aug[:, self.final_indices_in_csv]
                        else:
                            self.X_train_aug = X_aug
                            self.final_features = list(range(len(feature_cols)))
                            english_names = []
                            for col in feature_cols:
                                if col in self.chinese_to_english:
                                    english_names.append(self.chinese_to_english[col])
                                else:
                                    english_names.append(col)
                            self.final_feature_names = english_names
                        print(f"Loaded augmented training set from combined CSV: {self.X_train_aug.shape}")
                        return
            except Exception as e:
                print(f"Warning: Error loading combined CSV: {e}")
        
        # Try loading separate augmented training set CSV
        aug_csv_path = os.path.join(self.model_dir, "Augmented_Training_Set_Features.csv")
        if os.path.exists(aug_csv_path):
            try:
                df = pd.read_csv(aug_csv_path)
                if 'Tg_True' in df.columns:
                    self.y_train_aug = df['Tg_True'].values
                    feature_cols = [col for col in df.columns if col not in ['Data_Source', 'Tg_True']]
                    if len(feature_cols) > 0:
                        X_aug = df[feature_cols].values
                        self.final_indices_in_csv = []
                        for feat_idx in self.final_features:
                            if feat_idx in self.pearson_indices:
                                pos_in_pearson = list(self.pearson_indices).index(feat_idx)
                                if pos_in_pearson < len(feature_cols):
                                    self.final_indices_in_csv.append(pos_in_pearson)
                        if len(self.final_indices_in_csv) == len(self.final_features):
                            self.X_train_aug = X_aug[:, self.final_indices_in_csv]
                        else:
                            self.X_train_aug = X_aug
                            self.final_features = list(range(len(feature_cols)))
                            english_names = []
                            for col in feature_cols:
                                if col in self.chinese_to_english:
                                    english_names.append(self.chinese_to_english[col])
                                else:
                                    english_names.append(col)
                            self.final_feature_names = english_names
                        print(f"Loaded augmented training set from CSV: {self.X_train_aug.shape}")
                        return
            except Exception as e:
                print(f"Warning: Error loading CSV: {e}")
    
    def create_explainer(self):
        print("\n" + "-"*50)
        print("Creating SHAP explainer")
        print("-"*50)
        if self.X_train_aug is None:
            print("Error: No training data")
            return False
        
        model_type = type(self.model).__name__
        print(f"Model type: {model_type}")
        
        try:
            # For SVR, use KernelExplainer
            if 'SVR' in model_type:
                print("Using KernelExplainer for SVR model")
                # Use standardized data
                X_scaled = self.scaler.transform(self.X_train_aug)
                # Use subset of data as background
                n_background = min(100, len(X_scaled))
                background_data = X_scaled[:n_background]
                self.explainer = shap.KernelExplainer(self.model.predict, background_data)
            else:
                self.explainer = shap.TreeExplainer(self.model)
            
            if hasattr(self.explainer, 'expected_value'):
                self.expected_value = self.explainer.expected_value
                if hasattr(self.expected_value, '__iter__'):
                    self.expected_value = self.expected_value[0]
            else:
                self.expected_value = np.mean(self.y_train_aug) if self.y_train_aug is not None else 150
            
            print(f"Explainer created successfully")
            print(f"  Baseline value: {self.expected_value:.2f}°C")
            return True
        except Exception as e:
            print(f"Failed to create explainer: {e}")
            return False
    
    def calculate_shap_values(self, train_sample_size=None):
        print("\n" + "-"*50)
        print("Calculating SHAP values")
        print("-"*50)
        
        if self.explainer is None:
            if not self.create_explainer():
                return False
        
        if self.X_train_aug is not None:
            # Use all training data (standardized)
            X_scaled = self.scaler.transform(self.X_train_aug)
            self.X_train_sample = X_scaled
            self.y_train_sample = self.y_train_aug
            print(f"Using full training set: {self.X_train_sample.shape[0]} samples")
            print("Calculating training set SHAP values...")
            
            try:
                # KernelExplainer uses shap_values method
                if isinstance(self.explainer, shap.KernelExplainer):
                    nsamples = min(100, len(self.X_train_sample))
                    self.shap_values_train = self.explainer.shap_values(self.X_train_sample, nsamples=nsamples)
                else:
                    self.shap_values_train = self.explainer.shap_values(self.X_train_sample)
                print(f"Training set SHAP values shape: {self.shap_values_train.shape}")
                
                if self.shap_values_train.shape[1] != len(self.final_feature_names):
                    if self.shap_values_train.shape[1] < len(self.final_feature_names):
                        self.final_feature_names = self.final_feature_names[:self.shap_values_train.shape[1]]
                    else:
                        for i in range(len(self.final_feature_names), self.shap_values_train.shape[1]):
                            self.final_feature_names.append(f"Feature_{i}")
                    print(f"Adjusted feature names to match SHAP values")
                
                return True
            except Exception as e:
                print(f"Error calculating SHAP values: {e}")
                return False
        else:
            print("No training data available")
            return False
    
    def plot_combined_shap(self, top_n=15):
        print(f"\nCreating combined SHAP plot (Top {top_n} features)...")
        if self.shap_values_train is None:
            print("Please calculate SHAP values first")
            return
        
        try:
            importance = np.abs(self.shap_values_train).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1][:top_n]
            sorted_features = [self.final_feature_names[i] for i in sorted_idx]
            sorted_importance = importance[sorted_idx]
            sorted_shap = self.shap_values_train[:, sorted_idx]
            sorted_X = self.X_train_sample[:, sorted_idx]
            X_train_df = pd.DataFrame(sorted_X, columns=sorted_features)
            
            plt.rcParams['font.size'] = 72
            plt.rcParams['axes.labelsize'] = 82
            plt.rcParams['axes.titlesize'] = 92
            plt.rcParams['xtick.labelsize'] = 72
            plt.rcParams['ytick.labelsize'] = 72
            
            fig = plt.figure(figsize=(45, 28))
            
            # ===== Use coolwarm colormap (blue to orange-red) =====
            shap.summary_plot(sorted_shap, X_train_df, feature_names=sorted_features,
                             show=False, max_display=top_n, plot_size=None, color_bar=True,
                             cmap=plt.cm.coolwarm)
            
            ax = plt.gca()
            ax.set_title(r'SHAP value of Glass Transition Temperature ($T_g$)', 
                        fontsize=92, fontweight='bold', fontname='Times New Roman', pad=60)
            ax.set_xlabel('SHAP value (impact on model output)', fontsize=82, fontweight='bold',
                         fontname='Times New Roman', labelpad=55)
            ax.set_ylabel('Features', fontsize=82, fontweight='bold', fontname='Times New Roman', labelpad=55)
            ax.tick_params(axis='x', labelsize=72, pad=20)
            for label in ax.get_xticklabels():
                label.set_fontname('Times New Roman'); label.set_fontsize(72); label.set_fontweight('bold')
            ax.tick_params(axis='y', labelsize=72, pad=20)
            for label in ax.get_yticklabels():
                label.set_fontname('Times New Roman'); label.set_fontsize(72); label.set_fontweight('bold')
            
            for collection in ax.collections:
                if hasattr(collection, 'set_sizes'):
                    try: collection.set_sizes([600])
                    except: pass
            
            # Modify colorbar labels
            cbar_ax = None
            for fig_ax in fig.get_axes():
                if fig_ax != ax:
                    cbar_ax = fig_ax
                    break
            if cbar_ax is not None:
                try:
                    cbar_ax.set_ylabel('Feature value', fontsize=68, fontweight='bold',
                                      fontname='Times New Roman', labelpad=50)
                    cbar_ax.tick_params(labelsize=60)
                    for label in cbar_ax.get_yticklabels():
                        label.set_fontname('Times New Roman'); label.set_fontsize(60); label.set_fontweight('bold')
                except:
                    pass
            
            # ===== Draw feature importance in bottom-left corner =====
            x_min, x_max = ax.get_xlim()
            y_min, y_max = ax.get_ylim()
            x_range = x_max - x_min
            y_range = y_max - y_min
            
            # Bottom-left position
            legend_x = x_min + x_range * 0.02
            legend_y = y_min + y_range * 0.02
            legend_width = x_range * 0.33
            legend_height = y_range * 0.38
            
            from matplotlib.patches import Rectangle
            rect = Rectangle(
                (legend_x, legend_y),
                legend_width,
                legend_height,
                facecolor='white',
                edgecolor='#888888',
                linewidth=2.5,
                alpha=0.92,
                zorder=100
            )
            ax.add_patch(rect)
            
            ax.text(
                legend_x + legend_width / 2,
                legend_y + legend_height - 0.015 * y_range,
                'Feature Importance',
                fontsize=62,
                fontweight='bold',
                fontname='Times New Roman',
                ha='center',
                va='top',
                color='#000000',
                zorder=101
            )
            
            sep_y = legend_y + legend_height - 0.055 * y_range
            ax.plot([legend_x + 0.02 * x_range, legend_x + legend_width - 0.02 * x_range], 
                   [sep_y, sep_y],
                   color='#888888', linewidth=1.5, zorder=101)
            
            n_display = min(8, len(sorted_features))
            display_features = sorted_features[:n_display]
            display_importance = sorted_importance[:n_display]
            max_imp = max(display_importance)
            
            bar_height = (legend_height - 0.10 * y_range) / n_display
            bar_width_ratio = 0.55
            
            for i, (feat_name, imp_val) in enumerate(zip(display_features, display_importance)):
                y_pos = sep_y - (i + 0.5) * bar_height - 0.015 * y_range
                if y_pos < legend_y + 0.02 * y_range:
                    break
                imp_ratio = imp_val / max_imp
                bar_width = imp_ratio * legend_width * bar_width_ratio
                bar_x_start = legend_x + 0.02 * x_range
                
                # ===== Orange bars =====
                ax.barh(y_pos, bar_width, left=bar_x_start, 
                       color='#E69F00', alpha=0.8, height=bar_height * 0.6, zorder=101)
                
                # ===== Values in dark orange =====
                ax.text(
                    legend_x + legend_width - 0.01 * x_range,
                    y_pos,
                    f'{imp_val:.3f}',
                    fontsize=44,
                    fontweight='bold',
                    fontname='Times New Roman',
                    ha='right',
                    va='center',
                    color='#D55E00',
                    zorder=101
                )
                
                if len(feat_name) > 18:
                    display_name = feat_name[:15] + '...'
                else:
                    display_name = feat_name
                
                ax.text(
                    legend_x + 0.02 * x_range + 0.005 * x_range,
                    y_pos,
                    display_name,
                    fontsize=40,
                    fontweight='normal',
                    fontname='Times New Roman',
                    ha='left',
                    va='center',
                    color='#1a1a1a',
                    zorder=101
                )
            
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['left'].set_linewidth(3)
            ax.spines['bottom'].set_linewidth(3)
            
            plt.tight_layout()
            save_path = os.path.join(self.output_dir, 'shap_combined_plot_SVR.png')
            plt.savefig(save_path, dpi=300, bbox_inches='tight', format='png', pad_inches=1.0)
            plt.close()
            gc.collect()
            print(f"   Combined plot saved: {save_path}")
            return fig
        except Exception as e:
            print(f"   Failed: {e}")
            return None
    
    def _save_feature_importance(self):
        """Save feature importance data"""
        if self.shap_values_train is None:
            return
        
        shap_abs_mean = np.abs(self.shap_values_train).mean(axis=0)
        indices = np.argsort(shap_abs_mean)[::-1]
        valid_indices = indices[:min(len(indices), len(self.final_feature_names))]
        df = pd.DataFrame({
            'Rank': range(1, len(valid_indices) + 1),
            'Feature Name': [self.final_feature_names[i] for i in valid_indices],
            'Mean |SHAP|': shap_abs_mean[valid_indices],
            'Relative Importance (%)': shap_abs_mean[valid_indices] / shap_abs_mean.sum() * 100
        })
        csv_path = os.path.join(self.output_dir, 'svr_feature_importance.csv')
        df.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"Feature importance data saved: {csv_path}")
        
        # Save SHAP values
        shap_df = pd.DataFrame(self.shap_values_train, columns=self.final_feature_names)
        shap_df['True Tg'] = self.y_train_sample
        shap_csv_path = os.path.join(self.output_dir, 'shap_values_train.csv')
        shap_df.to_csv(shap_csv_path, index=False, encoding='utf-8-sig')
        print(f"Training set SHAP values saved: {shap_csv_path}")
        
        # Save training data
        train_df = pd.DataFrame(self.X_train_aug, columns=self.final_feature_names)
        train_df['True Tg'] = self.y_train_aug
        train_csv_path = os.path.join(self.output_dir, 'training_data.csv')
        train_df.to_csv(train_csv_path, index=False, encoding='utf-8-sig')
        print(f"Training data saved: {train_csv_path}")
    
    def generate_full_report(self, train_sample_size=None):
        print("\n" + "="*80)
        print("Generating Complete SHAP Analysis Report")
        print("="*80)
        
        if not self.calculate_shap_values(train_sample_size):
            print("SHAP value calculation failed")
            return False
        
        # Combined plot
        self.plot_combined_shap(top_n=min(15, self.shap_values_train.shape[1]))
        
        # Save feature importance data
        self._save_feature_importance()
        
        # Text report and data
        self._generate_text_report()
        self._save_data_overview()
        
        print("\n" + "="*80)
        print(f"SHAP analysis completed! Results saved to: {self.output_dir}")
        print("="*80)
        return True
    
    def _generate_text_report(self):
        report_lines = []
        report_lines.append("="*80)
        report_lines.append("SVR_rbf Model - SHAP Analysis Report")
        report_lines.append("="*80)
        report_lines.append(f"Generation time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append(f"Model directory: {self.model_dir}")
        report_lines.append("")
        report_lines.append("[Model Performance]")
        report_lines.append(f"Best model: {self.best_model_name}")
        report_lines.append(f"Test R²: {self.feature_info.get('best_test_r2', 0):.4f}")
        report_lines.append(f"Test RMSE: {self.feature_info.get('best_test_rmse', 0):.2f}°C")
        report_lines.append("")
        report_lines.append("[Feature Information]")
        report_lines.append(f"Final selected features: {len(self.final_feature_names)}")
        report_lines.append("")
        
        if self.shap_values_train is not None:
            report_lines.append("[Feature Importance Ranking (Top 10)]")
            shap_abs_mean = np.abs(self.shap_values_train).mean(axis=0)
            indices = np.argsort(shap_abs_mean)[::-1]
            for i, idx in enumerate(indices[:10]):
                if idx < len(self.final_feature_names):
                    report_lines.append(f"{i+1:2d}. {self.final_feature_names[idx]}: {shap_abs_mean[idx]:.4f}")
            report_lines.append("")
        
        report_lines.append(f"[Baseline Value]")
        report_lines.append(f"Expected value: {self.expected_value:.2f}°C")
        report_lines.append("")
        report_lines.append(f"[Training Data]")
        report_lines.append(f"Training samples: {len(self.X_train_aug) if self.X_train_aug is not None else 0}")
        report_lines.append(f"Features: {len(self.final_feature_names)}")
        report_lines.append("")
        report_lines.append("="*80)
        
        report_path = os.path.join(self.output_dir, 'svr_shap_report.txt')
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_lines))
        print(f"Text report saved: {report_path}")
    
    def _save_data_overview(self):
        overview = {
            'Training samples': len(self.X_train_aug) if self.X_train_aug is not None else 0,
            'Training set Tg mean': np.mean(self.y_train_aug) if self.y_train_aug is not None else 0,
            'Training set Tg std': np.std(self.y_train_aug) if self.y_train_aug is not None else 0,
        }
        df = pd.DataFrame([overview])
        csv_path = os.path.join(self.output_dir, 'data_overview.csv')
        df.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"Data overview saved: {csv_path}")


# ==================== Main Program ====================
def main():
    # Update this path to your model directory
    base_dir = r"your model file generated from modeling code"
    print("="*80)
    print("Polymer Tg Prediction Model - SVR_rbf Model SHAP Analysis")
    print("="*80)
    print(f"Base directory: {base_dir}")
    if not os.path.exists(base_dir):
        base_dir = os.getcwd()
        print(f"Using current directory: {base_dir}")
    possible_dirs = [d for d in os.listdir() if d.startswith("GroupModel_Augment")]
    if possible_dirs and not os.path.exists(base_dir):
        base_dir = possible_dirs[0]
        print(f"Found model directory: {base_dir}")
    try:
        analyzer = SHAPAnalyzer(base_dir)
        analyzer.generate_full_report(train_sample_size=None)  # Use all training data
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()