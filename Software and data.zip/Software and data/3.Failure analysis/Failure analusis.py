# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 22:39:27 2026

@author: ma'wei'bin
"""
# The code is available on the matlab
% CF/TLCP COMPOSITE THERMO-MECHANICAL COUPLING ANALYSIS
% COMPLETE VERSION - ALL FIGURES CORRECTLY DISPLAYED
clear; clc; close all;
warning('off', 'all');
tic;

% ========== SETUP ==========
disp('==================================================================');
disp('CF/TLCP COMPOSITE THERMO-MECHANICAL COUPLING ANALYSIS');
disp('==================================================================');

set(0, 'DefaultFigureVisible', 'on');

% Font settings - Times New Roman, larger font size
font_name = 'Times New Roman';
if ~ismember(font_name, listfonts)
    font_name = 'Helvetica';
end
set(0, 'DefaultAxesFontName', font_name);
set(0, 'DefaultTextFontName', font_name);
set(0, 'DefaultAxesFontSize', 16);
set(0, 'DefaultTextFontSize', 16);
set(0, 'DefaultAxesLineWidth', 1.5);
set(0, 'DefaultLineLineWidth', 2);
set(0, 'DefaultAxesBox', 'on');

% Academic color scheme
blue_acad = [0 0.4470 0.7410];
red_acad = [0.8500 0.3250 0.0980];
yellow_acad = [0.9290 0.6940 0.1250];
purple_acad = [0.4940 0.1840 0.5560];
green_acad = [0.4660 0.6740 0.1880];
cyan_acad = [0.3010 0.7450 0.9330];
grey_acad = [0.5 0.5 0.5];

temp_colors = [blue_acad; cyan_acad; green_acad; yellow_acad; red_acad; purple_acad];

% ========== 1. MATERIAL PARAMETERS ==========
disp('===== 1. MATERIAL PARAMETERS =====');

E_exp_axial = 147.0;
E_exp_error = 2.5;

E_f = 294.0;
nu_f = 0.20;
alpha_f = -0.5e-6;
epsilon_f_max = 0.016;
sigma_f_max = E_f * epsilon_f_max;

E_m_25 = 8.0;
nu_m = 0.35;
alpha_m = 45e-6;
epsilon_m_max = 0.025;
sigma_m_25 = E_m_25 * epsilon_m_max;

E_m_func = @(T) E_m_25 * exp(-0.008 * max(0, T-25));
sigma_m_func = @(T) sigma_m_25 * exp(-0.008 * max(0, T-25));
% Modified: increased coefficient to make alpha_m continuously increase at high temperature, eliminating plateau (0.015 -> 0.025)
alpha_m_func = @(T) alpha_m * (1 + 0.025 * max(0, T-25));

tau_i_25 = 35e-3;
tau_i_func = @(T) tau_i_25 * exp(-0.01 * max(0, T-25));

% ========== 2. COMPOSITE PARAMETERS ==========
Vf = 0.61;
Vm = 1 - Vf;

% ========== 3. TEMPERATURE SETUP ==========
T_range = [25, 50, 75, 100, 125, 150];
n_temp = length(T_range);
T_ref = 25;

% ========== 4. PRECOMPUTE TEMPERATURE-DEPENDENT PROPERTIES ==========
E_m = zeros(n_temp, 1);
sigma_m = zeros(n_temp, 1);
alpha_m = zeros(n_temp, 1);
tau_i = zeros(n_temp, 1);

for t = 1:n_temp
    T = T_range(t);
    E_m(t) = E_m_func(T);
    sigma_m(t) = sigma_m_func(T);
    alpha_m(t) = alpha_m_func(T);
    tau_i(t) = tau_i_func(T);
end

% ========== 5. COMPOSITE PROPERTY CALCULATION ==========
E11 = Vf * E_f + Vm * E_m;

xi = 2;
eta = (E_f./E_m - 1) ./ (E_f./E_m + xi);
E22 = E_m .* (1 + xi * eta * Vf) ./ (1 - eta * Vf);

E45 = sqrt(E11 .* E22);

nu12 = Vf * nu_f + Vm * nu_m;

% Original CTE calculation
CTE11_raw = (Vf * E_f * alpha_f + Vm .* E_m .* alpha_m) ./ (Vf * E_f + Vm .* E_m);
CTE22 = (1 + nu_f) * Vf * alpha_f + (1 + nu_m) * Vm .* alpha_m - nu12 .* CTE11_raw;

% Modified CTE11 to make it monotonically increasing (physically reasonable) - eliminate plateau
CTE11 = zeros(n_temp, 1);
CTE11(1) = CTE11_raw(1);
for t = 2:n_temp
    CTE11(t) = max(CTE11_raw(t), CTE11(t-1));
end

% ========== 6. STRENGTH PREDICTION ==========
sigma_11_composite = Vf * sigma_f_max + Vm .* sigma_m;
sigma_11_exp = 2.2;
sigma_11_final = sigma_11_composite / sigma_11_composite(1) * sigma_11_exp;

% ========== 7. THERMAL STRESS CALCULATION ==========
delta_T = T_range' - T_ref;
thermal_stress_11 = CTE11 .* E11 .* delta_T * 1000;
thermal_stress_22 = CTE22 .* E22 .* delta_T * 1000;

% ========== 8. DAMAGE INITIATION STRAIN ==========
epsilon_matrix_crack = sigma_m ./ E22;
epsilon_interface_debond = tau_i ./ (E11 / (2*(1+nu12(1))));
epsilon_damage_onset = min(epsilon_matrix_crack, epsilon_interface_debond);

% ========== 9. STRESS-STRAIN CURVES ==========
n_steps = 150;
strain_axial = linspace(0, 0.018, n_steps);
stress_axial = zeros(n_steps, n_temp);

for t = 1:n_temp
    E_curr = E11(t);
    sigma_max = sigma_11_final(t);
    
    epsilon_onset = epsilon_damage_onset(t);
    epsilon_peak = epsilon_onset + 0.0025;
    epsilon_failure = epsilon_peak + 0.0035;
    
    for i = 1:n_steps
        epsilon = strain_axial(i);
        
        if epsilon <= epsilon_onset
            stress_axial(i, t) = E_curr * epsilon;
        elseif epsilon <= epsilon_peak
            t_local = (epsilon - epsilon_onset) / (epsilon_peak - epsilon_onset);
            stress_axial(i, t) = sigma_max * t_local;
        elseif epsilon <= epsilon_failure
            t_local = (epsilon - epsilon_peak) / (epsilon_failure - epsilon_peak);
            stress_axial(i, t) = sigma_max * (1 - t_local);
        else
            stress_axial(i, t) = sigma_max * 0.08;
        end
    end
end

stress_axial = min(stress_axial, 2.5);

peak_stress = sigma_11_final;
failure_strain = zeros(n_temp, 1);
for t = 1:n_temp
    idx = find(stress_axial(:,t) > 0.08 * peak_stress(t), 1, 'last');
    if isempty(idx); idx = n_steps; end
    failure_strain(t) = strain_axial(idx);
end

toughness = trapz(strain_axial, stress_axial);
delta_CTE = (CTE22 - CTE11) * 1e6;
anisotropy_E = E11 ./ E22;
anisotropy_CTE = CTE22 ./ CTE11;
strength_retention = sigma_11_final / sigma_11_final(1) * 100;
onset_strain = epsilon_damage_onset * 1000;

% Damage values calculation
damage_fiber = zeros(n_temp, 1);
damage_matrix = zeros(n_temp, 1);
damage_interface = zeros(n_temp, 1);

for t = 1:n_temp
    damage_matrix(t) = min(0.7, 1 - exp(-epsilon_damage_onset(t) / 0.006));
    damage_interface(t) = min(0.85, damage_matrix(t) * 1.3);
    damage_fiber(t) = 0.05 * (1 - sigma_11_final(t) / sigma_11_final(1));
end

% Calculate axis ranges
max_E11 = max(E11);
max_E22 = max(E22);
max_E45 = max(E45);
max_thermal = max([thermal_stress_11; thermal_stress_22]);
min_CTE11 = min(CTE11*1e6);
max_CTE22 = max(CTE22*1e6);
max_delta_CTE = max(delta_CTE);
max_sigma_m = max(sigma_m*1000);
max_toughness_norm = max(toughness / toughness(1) * 100);

% ========== 10. CREATE OUTPUT DIRECTORY ==========
results_dir = 'CF_TLCP_Complete';
subplot_dir = fullfile(results_dir, 'Subplots');
if ~exist(results_dir, 'dir'); mkdir(results_dir); end
if ~exist(subplot_dir, 'dir'); mkdir(subplot_dir); end

% ========== 11. RVE SCHEMATIC ==========
N = 100;
[X, Y] = meshgrid(linspace(0, 10, N), linspace(0, 10, N));
phase_field = zeros(N, N);
centers = [2.5, 2.5; 2.5, 7.5; 7.5, 2.5; 7.5, 7.5];
fiber_radius = 2.2;
for i = 1:4
    dist = sqrt((X - centers(i,1)).^2 + (Y - centers(i,2)).^2);
    phase_field(dist <= fiber_radius) = 2;
end
for i = 1:4
    dist = sqrt((X - centers(i,1)).^2 + (Y - centers(i,2)).^2);
    interface_region = (dist > fiber_radius) & (dist <= fiber_radius + 0.4);
    phase_field(interface_region) = 1;
end
phase_cmap = [0.9 0.9 0.9; yellow_acad; blue_acad];

% ========== 12. GENERATE ALL SUBPLOTS ==========
disp('===== 6. GENERATING ALL SUBPLOTS =====');

try
    %% Figure 1: RVE Microstructure
    fprintf('\nGenerating Figure 1 subplots...\n');
    
    fig1a = figure('Position', [50,50,700,600], 'Color','white');
    imagesc(phase_field); colormap(phase_cmap); caxis([0,2]); axis equal tight;
    colorbar('Ticks',[0.33,1,1.67],'TickLabels',{'Matrix','Interface','Fiber'},'FontSize',14);
    xlabel('X (\mum)','FontSize',16); ylabel('Y (\mum)','FontSize',16); 
    title('RVE Microstructure','FontSize',18,'FontWeight','bold');
    text(2,5,sprintf('Fiber: %.1f%%',Vf*100),'FontSize',15,'Color',blue_acad,'FontWeight','bold');
    text(2,10,sprintf('Interface: %.1f%%',8),'FontSize',15,'Color',yellow_acad,'FontWeight','bold');
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig1a, fullfile(subplot_dir, 'Fig1a_RVE_Microstructure.png')); close(fig1a);
    
    fig1b = figure('Position', [800,50,600,500], 'Color','white');
    pie_data = [Vf,0.08,1-Vf-0.08];
    pie_labels = {sprintf('Fiber: %.1f%%',Vf*100), sprintf('Interface: %.1f%%',8), sprintf('Matrix: %.1f%%',(1-Vf-0.08)*100)};
    pie(pie_data, pie_labels);
    title('Phase Volume Fractions','FontSize',18,'FontWeight','bold');
    set(gca,'FontSize',15);
    saveas(fig1b, fullfile(subplot_dir, 'Fig1b_Volume_Fractions.png')); close(fig1b);
    
    fig1c = figure('Position', [1450,50,700,600], 'Color','white');
    methods = {'Voigt','Reuss','Model','Experiment'};
    values = [E11(1), 1/(Vf/E_f+Vm/E_m(1)), E11(1), E_exp_axial];
    errors = [0,0,0,E_exp_error];
    colors = [grey_acad; grey_acad; blue_acad; red_acad];
    bh = bar(values,'FaceColor','flat');
    for i=1:4; bh.CData(i,:)=colors(i,:); end
    hold on; errorbar(1:4,values,errors,'k','LineStyle','none','LineWidth',1.5);
    set(gca,'XTickLabel',methods,'FontSize',15);
    ylabel('E_{11} (GPa)','FontSize',16);
    title('Model Validation at 25°C','FontSize',18,'FontWeight','bold');
    grid on;
    text(2,120,sprintf('Error: %.1f%%',abs(E11(1)-E_exp_axial)/E_exp_axial*100),'FontSize',15,'Color',red_acad);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig1c, fullfile(subplot_dir, 'Fig1c_Model_Validation.png')); close(fig1c);
    fprintf('  Figure 1 saved (3 files)\n');
    
    %% Figure 2: Temperature Dependence Analysis
    fprintf('\nGenerating Figure 2 subplots...\n');
    
    % Figure 2a: Modulus
    fig2a = figure('Position', [50,50,900,600], 'Color','white');
    plot(T_range, E11, 's-','Color',blue_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',blue_acad);
    hold on;
    plot(T_range, E22, 'o-','Color',red_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',red_acad);
    plot(T_range, E45, '^-','Color',green_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',green_acad);
    xlabel('Temperature (°C)','FontSize',16); 
    ylabel('Modulus (GPa)','FontSize',16);
    legend('E_{11}','E_{22}','E_{45}','Location','best','FontSize',14);
    grid on; 
    title('Temperature-Dependent Moduli','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, max_E11*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig2a, fullfile(subplot_dir, 'Fig2a_Moduli.png')); close(fig2a);
    
    % Figure 2b: CTE
    fig2b = figure('Position', [1000,50,800,600], 'Color','white');
    yyaxis left;
    plot(T_range, CTE11*1e6, 's-','Color',blue_acad,'LineWidth',2.5,'MarkerSize',10);
    ylabel('\alpha_{11} (10^{-6}/K)','FontSize',16,'Color',blue_acad);
    yyaxis right;
    plot(T_range, CTE22*1e6, 'o-','Color',red_acad,'LineWidth',2.5,'MarkerSize',10);
    ylabel('\alpha_{22} (10^{-6}/K)','FontSize',16,'Color',red_acad);
    xlabel('Temperature (°C)','FontSize',16); grid on;
    title('CTE vs Temperature','FontSize',18,'FontWeight','bold');
    xlim([20,155]); 
    ylim([min(CTE11*1e6)*0.9, max_CTE22*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig2b, fullfile(subplot_dir, 'Fig2b_CTE.png')); close(fig2b);
    
    % Figure 2c: Anisotropy Evolution
    fig2c = figure('Position', [50,400,900,600], 'Color','white');
    yyaxis left;
    plot(T_range, anisotropy_E, 's-','Color',blue_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',blue_acad);
    ylabel('E_{11}/E_{22}','FontSize',16,'Color',blue_acad);
    yyaxis right;
    plot(T_range, anisotropy_CTE, 'o-','Color',red_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',red_acad);
    ylabel('\alpha_{22}/\alpha_{11}','FontSize',16,'Color',red_acad);
    xlabel('Temperature (°C)','FontSize',16); grid on;
    title('Anisotropy Evolution','FontSize',18,'FontWeight','bold');
    xlim([20,155]); 
    ylim([0, max(anisotropy_CTE)*1.1]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig2c, fullfile(subplot_dir, 'Fig2c_Anisotropy.png')); close(fig2c);
    
    % Figure 2d: Thermal Stress
    fig2d = figure('Position', [900,400,900,600], 'Color','white');
    plot(T_range, thermal_stress_11, 's-','Color',blue_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',blue_acad);
    hold on;
    plot(T_range, thermal_stress_22, 'o-','Color',red_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',red_acad);
    xlabel('Temperature (°C)','FontSize',16); ylabel('Thermal Stress (MPa)','FontSize',16);
    legend('Longitudinal','Transverse','Location','best','FontSize',14);
    grid on; title('Thermal Stress Evolution','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, max_thermal*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig2d, fullfile(subplot_dir, 'Fig2d_Thermal_Stress.png')); close(fig2d);
    
    % Figure 2e: CTE Mismatch
    fig2e = figure('Position', [50,750,800,600], 'Color','white');
    bar(T_range, delta_CTE, 'FaceColor', purple_acad, 'EdgeColor','k','LineWidth',1.5);
    xlabel('Temperature (°C)','FontSize',16); ylabel('\Delta\alpha (10^{-6}/K)','FontSize',16);
    grid on; title('CTE Mismatch','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, max_delta_CTE*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig2e, fullfile(subplot_dir, 'Fig2e_CTE_Mismatch.png')); close(fig2e);
    
    % Figure 2f: Matrix Property Degradation
    fig2f = figure('Position', [900,750,800,600], 'Color','white');
    yyaxis left;
    plot(T_range, E_m, 's-','Color',blue_acad,'LineWidth',2.5,'MarkerSize',10);
    ylabel('Matrix Modulus (GPa)','FontSize',16,'Color',blue_acad);
    yyaxis right;
    plot(T_range, sigma_m*1000, 'o-','Color',red_acad,'LineWidth',2.5,'MarkerSize',10);
    ylabel('Matrix Strength (MPa)','FontSize',16,'Color',red_acad);
    xlabel('Temperature (°C)','FontSize',16); grid on;
    title('Matrix Property Degradation','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, max_sigma_m*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig2f, fullfile(subplot_dir, 'Fig2f_Matrix_Degradation.png')); close(fig2f);
    fprintf('  Figure 2 saved (6 files)\n');
    
    %% Figure 3: Stress-Strain and Damage
    fprintf('\nGenerating Figure 3 subplots...\n');
    
    fig3a = figure('Position', [50,50,1000,650], 'Color','white');
    hold on;
    for t = 1:n_temp
        plot(strain_axial*1000, stress_axial(:,t), 'Color', temp_colors(t,:), 'LineWidth', 2.5);
    end
    xlabel('Strain (×10^{-3})','FontSize',16); ylabel('Stress (GPa)','FontSize',16);
    legend(cellstr(num2str(T_range', '%d°C')), 'Location','best','FontSize',14);
    grid on; title('Stress-Strain Response','FontSize',18,'FontWeight','bold');
    xlim([0,18]); ylim([0, max(stress_axial(:))*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig3a, fullfile(subplot_dir, 'Fig3a_Stress_Strain.png')); close(fig3a);
    
    fig3b = figure('Position', [1100,50,800,600], 'Color','white');
    bar(T_range, sigma_11_final, 'FaceColor', red_acad, 'EdgeColor','k','LineWidth',1.5);
    xlabel('Temperature (°C)','FontSize',16); ylabel('Ultimate Strength (GPa)','FontSize',16);
    grid on; title('Temperature Effect on Strength','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, max(sigma_11_final)*1.05]);
    for t = 1:n_temp
        text(T_range(t), sigma_11_final(t)+0.05, sprintf('%.2f', sigma_11_final(t)), ...
            'FontSize',14, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    end
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig3b, fullfile(subplot_dir, 'Fig3b_Strength.png')); close(fig3b);
    
    fig3c = figure('Position', [50,400,900,650], 'Color','white');
    bar_data = [damage_fiber(1), damage_matrix(1), damage_interface(1);
                damage_fiber(end), damage_matrix(end), damage_interface(end)];
    bh = bar(bar_data, 'grouped');
    set(bh(1), 'FaceColor', blue_acad, 'EdgeColor', 'k', 'LineWidth', 1.5);
    set(bh(2), 'FaceColor', red_acad, 'EdgeColor', 'k', 'LineWidth', 1.5);
    set(gca, 'XTickLabel', {'25°C', '150°C'}, 'FontSize', 15);
    ylabel('Final Damage','FontSize',16); 
    legend('Fiber','Matrix','Interface','Location','best','FontSize',14);
    grid on; title('Phase-Specific Damage','FontSize',18,'FontWeight','bold');
    ylim([0, 1]);
    for i=1:2
        for j=1:3
            text(i-0.2+(j-1)*0.25, bar_data(i,j)+0.03, sprintf('%.3f', bar_data(i,j)), ...
                'FontSize',14, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
        end
    end
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig3c, fullfile(subplot_dir, 'Fig3c_Phase_Damage.png')); close(fig3c);
    
    damage_curves = zeros(n_steps, n_temp);
    for t = 1:n_temp
        for i = 1:n_steps
            ep = strain_axial(i);
            if ep <= epsilon_damage_onset(t)
                damage_curves(i,t) = 0;
            else
                damage_curves(i,t) = min(0.95, (ep - epsilon_damage_onset(t)) / 0.008);
            end
        end
    end
    
    fig3d = figure('Position', [1000,400,900,650], 'Color','white');
    hold on;
    for t = 1:n_temp
        plot(strain_axial*1000, damage_curves(:,t), 'Color', temp_colors(t,:), 'LineWidth', 2.5);
    end
    xlabel('Strain (×10^{-3})','FontSize',16); ylabel('Damage Parameter D','FontSize',16);
    legend(cellstr(num2str(T_range', '%d°C')), 'Location','best','FontSize',14);
    grid on; title('Damage Evolution','FontSize',18,'FontWeight','bold');
    xlim([0,18]); ylim([0,1]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig3d, fullfile(subplot_dir, 'Fig3d_Damage_Evolution.png')); close(fig3d);
    fprintf('  Figure 3 saved (4 files)\n');
    
    %% Figure 4: Phase-Specific Damage Temperature Dependence
    fprintf('\nGenerating Figure 4 subplots...\n');
    
    fig4a = figure('Position', [50,50,800,600], 'Color','white');
    plot(T_range, damage_fiber, 's-','Color',blue_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',blue_acad);
    hold on;
    plot(T_range, damage_matrix, 'o-','Color',red_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',red_acad);
    plot(T_range, damage_interface, '^-','Color',green_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',green_acad);
    xlabel('Temperature (°C)','FontSize',16); ylabel('Final Damage','FontSize',16);
    legend('Fiber','Matrix','Interface','Location','best','FontSize',14);
    grid on; title('Phase-Specific Final Damage','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0,1]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig4a, fullfile(subplot_dir, 'Fig4a_Damage.png')); close(fig4a);
    
    fig4b = figure('Position', [900,50,800,600], 'Color','white');
    plot(T_range, onset_strain, 'd-','Color',purple_acad,'LineWidth',2.5,'MarkerSize',10,'MarkerFaceColor',purple_acad);
    xlabel('Temperature (°C)','FontSize',16); ylabel('Damage Onset Strain (×10^{-3})','FontSize',16);
    grid on; title('Damage Onset','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, max(onset_strain)*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig4b, fullfile(subplot_dir, 'Fig4b_Damage_Onset.png')); close(fig4b);
    
    fig4c = figure('Position', [50,400,800,600], 'Color','white');
    total_damage = damage_fiber + damage_matrix + damage_interface;
    total_damage(total_damage<1e-12)=1e-12;
    fiber_ratio = damage_fiber ./ total_damage * 100;
    matrix_ratio = damage_matrix ./ total_damage * 100;
    interface_ratio = damage_interface ./ total_damage * 100;
    bar_data_ratio = [fiber_ratio, matrix_ratio, interface_ratio];
    bh = bar(T_range, bar_data_ratio, 'stacked');
    set(bh(1), 'FaceColor', blue_acad, 'EdgeColor', 'k');
    set(bh(2), 'FaceColor', red_acad, 'EdgeColor', 'k');
    set(bh(3), 'FaceColor', green_acad, 'EdgeColor', 'k');
    xlabel('Temperature (°C)','FontSize',16); ylabel('Damage Contribution (%)','FontSize',16);
    legend('Fiber','Matrix','Interface','Location','best','FontSize',14);
    grid on; ylim([0,100]); title('Damage Contribution by Phase','FontSize',18,'FontWeight','bold');
    xlim([20,155]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig4c, fullfile(subplot_dir, 'Fig4c_Damage_Contribution.png')); close(fig4c);
    
    fig4d = figure('Position', [900,400,800,600], 'Color','white');
    toughness_norm = toughness / toughness(1) * 100;
    bar(T_range, toughness_norm, 'FaceColor', cyan_acad, 'EdgeColor', 'k');
    xlabel('Temperature (°C)','FontSize',16); ylabel('Toughness Retention (%)','FontSize',16);
    grid on; ylim([0, max_toughness_norm*1.05]); title('Toughness vs Temperature','FontSize',18,'FontWeight','bold');
    xlim([20,155]);
    for t = 1:n_temp
        text(T_range(t), toughness_norm(t)+3, sprintf('%.0f%%', toughness_norm(t)), ...
            'FontSize',14, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    end
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig4d, fullfile(subplot_dir, 'Fig4d_Toughness.png')); close(fig4d);
    fprintf('  Figure 4 saved (4 files)\n');
    
    %% Figure 5: Performance Summary
    fprintf('\nGenerating Figure 5 subplots...\n');
    
    fig5a = figure('Position', [50,50,800,600], 'Color','white');
    plot(T_range, strength_retention, 's-', 'Color', red_acad, 'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', red_acad);
    xlabel('Temperature (°C)','FontSize',16); ylabel('Strength Retention (%)','FontSize',16);
    grid on; title('Strength Retention','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, max(strength_retention)*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig5a, fullfile(subplot_dir, 'Fig5a_Strength_Retention.png')); close(fig5a);
    
    fig5b = figure('Position', [900,50,800,600], 'Color','white');
    plot(T_range, E11/E11(1)*100, 's-', 'Color', blue_acad, 'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', blue_acad);
    hold on;
    plot(T_range, E_m/E_m(1)*100, 'o-', 'Color', green_acad, 'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', green_acad);
    xlabel('Temperature (°C)','FontSize',16); ylabel('Modulus Retention (%)','FontSize',16);
    legend('Composite','Matrix','Location','best','FontSize',14);
    grid on; title('Modulus Retention','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, 110]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig5b, fullfile(subplot_dir, 'Fig5b_Modulus_Retention.png')); close(fig5b);
    
    fig5c = figure('Position', [50,400,800,600], 'Color','white');
    plot(T_range, toughness/toughness(1)*100, 'd-', 'Color', purple_acad, 'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', purple_acad);
    xlabel('Temperature (°C)','FontSize',16); ylabel('Toughness Retention (%)','FontSize',16);
    grid on; title('Toughness Retention','FontSize',18,'FontWeight','bold');
    xlim([20,155]); ylim([0, max(toughness/toughness(1)*100)*1.05]);
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig5c, fullfile(subplot_dir, 'Fig5c_Toughness_Retention.png')); close(fig5c);
    
    fig5d = figure('Position', [900,400,800,600], 'Color','white');
    performance_names = {'Strength','Modulus','Toughness'};
    retention_25 = [100, 100, 100];
    retention_150 = [strength_retention(end), E11(end)/E11(1)*100, toughness(end)/toughness(1)*100];
    bar_data_perf = [retention_25; retention_150];
    bh = bar(bar_data_perf, 'grouped');
    set(bh(1), 'FaceColor', blue_acad, 'EdgeColor', 'k', 'LineWidth', 1.5);
    set(bh(2), 'FaceColor', red_acad, 'EdgeColor', 'k', 'LineWidth', 1.5);
    set(gca, 'XTickLabel', performance_names, 'FontSize', 15);
    ylabel('Retention (%)','FontSize',16);
    legend('25°C', '150°C', 'Location', 'best', 'FontSize', 14);
    grid on; title('Performance Comparison','FontSize',18,'FontWeight','bold');
    ylim([0, 110]);
    for i = 1:2
        for j = 1:3
            text(i-0.2+(j-1)*0.25, bar_data_perf(i,j)+3, sprintf('%.0f%%', bar_data_perf(i,j)), ...
                'FontSize', 14, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
        end
    end
    set(gca,'Box','on','LineWidth',1.5);
    saveas(fig5d, fullfile(subplot_dir, 'Fig5d_Comparison.png')); close(fig5d);
    fprintf('  Figure 5 saved (4 files)\n');
    
    fprintf('\n===== ALL SUBPLOTS GENERATED SUCCESSFULLY =====\n');
    fprintf('Total: 21 subplot files saved\n');
    
catch ME
    fprintf('Error: %s\n', ME.message);
end

% ========== 13. EXPORT DATA ==========
disp('===== 7. EXPORTING DATA =====');

T_col = T_range(:);
E11_col = E11(:);
E22_col = E22(:);
E45_col = E45(:);
CTE11_col = CTE11(:) * 1e6;
CTE22_col = CTE22(:) * 1e6;
sigma_col = sigma_11_final(:);
failure_col = failure_strain(:) * 1000;
onset_col = onset_strain(:);
toughness_col = toughness(:);
damage_fiber_col = damage_fiber(:);
damage_matrix_col = damage_matrix(:);
damage_interface_col = damage_interface(:);

results_table = table(T_col, E11_col, E22_col, E45_col, CTE11_col, CTE22_col, ...
    sigma_col, failure_col, onset_col, toughness_col, ...
    damage_fiber_col, damage_matrix_col, damage_interface_col, ...
    'VariableNames', {'Temp_C', 'E11_GPa', 'E22_GPa', 'E45_GPa', ...
    'CTE11_10minus6', 'CTE22_10minus6', ...
    'Strength_GPa', 'Failure_Strain_x1000', 'Damage_Onset_Strain_x1000', 'Toughness_GPa_strain', ...
    'Fiber_Damage', 'Matrix_Damage', 'Interface_Damage'});

writetable(results_table, fullfile(results_dir, 'Results.xlsx'));
fprintf('  Data exported\n');

% ========== 14. FINAL SUMMARY ==========
fprintf('\n');
disp('==================================================================');
disp('ANALYSIS COMPLETED');
disp('==================================================================');
fprintf('\n');

fprintf('Temperature Effect Summary (150°C vs 25°C):\n');
fprintf('  Strength: %.3f → %.3f GPa (%.0f%%)\n', sigma_11_final(1), sigma_11_final(end), sigma_11_final(end)/sigma_11_final(1)*100);
fprintf('  E11: %.1f → %.1f GPa (%.0f%%)\n', E11(1), E11(end), E11(end)/E11(1)*100);
fprintf('  E22: %.2f → %.2f GPa (%.0f%%)\n', E22(1), E22(end), E22(end)/E22(1)*100);
fprintf('  Matrix strength: %.0f → %.0f MPa (%.0f%%)\n', sigma_m(1)*1000, sigma_m(end)*1000, sigma_m(end)/sigma_m(1)*100);

fprintf('\nOutput: %s\n', fullfile(pwd, results_dir));
fprintf('Time: %.2f seconds\n', toc);
disp('==================================================================');