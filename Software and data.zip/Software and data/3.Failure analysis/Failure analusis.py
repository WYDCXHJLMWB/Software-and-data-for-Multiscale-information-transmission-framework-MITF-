# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 09:51:43 2026

@author: ma'wei'bin
"""

%% CF/TLCP COMPOSITE - MULTI-PHASE CDM MODEL (Final Paper Version v11 - Individual Subplot Output)
% 
% v11 Fixes:
%   1. Interface stress -> interface load-transfer indicator
%   2. Failure sequence changed to objective reporting; no forced "debond -> peak"
%   3. Dominant damage determination changed to "stiffness loss contribution" (instead of directly comparing D values)
%   4. Vi=5% explicitly labeled as "equivalent interface region"
%   5. ★ Each subplot output as an individual image + corresponding data CSV
%   6. ★ Fig.1 kept as one figure; Fig.2 split into 2a+2b; Fig.3 split into 3a+3b+3c+3d
%   7. ★ Fixed mkdir permission error
%   8. ★ Plotting data for each subplot saved separately as CSV

clear; clc; close all;
tic;

% ★ Fix: automatically switch to user directory
try
    user_dir = userpath;
    if ~isempty(user_dir)
        paths = split(user_dir, ';');
        if ~isempty(paths)
            cd(paths{1});
        end
    end
catch
    try
        script_dir = fileparts(mfilename('fullpath'));
        if ~isempty(script_dir) && exist(script_dir, 'dir')
            cd(script_dir);
        end
    catch
        try
            if ispc
                cd('C:\Users\Public\Desktop');
            elseif ismac
                cd('/Users/Shared');
            else
                cd('/tmp');
            end
        catch
        end
    end
end

fprintf('Current working directory: %s\n', pwd);

disp('==================================================================');
disp('CF/TLCP COMPOSITE - MULTI-PHASE CDM MODEL');
disp('Final Paper Version v11 - Individual Subplot Output + Data Export');
disp('==================================================================');

% ========================================================================
% 1. [Experimental Parameters]
% ========================================================================

E_m_25 = 8.0;       % GPa, matrix modulus @25°C
E_f = 294.0;        % GPa, fiber modulus
Vf = 0.61;          % total fiber volume fraction
Vm = 1 - Vf;        % matrix volume fraction (0.39)
Vi = 0.05;          % ★ equivalent interface region volume fraction (not a true independent phase)
Vf_eff = Vf - Vi;   % effective fiber volume fraction (0.56)

fprintf('\n[Volume Fraction Description]\n');
fprintf('  Vf_eff = %.2f (effective fiber)\n', Vf_eff);
fprintf('  Vi     = %.2f (equivalent interface region, not an independent phase)\n', Vi);
fprintf('  Vm     = %.2f (matrix)\n', Vm);

% ========================================================================
% 2. [Literature Parameters]
% ========================================================================

nu_f = 0.20; nu_m = 0.35; nu_i = 0.30;
alpha_f = -0.5e-6; alpha_m = 45e-6; alpha_i = 25e-6;

% ========================================================================
% 3. [Model Parameters] - v10 parameters retained
% ========================================================================

E_i_25 = 12.0;              % GPa, interface equivalent modulus

% --- Matrix damage ---
eps_m0 = 0.0015;            % 0.15%
eps_c_m = 0.007;            % 0.7%
m_m = 2.5;
D_max_m = 0.55;

% --- ★ Interface debonding (interface load-transfer indicator) ---
sigma_int_25 = 25.0;        % MPa, interface load-transfer threshold
m_i = 4.0;
D_max_i = 0.90;

% --- Fiber damage ---
eps_f0 = 0.006;             % 0.6% fiber fully elastic before this
eps_c_f_25 = 0.018;         % 1.8%
m_f = 2.5;

% --- Temperature degradation coefficients ---
beta_m = 0.012;
beta_i = 0.015;
beta_s = 0.010;
beta_f = 0.004;

fprintf('\n[v11 Model Parameters]\n');
fprintf('  eps_m0     = %.2f%%\n', eps_m0*100);
fprintf('  eps_c_m    = %.2f%%\n', eps_c_m*100);
fprintf('  D_max_m    = %.2f\n', D_max_m);
fprintf('  sigma_int  = %.1f MPa (load-transfer threshold)\n', sigma_int_25);
fprintf('  eps_f0     = %.2f%%\n', eps_f0*100);
fprintf('  eps_c_f_25 = %.2f%%\n', eps_c_f_25*100);
fprintf('  m_f        = %.1f\n', m_f);

% ========================================================================
% 4. Temperature-dependent functions
% ========================================================================

T0 = 25;
E_m_func = @(T) E_m_25 * exp(-beta_m * max(0, T-T0));
E_i_func = @(T) E_i_25 * exp(-beta_i * max(0, T-T0));
sigma_int_func = @(T) sigma_int_25 * exp(-beta_s * max(0, T-T0));
eps_c_f_func = @(T) eps_c_f_25 * exp(-beta_f * max(0, T-T0));

T_range = [25, 50, 75, 100, 125, 150];
n_temp = length(T_range);

% ========================================================================
% 5. Material property calculation
% ========================================================================

E_m = zeros(n_temp, 1);
E_i = zeros(n_temp, 1);
sigma_int = zeros(n_temp, 1);
eps_c_f = zeros(n_temp, 1);

for t = 1:n_temp
    T = T_range(t);
    E_m(t) = E_m_func(T);
    E_i(t) = E_i_func(T);
    sigma_int(t) = sigma_int_func(T);
    eps_c_f(t) = eps_c_f_func(T);
end

E11 = Vf_eff * E_f + Vi * E_i + Vm * E_m;

% ========================================================================
% 6. CDM calculation
% ========================================================================

n_steps = 1500;
strain_max = 0.025;
strain_axial = linspace(0, strain_max, n_steps);

stress_axial = zeros(n_steps, n_temp);
stress_axial_MPa = zeros(n_steps, n_temp);
D_m = zeros(n_steps, n_temp);
D_i = zeros(n_steps, n_temp);
D_f = zeros(n_steps, n_temp);
D_total = zeros(n_steps, n_temp);

% ★ Renamed: interface load-transfer indicator
interface_load_indicator = zeros(n_steps, n_temp);
interface_damaged = zeros(n_steps, n_temp);
eps_c_i_actual = NaN(n_temp, 1);

fprintf('\nRunning CDM calculation...\n');

for t = 1:n_temp
    for i = 1:n_steps
        eps = strain_axial(i);
        
        % --- Matrix damage ---
        if eps <= eps_m0
            Dm = 0;
        else
            eps_eff = eps - eps_m0;
            eps_c_eff = eps_c_m - eps_m0;
            if eps_c_eff <= 0; eps_c_eff = 0.001; end
            Dm = D_max_m * (1 - exp(-(eps_eff / eps_c_eff)^m_m));
            Dm = max(0, min(Dm, D_max_m));
        end
        
        % --- ★ Interface load-transfer indicator (not true interface stress) ---
        load_indicator_curr = (1 - Dm) * E_m(t) * eps * 1000;  % MPa
        interface_load_indicator(i, t) = load_indicator_curr;
        
        % --- ★ Interface damage criterion (based on load-transfer indicator) ---
        if isnan(eps_c_i_actual(t))
            if load_indicator_curr >= sigma_int(t) && eps > eps_m0
                eps_c_i_actual(t) = eps;
                interface_damaged(i, t) = 1;
                Di = 0;
            else
                interface_damaged(i, t) = 0;
                Di = 0;
            end
        else
            interface_damaged(i, t) = 1;
            eps_i_onset = eps_c_i_actual(t);
            if eps > eps_i_onset
                Di = D_max_i * (1 - exp(-((eps - eps_i_onset) / eps_i_onset)^m_i));
            else
                Di = 0;
            end
            Di = max(0, min(Di, D_max_i));
        end
        
        % --- Fiber damage ---
        if eps <= eps_f0
            Df = 0;
        else
            eps_eff_f = eps - eps_f0;
            eps_c_eff_f = eps_c_f(t) - eps_f0;
            if eps_c_eff_f <= 0; eps_c_eff_f = 0.001; end
            Df = 1.0 * (1 - exp(-(eps_eff_f / eps_c_eff_f)^m_f));
            Df = max(0, min(Df, 1.0));
        end
        
        % --- Three-phase stiffness superposition ---
        E_eff_fiber = Vf_eff * E_f * (1 - Df);
        E_eff_interface = Vi * E_i(t) * (1 - Di);
        E_eff_matrix = Vm * E_m(t) * (1 - Dm);
        E_eff_total = E_eff_fiber + E_eff_interface + E_eff_matrix;
        
        stress = E_eff_total * eps;
        
        E0_total = Vf_eff*E_f + Vi*E_i(t) + Vm*E_m(t);
        D_total_curr = 1 - (E_eff_total / E0_total);
        
        D_m(i, t) = Dm;
        D_i(i, t) = Di;
        D_f(i, t) = Df;
        D_total(i, t) = D_total_curr;
        stress_axial(i, t) = stress;
        stress_axial_MPa(i, t) = stress * 1000;
    end
end

% ========================================================================
% 7. Peak extraction
% ========================================================================

peak_stress = zeros(1, n_temp);
peak_strain = zeros(1, n_temp);
peak_idx_all = zeros(1, n_temp);

for t = 1:n_temp
    [peak_val, idx] = max(stress_axial(:, t));
    peak_stress(t) = peak_val;
    peak_strain(t) = strain_axial(idx);
    peak_idx_all(t) = idx;
end

% ========================================================================
% 8. ★ Stiffness loss contribution analysis (at peak)
% ========================================================================

fprintf('\n');
disp('==================================================================');
disp('★ Stiffness Loss Contribution Analysis (at Peak)');
disp('==================================================================');
fprintf('  T(°C)   dE_fiber   dE_interface   dE_matrix   Dominant Phase\n');
fprintf('          (GPa)      (GPa)          (GPa)       \n');
fprintf('  ---------------------------------------------------------\n');

contrib_f = zeros(n_temp, 1);
contrib_i = zeros(n_temp, 1);
contrib_m = zeros(n_temp, 1);

for t = 1:n_temp
    idx = peak_idx_all(t);
    
    delta_E_f = Vf_eff * E_f * D_f(idx, t);
    delta_E_i = Vi * E_i(t) * D_i(idx, t);
    delta_E_m = Vm * E_m(t) * D_m(idx, t);
    delta_E_total = delta_E_f + delta_E_i + delta_E_m;
    
    if delta_E_total > 0
        contrib_f(t) = delta_E_f / delta_E_total * 100;
        contrib_i(t) = delta_E_i / delta_E_total * 100;
        contrib_m(t) = delta_E_m / delta_E_total * 100;
    else
        contrib_f(t) = 0; contrib_i(t) = 0; contrib_m(t) = 0;
    end
    
    [~, idx_max] = max([contrib_f(t), contrib_i(t), contrib_m(t)]);
    phases = {'Fiber', 'Interface', 'Matrix'};
    dominant = phases{idx_max};
    
    fprintf('  %5d   %8.2f     %8.2f       %8.2f     %s\n', ...
        T_range(t), delta_E_f, delta_E_i, delta_E_m, dominant);
end

% ========================================================================
% 9. ★ Objective failure sequence report (not forced)
% ========================================================================

fprintf('\n');
disp('==================================================================');
disp('★ Objective Failure Sequence Report');
disp('==================================================================');
fprintf('  T(°C)   Interface Damage eps   Peak eps   Sequence Relation\n');
fprintf('          (%)                    (%)        \n');
fprintf('  ---------------------------------------------------------\n');

for t = 1:n_temp
    if isnan(eps_c_i_actual(t))
        fprintf('  %5d   --                     %.2f      Interface damage not triggered\n', ...
            T_range(t), peak_strain(t)*100);
    elseif eps_c_i_actual(t) < peak_strain(t)
        fprintf('  %5d   %.2f                    %.2f      Interface damage -> Peak\n', ...
            T_range(t), eps_c_i_actual(t)*100, peak_strain(t)*100);
    else
        fprintf('  %5d   %.2f                    %.2f      Peak -> Interface damage\n', ...
            T_range(t), eps_c_i_actual(t)*100, peak_strain(t)*100);
    end
end

% ========================================================================
% 10. Create output directory ★ fixed mkdir permission issue
% ========================================================================

% ★ Use absolute path to create directory
results_dir = fullfile(pwd, 'CF_TLCP_CDM_Figures_v11');

% Try to create directory; if it fails, use temporary directory
try
    if ~exist(results_dir, 'dir')
        mkdir(results_dir);
    end
    test_file = fullfile(results_dir, 'test.txt');
    fid = fopen(test_file, 'w');
    if fid == -1
        error('No write permission');
    end
    fprintf(fid, 'test');
    fclose(fid);
    delete(test_file);
    fprintf('Using directory: %s\n', results_dir);
catch
    if ispc
        results_dir = fullfile(getenv('TEMP'), 'CF_TLCP_CDM_Figures_v11');
    elseif ismac
        results_dir = fullfile('/tmp', 'CF_TLCP_CDM_Figures_v11');
    else
        results_dir = fullfile('/tmp', 'CF_TLCP_CDM_Figures_v11');
    end
    if ~exist(results_dir, 'dir')
        mkdir(results_dir);
    end
    fprintf('Using directory: %s\n', results_dir);
end

data_dir = fullfile(results_dir, 'Data_CSV');
if ~exist(data_dir, 'dir'); mkdir(data_dir); end
fig_dir = fullfile(results_dir, 'Figures');
if ~exist(fig_dir, 'dir'); mkdir(fig_dir); end

colors = [0 0.4470 0.7410; 0.3010 0.7450 0.9330; 0.4660 0.6740 0.1880;
          0.9290 0.6940 0.1250; 0.8500 0.3250 0.0980; 0.4940 0.1840 0.5560];
blue_acad = [0 0.4470 0.7410];
red_acad = [0.8500 0.3250 0.0980];
green_acad = [0.4660 0.6740 0.1880];

save_fig = @(fig, filename) exportgraphics(fig, filename, 'Resolution', 300);

% ========================================================================
% 11. ★ Export all data as CSV
% ========================================================================

fprintf('\nExporting data to CSV...\n');

% 11a. Stress-strain data (all temperatures)
fid = fopen(fullfile(data_dir, 'Data_StressStrain_AllTemps.csv'), 'w');
fprintf(fid, 'Strain_Pct');
for t = 1:n_temp
    fprintf(fid, ',Stress_%dC_MPa', T_range(t));
end
fprintf(fid, '\n');
for i = 1:n_steps
    fprintf(fid, '%.4f', strain_axial(i)*100);
    for t = 1:n_temp
        fprintf(fid, ',%.4f', stress_axial_MPa(i, t));
    end
    fprintf(fid, '\n');
end
fclose(fid);

% 11b. Damage evolution data (25°C)
fid = fopen(fullfile(data_dir, 'Data_Damage_25C.csv'), 'w');
fprintf(fid, 'Strain_Pct,D_m_25C,D_i_25C,D_f_25C,D_total_25C\n');
for i = 1:n_steps
    fprintf(fid, '%.4f,%.6f,%.6f,%.6f,%.6f\n', ...
        strain_axial(i)*100, D_m(i,1), D_i(i,1), D_f(i,1), D_total(i,1));
end
fclose(fid);

% 11c. Interface load-transfer indicator (all temperatures)
fid = fopen(fullfile(data_dir, 'Data_InterfaceIndicator_AllTemps.csv'), 'w');
fprintf(fid, 'Strain_Pct');
for t = 1:n_temp
    fprintf(fid, ',Indicator_%dC_MPa', T_range(t));
end
fprintf(fid, '\n');
for i = 1:n_steps
    fprintf(fid, '%.4f', strain_axial(i)*100);
    for t = 1:n_temp
        fprintf(fid, ',%.4f', interface_load_indicator(i, t));
    end
    fprintf(fid, '\n');
end
fclose(fid);

% 11d. Peak summary data
fid = fopen(fullfile(data_dir, 'Data_PeakSummary.csv'), 'w');
fprintf(fid, 'Temp_C,PeakStress_MPa,PeakStrain_Pct,DebondStrain_Pct,');
fprintf(fid, 'D_m_peak,D_i_peak,D_f_peak,D_total_peak,');
fprintf(fid, 'Contrib_Fiber_Pct,Contrib_Interface_Pct,Contrib_Matrix_Pct,Dominant_Phase\n');
for t = 1:n_temp
    idx = peak_idx_all(t);
    if isnan(eps_c_i_actual(t))
        debond_str = 'NaN';
    else
        debond_str = sprintf('%.4f', eps_c_i_actual(t)*100);
    end
    phases = {'Fiber','Interface','Matrix'};
    [~, idx_max] = max([contrib_f(t), contrib_i(t), contrib_m(t)]);
    fprintf(fid, '%d,%.4f,%.4f,%s,', ...
        T_range(t), peak_stress(t)*1000, peak_strain(t)*100, debond_str);
    fprintf(fid, '%.6f,%.6f,%.6f,%.6f,', ...
        D_m(idx,t), D_i(idx,t), D_f(idx,t), D_total(idx,t));
    fprintf(fid, '%.2f,%.2f,%.2f,%s\n', ...
        contrib_f(t), contrib_i(t), contrib_m(t), phases{idx_max});
end
fclose(fid);

% 11e. Phase stiffness data (25°C)
fid = fopen(fullfile(data_dir, 'Data_PhaseStiffness_25C.csv'), 'w');
fprintf(fid, 'Strain_Pct,E_f_eff_GPa,E_i_eff_GPa,E_m_eff_GPa\n');
t_show = 1;
for i = 1:n_steps
    E_f_eff = E_f * (1 - D_f(i, t_show));
    E_i_eff = E_i(t_show) * (1 - D_i(i, t_show));
    E_m_eff = E_m(t_show) * (1 - D_m(i, t_show));
    fprintf(fid, '%.4f,%.4f,%.4f,%.4f\n', ...
        strain_axial(i)*100, E_f_eff, E_i_eff, E_m_eff);
end
fclose(fid);

fprintf('  Data exported to: %s\n', data_dir);

% ========================================================================
% 12. ★ Generate individual subplots + plotting data for each subplot
% ========================================================================

fprintf('\nGenerating individual subplots...\n');

% ========================================================================
% ★ Fig.1: Stress-strain curves (kept as one figure, 6 temperature curves)
% ========================================================================

fig1 = figure('Position', [50, 50, 900, 650], 'Color', 'white');
hold on;
for t = 1:n_temp
    plot(strain_axial*100, stress_axial_MPa(:, t), ...
        'Color', colors(t,:), 'LineWidth', 2.5);
    plot(strain_axial(peak_idx_all(t))*100, stress_axial_MPa(peak_idx_all(t), t), 'o', ...
        'Color', colors(t,:), 'MarkerSize', 10, 'MarkerFaceColor', colors(t,:), ...
        'HandleVisibility', 'off');
end
xlabel('Strain (%)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Stress (MPa)', 'FontSize', 16, 'FontWeight', 'bold');
xlim([0, 2.0]);
ylim([0, max(stress_axial_MPa(:))*1.05]);
grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
legend(cellstr(num2str(T_range', '%d°C')), 'Location', 'best', 'FontSize', 12);
title('Stress-Strain Response at Different Temperatures', ...
    'FontSize', 17, 'FontWeight', 'bold');
save_fig(fig1, fullfile(fig_dir, 'Fig1_StressStrain_AllTemps.png'));
fprintf('  Saved: Fig1_StressStrain_AllTemps.png\n');
close(fig1);

% ========================================================================
% ★ Fig.2a: 25°C damage evolution (individual figure)
% ========================================================================

fig2a = figure('Position', [50, 50, 900, 650], 'Color', 'white');
hold on;
t_show = 1;
plot(strain_axial*100, D_m(:, t_show), 'b-', 'LineWidth', 2.5, 'DisplayName', 'D_m');
plot(strain_axial*100, D_i(:, t_show), 'r-', 'LineWidth', 2.5, 'DisplayName', 'D_i');
plot(strain_axial*100, D_f(:, t_show), 'g-', 'LineWidth', 2.5, 'DisplayName', 'D_f');
plot(strain_axial*100, D_total(:, t_show), 'k--', 'LineWidth', 2.5, 'DisplayName', 'D_{total}');
xlabel('Strain (%)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Damage Parameter', 'FontSize', 16, 'FontWeight', 'bold');
xlim([0, 2.0]); ylim([0, 1]);
grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
legend('Location', 'best', 'FontSize', 12);
title('Damage Evolution at 25°C', 'FontSize', 17, 'FontWeight', 'bold');
save_fig(fig2a, fullfile(fig_dir, 'Fig2a_DamageEvolution_25C.png'));
fprintf('  Saved: Fig2a_DamageEvolution_25C.png\n');

% ★ Plotting data for Fig.2a: damage evolution data (25°C) - saved separately
fid = fopen(fullfile(data_dir, 'Fig2a_DamageEvolution_25C.csv'), 'w');
fprintf(fid, 'Strain_Pct,D_m,D_i,D_f,D_total\n');
for i = 1:n_steps
    fprintf(fid, '%.4f,%.6f,%.6f,%.6f,%.6f\n', ...
        strain_axial(i)*100, D_m(i,t_show), D_i(i,t_show), D_f(i,t_show), D_total(i,t_show));
end
fclose(fid);
fprintf('  Data saved: Fig2a_DamageEvolution_25C.csv\n');
close(fig2a);

% ========================================================================
% ★ Fig.2b: 25°C interface load-transfer indicator (individual figure)
% ========================================================================

fig2b = figure('Position', [50, 50, 900, 650], 'Color', 'white');
hold on;
t_show = 1;
plot(strain_axial*100, interface_load_indicator(:, t_show), 'b-', 'LineWidth', 2.5);
yline(sigma_int(t_show), 'r--', 'LineWidth', 2);
idx_d = find(interface_damaged(:, t_show) == 1, 1, 'first');
if ~isempty(idx_d)
    plot(strain_axial(idx_d)*100, interface_load_indicator(idx_d, t_show), ...
        'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
    text(strain_axial(idx_d)*100 + 0.02, interface_load_indicator(idx_d, t_show) + 2, ...
        sprintf('Initiation\neps=%.2f%%', strain_axial(idx_d)*100), ...
        'FontSize', 11, 'Color', 'r', 'FontWeight', 'bold');
end
xlabel('Strain (%)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Load Indicator (MPa)', 'FontSize', 16, 'FontWeight', 'bold');
xlim([0, 2.0]); grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
legend('Interface load-transfer indicator', 'Threshold', ...
    'Location', 'best', 'FontSize', 12);
title('Interface Load-Transfer Indicator at 25°C', ...
    'FontSize', 17, 'FontWeight', 'bold');
save_fig(fig2b, fullfile(fig_dir, 'Fig2b_InterfaceIndicator_25C.png'));
fprintf('  Saved: Fig2b_InterfaceIndicator_25C.png\n');

% ★ Plotting data for Fig.2b: interface load-transfer indicator (25°C)
fid = fopen(fullfile(data_dir, 'Fig2b_InterfaceIndicator_25C.csv'), 'w');
fprintf(fid, 'Strain_Pct,Interface_Load_Indicator_MPa,Interface_Strength_MPa,Debonded\n');
for i = 1:n_steps
    fprintf(fid, '%.4f,%.4f,%.1f,%d\n', ...
        strain_axial(i)*100, interface_load_indicator(i,t_show), ...
        sigma_int(t_show), interface_damaged(i,t_show));
end
fclose(fid);
fprintf('  Data saved: Fig2b_InterfaceIndicator_25C.csv\n');
close(fig2b);

% ========================================================================
% ★ Fig.3a: Peak strength vs temperature (individual figure)
% ========================================================================

fig3a = figure('Position', [50, 50, 800, 600], 'Color', 'white');
bar(T_range, peak_stress*1000, 'FaceColor', red_acad, 'EdgeColor', 'k', 'LineWidth', 1.5);
xlabel('Temperature (°C)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Peak Stress (MPa)', 'FontSize', 16, 'FontWeight', 'bold');
grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
title('Peak Strength vs Temperature', 'FontSize', 17, 'FontWeight', 'bold');
for t = 1:n_temp
    text(T_range(t), peak_stress(t)*1000 + 10, sprintf('%.0f', peak_stress(t)*1000), ...
        'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold');
end
save_fig(fig3a, fullfile(fig_dir, 'Fig3a_PeakStrength_vs_T.png'));
fprintf('  Saved: Fig3a_PeakStrength_vs_T.png\n');

% ★ Plotting data for Fig.3a: peak strength vs temperature
fid = fopen(fullfile(data_dir, 'Fig3a_PeakStrength_vs_T.csv'), 'w');
fprintf(fid, 'Temp_C,PeakStress_MPa\n');
for t = 1:n_temp
    fprintf(fid, '%d,%.4f\n', T_range(t), peak_stress(t)*1000);
end
fclose(fid);
fprintf('  Data saved: Fig3a_PeakStrength_vs_T.csv\n');
close(fig3a);

% ========================================================================
% ★ Fig.3b: Peak strain vs temperature (individual figure)
% ========================================================================

fig3b = figure('Position', [50, 50, 800, 600], 'Color', 'white');
bar(T_range, peak_strain*100, 'FaceColor', blue_acad, 'EdgeColor', 'k', 'LineWidth', 1.5);
xlabel('Temperature (°C)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Peak Strain (%)', 'FontSize', 16, 'FontWeight', 'bold');
grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
title('Peak Strain vs Temperature', 'FontSize', 17, 'FontWeight', 'bold');
for t = 1:n_temp
    text(T_range(t), peak_strain(t)*100 + 0.02, sprintf('%.2f', peak_strain(t)*100), ...
        'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold');
end
save_fig(fig3b, fullfile(fig_dir, 'Fig3b_PeakStrain_vs_T.png'));
fprintf('  Saved: Fig3b_PeakStrain_vs_T.png\n');

% ★ Plotting data for Fig.3b: peak strain vs temperature
fid = fopen(fullfile(data_dir, 'Fig3b_PeakStrain_vs_T.csv'), 'w');
fprintf(fid, 'Temp_C,PeakStrain_Pct\n');
for t = 1:n_temp
    fprintf(fid, '%d,%.4f\n', T_range(t), peak_strain(t)*100);
end
fclose(fid);
fprintf('  Data saved: Fig3b_PeakStrain_vs_T.csv\n');
close(fig3b);

% ========================================================================
% ★ Fig.3c: Strength retention vs temperature (individual figure)
% ========================================================================

fig3c = figure('Position', [50, 50, 800, 600], 'Color', 'white');
retention = peak_stress / peak_stress(1) * 100;
plot(T_range, retention, 's-', 'Color', red_acad, 'LineWidth', 2.5, ...
    'MarkerSize', 10, 'MarkerFaceColor', red_acad);
xlabel('Temperature (°C)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Strength Retention (%)', 'FontSize', 16, 'FontWeight', 'bold');
grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
xlim([20, 155]); ylim([0, 105]);
title('Strength Retention vs Temperature', 'FontSize', 17, 'FontWeight', 'bold');
for t = 1:n_temp
    text(T_range(t), retention(t) + 3, sprintf('%.1f%%', retention(t)), ...
        'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold');
end
save_fig(fig3c, fullfile(fig_dir, 'Fig3c_StrengthRetention_vs_T.png'));
fprintf('  Saved: Fig3c_StrengthRetention_vs_T.png\n');

% ★ Plotting data for Fig.3c: strength retention vs temperature
fid = fopen(fullfile(data_dir, 'Fig3c_StrengthRetention_vs_T.csv'), 'w');
fprintf(fid, 'Temp_C,StrengthRetention_Pct\n');
for t = 1:n_temp
    fprintf(fid, '%d,%.4f\n', T_range(t), retention(t));
end
fclose(fid);
fprintf('  Data saved: Fig3c_StrengthRetention_vs_T.csv\n');
close(fig3c);

% ========================================================================
% ★ Fig.3d: Modulus retention vs temperature (individual figure)
% ========================================================================

fig3d = figure('Position', [50, 50, 800, 600], 'Color', 'white');
E11_norm = E11 / E11(1) * 100;
plot(T_range, E11_norm, 'd-', 'Color', blue_acad, 'LineWidth', 2.5, ...
    'MarkerSize', 10, 'MarkerFaceColor', blue_acad);
xlabel('Temperature (°C)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Modulus Retention (%)', 'FontSize', 16, 'FontWeight', 'bold');
grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
xlim([20, 155]); ylim([0, 105]);
title('Modulus Retention vs Temperature', 'FontSize', 17, 'FontWeight', 'bold');
for t = 1:n_temp
    text(T_range(t), E11_norm(t) + 3, sprintf('%.1f%%', E11_norm(t)), ...
        'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold');
end
save_fig(fig3d, fullfile(fig_dir, 'Fig3d_ModulusRetention_vs_T.png'));
fprintf('  Saved: Fig3d_ModulusRetention_vs_T.png\n');

% ★ Plotting data for Fig.3d: modulus retention vs temperature
fid = fopen(fullfile(data_dir, 'Fig3d_ModulusRetention_vs_T.csv'), 'w');
fprintf(fid, 'Temp_C,ModulusRetention_Pct\n');
for t = 1:n_temp
    fprintf(fid, '%d,%.4f\n', T_range(t), E11_norm(t));
end
fclose(fid);
fprintf('  Data saved: Fig3d_ModulusRetention_vs_T.csv\n');
close(fig3d);

% ========================================================================
% ★ Fig.4: Stiffness loss contribution at peak (stacked bar chart, kept as one)
% ========================================================================

fig4 = figure('Position', [50, 50, 900, 650], 'Color', 'white');
bar_data = [contrib_f, contrib_i, contrib_m];
bh = bar(T_range, bar_data, 'stacked');
set(bh(1), 'FaceColor', green_acad, 'EdgeColor', 'k', 'LineWidth', 1);
set(bh(2), 'FaceColor', red_acad, 'EdgeColor', 'k', 'LineWidth', 1);
set(bh(3), 'FaceColor', blue_acad, 'EdgeColor', 'k', 'LineWidth', 1);
xlabel('Temperature (°C)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Contribution to Stiffness Loss (%)', 'FontSize', 16, 'FontWeight', 'bold');
legend('Fiber', 'Interface', 'Matrix', 'Location', 'best', 'FontSize', 12);
grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
title('Damage Contribution at Peak Stress', 'FontSize', 17, 'FontWeight', 'bold');
save_fig(fig4, fullfile(fig_dir, 'Fig4_DamageContribution_Peak.png'));
fprintf('  Saved: Fig4_DamageContribution_Peak.png\n');

% ★ Plotting data for Fig.4: stiffness loss contribution at peak
fid = fopen(fullfile(data_dir, 'Fig4_DamageContribution_Peak.csv'), 'w');
fprintf(fid, 'Temp_C,Fiber_Contrib_Pct,Interface_Contrib_Pct,Matrix_Contrib_Pct\n');
for t = 1:n_temp
    fprintf(fid, '%d,%.2f,%.2f,%.2f\n', ...
        T_range(t), contrib_f(t), contrib_i(t), contrib_m(t));
end
fclose(fid);
fprintf('  Data saved: Fig4_DamageContribution_Peak.csv\n');
close(fig4);

% ========================================================================
% ★ Supplementary Fig. S1: Damage evolution at all temperatures (one individual figure per temperature)
% ========================================================================

for t = 1:n_temp
    figS1 = figure('Position', [50, 50, 800, 600], 'Color', 'white');
    hold on;
    plot(strain_axial*100, D_m(:, t), 'b-', 'LineWidth', 2, 'DisplayName', 'D_m');
    plot(strain_axial*100, D_i(:, t), 'r-', 'LineWidth', 2, 'DisplayName', 'D_i');
    plot(strain_axial*100, D_f(:, t), 'g-', 'LineWidth', 2, 'DisplayName', 'D_f');
    plot(strain_axial*100, D_total(:, t), 'k--', 'LineWidth', 2, 'DisplayName', 'D_{total}');
    xlabel('Strain (%)', 'FontSize', 16, 'FontWeight', 'bold');
    ylabel('Damage Parameter', 'FontSize', 16, 'FontWeight', 'bold');
    xlim([0, 2.0]); ylim([0, 1]);
    grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
    legend('Location', 'best', 'FontSize', 12);
    title(sprintf('Damage Evolution at %d°C', T_range(t)), ...
        'FontSize', 16, 'FontWeight', 'bold');
    save_fig(figS1, fullfile(fig_dir, sprintf('FigS1_Damage_%dC.png', T_range(t))));
    fprintf('  Saved: FigS1_Damage_%dC.png\n', T_range(t));
    
    % ★ Plotting data for supplementary Fig.S1: damage evolution at each temperature
    fid = fopen(fullfile(data_dir, sprintf('FigS1_Damage_%dC.csv', T_range(t))), 'w');
    fprintf(fid, 'Strain_Pct,D_m,D_i,D_f,D_total\n');
    for i = 1:n_steps
        fprintf(fid, '%.4f,%.6f,%.6f,%.6f,%.6f\n', ...
            strain_axial(i)*100, D_m(i,t), D_i(i,t), D_f(i,t), D_total(i,t));
    end
    fclose(fid);
    fprintf('  Data saved: FigS1_Damage_%dC.csv\n', T_range(t));
    close(figS1);
end

% ========================================================================
% ★ Supplementary Fig. S2: Interface load-transfer indicator (one individual figure per temperature)
% ========================================================================

for t = 1:n_temp
    figS2 = figure('Position', [50, 50, 800, 600], 'Color', 'white');
    hold on;
    plot(strain_axial*100, interface_load_indicator(:, t), 'b-', 'LineWidth', 2.5);
    yline(sigma_int(t), 'r--', 'LineWidth', 2);
    idx_d = find(interface_damaged(:, t) == 1, 1, 'first');
    if ~isempty(idx_d)
        plot(strain_axial(idx_d)*100, interface_load_indicator(idx_d, t), ...
            'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
        text(strain_axial(idx_d)*100 + 0.02, interface_load_indicator(idx_d, t) + 2, ...
            sprintf('Initiation\neps=%.2f%%', strain_axial(idx_d)*100), ...
            'FontSize', 10, 'Color', 'r');
    end
    xlabel('Strain (%)', 'FontSize', 16, 'FontWeight', 'bold');
    ylabel('Load Indicator (MPa)', 'FontSize', 16, 'FontWeight', 'bold');
    xlim([0, 2.0]); grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
    legend('Interface load-transfer indicator', 'Threshold', ...
        'Location', 'best', 'FontSize', 12);
    title(sprintf('Interface Load-Transfer Indicator at %d°C', T_range(t)), ...
        'FontSize', 16, 'FontWeight', 'bold');
    save_fig(figS2, fullfile(fig_dir, sprintf('FigS2_InterfaceIndicator_%dC.png', T_range(t))));
    fprintf('  Saved: FigS2_InterfaceIndicator_%dC.png\n', T_range(t));
    
    % ★ Plotting data for supplementary Fig.S2: interface load-transfer indicator at each temperature
    fid = fopen(fullfile(data_dir, sprintf('FigS2_InterfaceIndicator_%dC.csv', T_range(t))), 'w');
    fprintf(fid, 'Strain_Pct,Interface_Load_Indicator_MPa,Interface_Strength_MPa,Debonded\n');
    for i = 1:n_steps
        fprintf(fid, '%.4f,%.4f,%.1f,%d\n', ...
            strain_axial(i)*100, interface_load_indicator(i,t), ...
            sigma_int(t), interface_damaged(i,t));
    end
    fclose(fid);
    fprintf('  Data saved: FigS2_InterfaceIndicator_%dC.csv\n', T_range(t));
    close(figS2);
end

% ========================================================================
% ★ Supplementary Fig. S3: Phase stiffness degradation (25°C, kept as one)
% ========================================================================

figS3 = figure('Position', [50, 50, 900, 650], 'Color', 'white');
t_show = 1;
hold on;
E_f_eff = E_f * (1 - D_f(:, t_show));
E_m_eff = E_m(t_show) * (1 - D_m(:, t_show));
E_i_eff = E_i(t_show) * (1 - D_i(:, t_show));
plot(strain_axial*100, E_f_eff, 'g-', 'LineWidth', 2.5, 'DisplayName', 'E_f(1-D_f)');
plot(strain_axial*100, E_m_eff, 'b-', 'LineWidth', 2.5, 'DisplayName', 'E_m(1-D_m)');
plot(strain_axial*100, E_i_eff, 'r-', 'LineWidth', 2.5, 'DisplayName', 'E_i(1-D_i)');
xlabel('Strain (%)', 'FontSize', 16, 'FontWeight', 'bold');
ylabel('Phase Modulus (GPa)', 'FontSize', 16, 'FontWeight', 'bold');
xlim([0, 2.0]); grid on; box on; set(gca, 'LineWidth', 1.5, 'FontSize', 14);
legend('Location', 'best', 'FontSize', 12);
title('Phase Stiffness Degradation at 25°C', 'FontSize', 17, 'FontWeight', 'bold');
save_fig(figS3, fullfile(fig_dir, 'FigS3_PhaseStiffness_25C.png'));
fprintf('  Saved: FigS3_PhaseStiffness_25C.png\n');

% ★ Plotting data for supplementary Fig.S3: phase stiffness degradation (25°C)
fid = fopen(fullfile(data_dir, 'FigS3_PhaseStiffness_25C.csv'), 'w');
fprintf(fid, 'Strain_Pct,E_f_eff_GPa,E_i_eff_GPa,E_m_eff_GPa\n');
for i = 1:n_steps
    fprintf(fid, '%.4f,%.4f,%.4f,%.4f\n', ...
        strain_axial(i)*100, E_f_eff(i), E_i_eff(i), E_m_eff(i));
end
fclose(fid);
fprintf('  Data saved: FigS3_PhaseStiffness_25C.csv\n');
close(figS3);

% ========================================================================
% ★★★ New: Modulus data export (Excel/TXT) ★★★
% ========================================================================

fprintf('\nExporting modulus data...\n');

% Calculate secant modulus
secant_modulus = zeros(n_temp, 1);
for t = 1:n_temp
    secant_modulus(t) = peak_stress(t) / peak_strain(t) / 1000;  % GPa
end

% Create summary table
T_data = T_range(:);
E11_data = E11(:);
E_m_data = E_m(:);
E_i_data = E_i(:);
E_f_data = E_f * ones(n_temp, 1);
peak_stress_data = peak_stress(:) * 1000;
peak_strain_data = peak_strain(:) * 100;
secant_data = secant_modulus(:);

% Create table
T_modulus = table(T_data, E11_data, E_m_data, E_i_data, E_f_data, ...
    peak_stress_data, peak_strain_data, secant_data, ...
    'VariableNames', {'Temperature_C', 'E11_GPa', 'E_m_GPa', ...
    'E_i_GPa', 'E_f_GPa', 'PeakStress_MPa', 'PeakStrain_Pct', 'SecantModulus_GPa'});

% ★ Save as Excel
excel_file = fullfile(data_dir, 'Modulus_Summary.xlsx');
try
    writetable(T_modulus, excel_file);
    fprintf('  Modulus data exported to: %s\n', excel_file);
catch ME
    fprintf('  Excel export failed: %s\n', ME.message);
    fprintf('  Will try to save as CSV format\n');
end

% ★ Save as CSV (backup)
csv_file = fullfile(data_dir, 'Modulus_Summary.csv');
writetable(T_modulus, csv_file);
fprintf('  Modulus data exported to: %s\n', csv_file);

% ★ Save as TXT format (human-readable)
txt_file = fullfile(data_dir, 'Modulus_Summary.txt');
fid = fopen(txt_file, 'w');
fprintf(fid, '================================================================================\n');
fprintf(fid, 'CF/TLCP COMPOSITE - MODULUS SUMMARY\n');
fprintf(fid, '================================================================================\n\n');
fprintf(fid, '  Temperature    E11        E_m        E_i        E_f    PeakStress  PeakStrain  SecantModulus\n');
fprintf(fid, '      (C)        (GPa)      (GPa)      (GPa)      (GPa)     (MPa)        (%)         (GPa)\n');
fprintf(fid, '--------------------------------------------------------------------------------\n');
for t = 1:n_temp
    fprintf(fid, '  %8d    %8.2f    %8.2f    %8.2f    %8.2f    %10.2f    %8.4f    %12.2f\n', ...
        T_range(t), E11(t), E_m(t), E_i(t), E_f, ...
        peak_stress(t)*1000, peak_strain(t)*100, secant_modulus(t));
end
fprintf(fid, '--------------------------------------------------------------------------------\n');
fprintf(fid, '\nNotes:\n');
fprintf(fid, '  E11: Longitudinal modulus (Voigt mixing rule)\n');
fprintf(fid, '  E_m: Matrix modulus (temperature dependent)\n');
fprintf(fid, '  E_i: Interface modulus (temperature dependent)\n');
fprintf(fid, '  E_f: Fiber modulus (constant, 294 GPa)\n');
fprintf(fid, '  Secant Modulus: Peak Stress / Peak Strain\n');
fclose(fid);
fprintf('  Modulus data exported to: %s\n', txt_file);

% ========================================================================
% 13. Final report
% ========================================================================

fprintf('\n');
disp('==================================================================');
disp('★ Generated File List');
disp('==================================================================');

fprintf('\n[Data Files (CSV)]\n');
fprintf('  %s\n', fullfile(data_dir, 'Data_StressStrain_AllTemps.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Data_Damage_25C.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Data_InterfaceIndicator_AllTemps.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Data_PeakSummary.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Data_PhaseStiffness_25C.csv'));

fprintf('\n[Plotting Data for Each Subplot (CSV)]\n');
fprintf('  %s\n', fullfile(data_dir, 'Fig2a_DamageEvolution_25C.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Fig2b_InterfaceIndicator_25C.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Fig3a_PeakStrength_vs_T.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Fig3b_PeakStrain_vs_T.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Fig3c_StrengthRetention_vs_T.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Fig3d_ModulusRetention_vs_T.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Fig4_DamageContribution_Peak.csv'));
fprintf('  %s\n', fullfile(data_dir, 'FigS1_Damage_%dC.csv (x6)'));
fprintf('  %s\n', fullfile(data_dir, 'FigS2_InterfaceIndicator_%dC.csv (x6)'));
fprintf('  %s\n', fullfile(data_dir, 'FigS3_PhaseStiffness_25C.csv'));

fprintf('\n[Modulus Summary Data]\n');
fprintf('  %s\n', fullfile(data_dir, 'Modulus_Summary.xlsx'));
fprintf('  %s\n', fullfile(data_dir, 'Modulus_Summary.csv'));
fprintf('  %s\n', fullfile(data_dir, 'Modulus_Summary.txt'));

fprintf('\n[Main Figures (Figures/)]\n');
fprintf('  Fig1_StressStrain_AllTemps.png\n');
fprintf('  Fig2a_DamageEvolution_25C.png\n');
fprintf('  Fig2b_InterfaceIndicator_25C.png\n');
fprintf('  Fig3a_PeakStrength_vs_T.png\n');
fprintf('  Fig3b_PeakStrain_vs_T.png\n');
fprintf('  Fig3c_StrengthRetention_vs_T.png\n');
fprintf('  Fig3d_ModulusRetention_vs_T.png\n');
fprintf('  Fig4_DamageContribution_Peak.png\n');

fprintf('\n[Supplementary Figures (Figures/)]\n');
fprintf('  FigS1_Damage_%dC.png (x6)\n');
fprintf('  FigS2_InterfaceIndicator_%dC.png (x6)\n');
fprintf('  FigS3_PhaseStiffness_25C.png\n');

fprintf('\n');
disp('==================================================================');
disp('★ v11 Fix Summary');
disp('==================================================================');
fprintf('  1. Interface stress -> interface load-transfer indicator\n');
fprintf('  2. Failure sequence changed to objective reporting (not forced)\n');
fprintf('  3. Dominant damage determination -> stiffness loss contribution\n');
fprintf('  4. Vi=5%% labeled as "equivalent interface region"\n');
fprintf('  5. Each subplot output as an individual image\n');
fprintf('  6. Data for each subplot saved separately as CSV\n');
fprintf('  7. Fig.1 kept as one; Fig.2 split into 2a+2b; Fig.3 split into 3a+3b+3c+3d\n');
fprintf('  8. Fixed mkdir permission error\n');
fprintf('  9. Added modulus data export (Excel/CSV/TXT)\n');

fprintf('\n');
disp('==================================================================');
fprintf('Output Directory: %s\n', fullfile(pwd, results_dir));
fprintf('Total time: %.2f seconds\n', toc);
disp('==================================================================');
disp('v11 completed');
disp('==================================================================');