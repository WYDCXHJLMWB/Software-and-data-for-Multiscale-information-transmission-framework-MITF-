# -*- coding: utf-8 -*-
"""
Composite Bayesian Ridge SHAP Analysis System - Full Feature Version
Uses the 31 feature names in feature_list.csv and extracts the corresponding
columns from full_data_all_features.csv.
Bayesian Ridge uses LinearExplainer.
Style follows SVR_rbf: extra-large fonts, Top-15 features displayed.
"""

import os
import numpy as np
import pandas as pd
import pickle
import warnings
from datetime import datetime
import matplotlib.pyplot as plt
import shap
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import traceback
import gc

warnings.filterwarnings('ignore')

# ==================== Font settings ====================
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = True  # Enable Unicode minus sign (U+2212)

# ==================== Path settings ====================
MODEL_PATH = r"Your model path"
RESULTS_DIR = r"Your file path"

# ==================== Color constants ====================
COLOR_VF = '#E41A1C'
COLOR_STL = '#0072B2'
COLOR_PHYSICAL = '#009E73'
COLOR_RESIN = '#D55E00'
COLOR_WEAVE = '#CC79A7'
CMAP = plt.cm.coolwarm


def get_feature_category(feature_name):
    """Get feature category"""
    if feature_name == 'Vf_actual':
        return 'Vf_actual'
    elif feature_name.startswith('stl_'):
        return 'STL'
    elif feature_name.startswith('struct_'):
        return 'Physical'
    elif feature_name.startswith('resin_type_'):
        return 'Resin'
    elif feature_name.startswith('weave_type_'):
        return 'Weave'
    else:
        return 'Other'


def get_feature_color(feature_name):
    """Get feature color"""
    if feature_name == 'Vf_actual':
        return COLOR_VF
    elif feature_name.startswith('stl_'):
        return COLOR_STL
    elif feature_name.startswith('struct_'):
        return COLOR_PHYSICAL
    elif feature_name.startswith('resin_type_'):
        return COLOR_RESIN
    elif feature_name.startswith('weave_type_'):
        return COLOR_WEAVE
    else:
        return '#999999'


def format_feature_name(feature_name):
    """Format feature name for display"""
    if feature_name == 'Vf_actual':
        return 'Vf_actual'
    elif feature_name == 'resin_type_K280':
        return 'LCP-1'
    elif feature_name == 'resin_type_K310':
        return 'LCP-2'
    elif feature_name == 'resin_type_K335':
        return 'LCP-3'
    elif feature_name.startswith('resin_type_'):
        return feature_name.replace('resin_type_', '').lower()
    elif feature_name.startswith('weave_type_'):
        w = feature_name.replace('weave_type_', '')
        if w == 'plain':
            return 'weave_plain'
        elif w == 'twill_2x1':
            return 'weave_twill'
        elif w == 'satin_5':
            return 'weave_satin'
        else:
            return f'weave_{w.lower()}'
    elif feature_name.startswith('struct_'):
        name = feature_name.replace('struct_', '')
        parts = name.split('_')
        return '_'.join([p.lower() for p in parts])
    elif feature_name.startswith('stl_'):
        name = feature_name.replace('stl_', '')
        parts = name.split('_')
        return 'stl_' + '_'.join([p.lower() for p in parts])
    else:
        return feature_name.lower()


class BayesianRidgeSHAPAnalyzer:
    def __init__(self, model_path, results_dir):
        self.model_path = model_path
        self.results_dir = results_dir
        self.model = None
        self.scaler = None
        self.feature_names = None
        self.data = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.X_train_scaled = None
        self.X_test_scaled = None
        self.shap_values = None
        self.expected_value = None
        self.sample_ids_train = None
        self.sample_ids_test = None
        self.vf_feature_index = None
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_dir = os.path.join(self.results_dir, f'shap_analysis_BayesianRidge_{timestamp}')
        os.makedirs(self.output_dir, exist_ok=True)
        print(f"\n✅ Output directory: {self.output_dir}")
    
    def load_model_and_data(self):
        """Load model and data"""
        print(f"\n{'='*80}")
        print("📂 Loading model and data...")
        print('='*80)
        
        try:
            # 1. Load model
            print("\n📍 Step 1: Loading model...")
            with open(self.model_path, 'rb') as f:
                model_data = pickle.load(f)
            
            if isinstance(model_data, dict):
                self.model = model_data.get('model')
                self.scaler = model_data.get('scaler_X')
                if 'feature_names' in model_data:
                    self.feature_names = model_data['feature_names']
                    print(f"   ✅ Loaded {len(self.feature_names)} features from model")
                print(f"   ✅ Model type: {type(self.model).__name__}")
            else:
                self.model = model_data
                print(f"   ✅ Model type: {type(self.model).__name__}")
            
            # 2. If the model has no feature names, read them from feature_list.csv
            if self.feature_names is None:
                print("\n📍 Step 2: Loading feature list from feature_list.csv...")
                feature_list_path = os.path.join(
                    self.results_dir, 
                    'predictions', 
                    '贝叶斯岭回归', 
                    'feature_list.csv'
                )
                
                if not os.path.exists(feature_list_path):
                    feature_list_path = os.path.join(self.results_dir, 'all_features_list.csv')
                
                if os.path.exists(feature_list_path):
                    feature_df = pd.read_csv(feature_list_path)
                    if '特征名称' in feature_df.columns:
                        self.feature_names = feature_df['特征名称'].tolist()
                    elif '特征' in feature_df.columns:
                        self.feature_names = feature_df['特征'].tolist()
                    else:
                        self.feature_names = feature_df.iloc[:, 0].tolist()
                    print(f"   ✅ Loaded {len(self.feature_names)} features from feature_list.csv")
                else:
                    print(f"   ❌ feature_list.csv not found!")
                    return False
            
            # Print feature list
            print(f"\n   📋 Model features ({len(self.feature_names)} features):")
            for i, f in enumerate(self.feature_names):
                category = get_feature_category(f)
                marker = " ⭐" if f == 'Vf_actual' else ""
                print(f"      {i+1:2d}. {f}{marker} ({category})")
            
            # Identify Vf_actual
            if 'Vf_actual' in self.feature_names:
                self.vf_feature_index = self.feature_names.index('Vf_actual')
                print(f"\n   ✅ Vf_actual at index: {self.vf_feature_index}")
            
            # 3. Load data from full_data_all_features.csv
            print("\n📍 Step 3: Loading data from full_data_all_features.csv...")
            data_path = os.path.join(self.results_dir, 'full_data_all_features.csv')
            
            if not os.path.exists(data_path):
                data_path = os.path.join(self.results_dir, '..', 'full_data_all_features.csv')
            
            if os.path.exists(data_path):
                self.data = pd.read_csv(data_path)
                print(f"   ✅ Data loaded: {data_path}")
                print(f"       Shape: {self.data.shape}")
            else:
                print(f"   ❌ full_data_all_features.csv not found!")
                return False
            
            if 'E_GPa' not in self.data.columns:
                print(f"   ❌ Target 'E_GPa' not found in data!")
                return False
            
            print(f"   ✅ Target: E_GPa")
            print(f"   ✅ Data columns count: {len(self.data.columns)}")
            
            return True
            
        except Exception as e:
            print(f"❌ Failed to load: {e}")
            traceback.print_exc()
            return False
    
    def prepare_data(self, test_size=0.2, random_state=166):
        """Prepare data - extract columns from full_data using feature_list names"""
        print(f"\n{'='*80}")
        print("🔧 Preparing data...")
        print('='*80)
        
        if self.data is None or self.feature_names is None:
            return False
        
        # Extract the corresponding columns from the data using feature_list names
        X = np.zeros((len(self.data), len(self.feature_names)))
        missing_features = []
        
        print(f"\n   📋 Extracting {len(self.feature_names)} features from data...")
        
        for i, feature_name in enumerate(self.feature_names):
            if feature_name in self.data.columns:
                X[:, i] = self.data[feature_name].fillna(0).values
            else:
                missing_features.append(feature_name)
                X[:, i] = 0
        
        if missing_features:
            print(f"\n   ⚠️ Missing {len(missing_features)} features in data (filled with 0):")
            for f in missing_features[:5]:
                print(f"      - {f}")
            if len(missing_features) > 5:
                print(f"      ... and {len(missing_features)-5} more")
        
        # Target variable
        y = self.data['E_GPa'].values
        
        # Sample IDs
        if 'sample_id' in self.data.columns:
            sample_ids = self.data['sample_id'].values
        else:
            sample_ids = np.arange(len(y))
        
        print(f"\n   ✅ X shape: {X.shape}")
        print(f"   ✅ Features: {len(self.feature_names)}")
        print(f"   ✅ y range: {y.min():.2f} - {y.max():.2f} GPa")
        
        # Split into training and test sets
        self.X_train, self.X_test, self.y_train, self.y_test, self.sample_ids_train, self.sample_ids_test = train_test_split(
            X, y, sample_ids, test_size=test_size, random_state=random_state
        )
        
        print(f"   ✅ Train: {self.X_train.shape[0]}, Test: {self.X_test.shape[0]}")
        
        # Standardization
        if self.scaler is not None:
            try:
                self.X_train_scaled = self.scaler.transform(self.X_train)
                self.X_test_scaled = self.scaler.transform(self.X_test)
                print(f"   ✅ Using model scaler")
            except Exception as e:
                print(f"   ⚠️ Scaler failed: {e}")
                print(f"   🔄 Creating new scaler...")
                self.scaler = StandardScaler()
                self.X_train_scaled = self.scaler.fit_transform(self.X_train)
                self.X_test_scaled = self.scaler.transform(self.X_test)
                print(f"   ✅ Created new scaler")
        else:
            self.scaler = StandardScaler()
            self.X_train_scaled = self.scaler.fit_transform(self.X_train)
            self.X_test_scaled = self.scaler.transform(self.X_test)
            print(f"   ✅ Created new scaler")
        
        # Verify feature count matches
        if self.X_train_scaled.shape[1] != len(self.feature_names):
            print(f"   ❌ Feature count mismatch!")
            print(f"      X_train_scaled: {self.X_train_scaled.shape[1]}")
            print(f"      feature_names: {len(self.feature_names)}")
            return False
        
        print(f"   ✅ Feature count: {self.X_train_scaled.shape[1]}")
        
        return True
    
    def compute_shap_values(self):
        """Compute SHAP values"""
        print(f"\n{'='*80}")
        print("🧮 Calculating SHAP values...")
        print('='*80)
        
        if self.model is None or self.X_train_scaled is None:
            return False
        
        try:
            print(f"   Using LinearExplainer for Bayesian Ridge")
            
            # Try different parameter sets
            try:
                self.explainer = shap.LinearExplainer(
                    self.model, 
                    self.X_train_scaled, 
                    feature_perturbation="interventional"
                )
                print("   ✅ Using LinearExplainer with feature_perturbation='interventional'")
            except TypeError:
                try:
                    self.explainer = shap.LinearExplainer(
                        self.model, 
                        self.X_train_scaled, 
                        feature_dependence="independent"
                    )
                    print("   ✅ Using LinearExplainer with feature_dependence='independent'")
                except TypeError:
                    self.explainer = shap.LinearExplainer(self.model, self.X_train_scaled)
                    print("   ✅ Using LinearExplainer with default parameters")
            
            print(f"   Computing SHAP values...")
            self.shap_values = self.explainer.shap_values(self.X_train_scaled)
            
            if isinstance(self.shap_values, list):
                self.shap_values = self.shap_values[0]
            
            if hasattr(self.explainer, 'expected_value'):
                self.expected_value = self.explainer.expected_value
                if hasattr(self.expected_value, '__iter__'):
                    self.expected_value = self.expected_value[0]
            else:
                self.expected_value = np.mean(self.y_train)
            
            print(f"   ✅ SHAP values shape: {self.shap_values.shape}")
            print(f"   ✅ Expected value: {self.expected_value:.4f}")
            
            # Print feature importance
            importance = np.abs(self.shap_values).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1]
            
            print(f"\n   📊 Feature Importance (All {len(self.feature_names)} features):")
            print(f"   {'Rank':<6} {'Feature Name':<45} {'Mean |SHAP|':<15} {'Category'}")
            print(f"   {'-'*100}")
            for i, idx in enumerate(sorted_idx):
                feature = self.feature_names[idx]
                category = get_feature_category(feature)
                is_vf = "⭐" if feature == 'Vf_actual' else ""
                print(f"   {i+1:<6} {feature:<45} {importance[idx]:<15.8f} {category} {is_vf}")
            
            return True
            
        except Exception as e:
            print(f"❌ Failed: {e}")
            traceback.print_exc()
            return False
    
    def save_training_data(self):
        """Save training data"""
        print(f"\n{'='*80}")
        print("💾 Saving training data...")
        print('='*80)
        
        try:
            # Save raw training data
            train_df = pd.DataFrame(self.X_train, columns=self.feature_names)
            if self.sample_ids_train is not None:
                train_df.insert(0, 'Sample ID', self.sample_ids_train)
            train_df['E_GPa'] = self.y_train
            
            train_path = os.path.join(self.output_dir, 'training_data_raw.csv')
            train_df.to_csv(train_path, index=False, encoding='utf-8-sig')
            print(f"   ✅ Training data (raw) saved: {train_path}")
            print(f"       Shape: {train_df.shape}")
            
            # Save standardized training data
            train_scaled_df = pd.DataFrame(self.X_train_scaled, columns=self.feature_names)
            if self.sample_ids_train is not None:
                train_scaled_df.insert(0, 'Sample ID', self.sample_ids_train)
            train_scaled_df['E_GPa'] = self.y_train
            
            scaled_path = os.path.join(self.output_dir, 'training_data_scaled.csv')
            train_scaled_df.to_csv(scaled_path, index=False, encoding='utf-8-sig')
            print(f"   ✅ Training data (scaled) saved: {scaled_path}")
            print(f"       Shape: {train_scaled_df.shape}")
            
            # Save training set statistics
            stats = {
                'Number of Samples': len(self.y_train),
                'Number of Features': len(self.feature_names),
                'E_GPa Mean': np.mean(self.y_train),
                'E_GPa Std': np.std(self.y_train),
                'E_GPa Min': np.min(self.y_train),
                'E_GPa Max': np.max(self.y_train),
                'E_GPa Median': np.median(self.y_train),
            }
            
            # Add Vf_actual statistics
            if self.vf_feature_index is not None:
                stats['Vf_actual Mean'] = np.mean(self.X_train[:, self.vf_feature_index])
                stats['Vf_actual Std'] = np.std(self.X_train[:, self.vf_feature_index])
                stats['Vf_actual Range'] = f"[{self.X_train[:, self.vf_feature_index].min():.4f}, {self.X_train[:, self.vf_feature_index].max():.4f}]"
            
            stats_df = pd.DataFrame([stats])
            stats_path = os.path.join(self.output_dir, 'training_data_stats.csv')
            stats_df.to_csv(stats_path, index=False, encoding='utf-8-sig')
            print(f"   ✅ Training stats saved: {stats_path}")
            
            return True
            
        except Exception as e:
            print(f"   ❌ Failed to save training data: {e}")
            return False
    
    def save_shap_values(self):
        """Save SHAP results"""
        print(f"\n{'='*80}")
        print("💾 Saving SHAP results...")
        print('='*80)
        
        if self.shap_values is None:
            print(f"   ❌ No SHAP values to save")
            return False
        
        try:
            shap_data = self.shap_values
            
            # 1. Save SHAP values
            shap_df = pd.DataFrame(shap_data, columns=self.feature_names)
            if self.sample_ids_train is not None:
                shap_df.insert(0, 'Sample ID', self.sample_ids_train)
            shap_df['E_GPa_True'] = self.y_train
            
            if self.model is not None and self.X_train_scaled is not None:
                y_pred = self.model.predict(self.X_train_scaled)
                shap_df['E_GPa_Predicted'] = y_pred
            
            shap_path = os.path.join(self.output_dir, 'shap_values_training.csv')
            shap_df.to_csv(shap_path, index=False, encoding='utf-8-sig')
            print(f"   ✅ SHAP values saved: {shap_path}")
            
            # 2. Save feature importance ranking
            importance = np.abs(shap_data).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1]
            
            importance_df = pd.DataFrame({
                'Rank': range(1, len(sorted_idx) + 1),
                'Feature Name': [self.feature_names[i] for i in sorted_idx],
                'Feature Category': [get_feature_category(self.feature_names[i]) for i in sorted_idx],
                'Mean |SHAP|': importance[sorted_idx],
                'Relative Importance (%)': importance[sorted_idx] / importance.sum() * 100
            })
            
            importance_path = os.path.join(self.output_dir, 'feature_importance_ranking.csv')
            importance_df.to_csv(importance_path, index=False, encoding='utf-8-sig')
            print(f"   ✅ Feature importance ranking saved: {importance_path}")
            
            # 3. Save category importance summary
            category_importance = {}
            for i, feature in enumerate(self.feature_names):
                cat = get_feature_category(feature)
                category_importance[cat] = category_importance.get(cat, 0) + importance[i]
            
            total_imp = sum(category_importance.values())
            cat_df = pd.DataFrame({
                'Feature Category': list(category_importance.keys()),
                'Total Importance': list(category_importance.values()),
                'Share (%)': [v/total_imp*100 for v in category_importance.values()]
            })
            cat_df = cat_df.sort_values('Total Importance', ascending=False)
            cat_path = os.path.join(self.output_dir, 'category_importance_summary.csv')
            cat_df.to_csv(cat_path, index=False, encoding='utf-8-sig')
            print(f"   ✅ Category importance summary saved: {cat_path}")
            
            # 4. Save model information
            model_info = {
                'Model Type': type(self.model).__name__,
                'Explainer Type': 'LinearExplainer',
                'Number of Features': len(self.feature_names),
                'Number of Training Samples': len(self.y_train),
                'Number of Test Samples': len(self.y_test),
                'SHAP Expected Value': self.expected_value,
                'Analysis Time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            info_df = pd.DataFrame([model_info])
            info_path = os.path.join(self.output_dir, 'model_shap_info.csv')
            info_df.to_csv(info_path, index=False, encoding='utf-8-sig')
            print(f"   ✅ Model info saved: {info_path}")
            
            return True
            
        except Exception as e:
            print(f"   ❌ Failed to save: {e}")
            return False
    
    def plot_shap(self, top_n=15):
        """Plot SHAP figures - SVR_rbf style, extra-large fonts, Top-15 features"""
        print(f"\n{'='*80}")
        print(f"🎨 Creating SHAP plots (Top {top_n} features, SVR_rbf style)...")
        print('='*80)
        
        if self.shap_values is None:
            return False
        
        try:
            shap_data = self.shap_values
            n_features = len(self.feature_names)
            
            # Sort by importance
            importance = np.abs(shap_data).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1][:top_n]  # only take top n
            sorted_shap = shap_data[:, sorted_idx]
            sorted_X = self.X_train_scaled[:, sorted_idx]
            
            # Simplify feature names for display (using format_feature_name)
            display_features = []
            for f in [self.feature_names[i] for i in sorted_idx]:
                display_features.append(format_feature_name(f))
            
            X_train_df = pd.DataFrame(sorted_X, columns=display_features)
            
            # ===== Set extra-large fonts (consistent with SVR_rbf style) =====
            plt.rcParams['font.size'] = 72
            plt.rcParams['axes.labelsize'] = 82
            plt.rcParams['axes.titlesize'] = 92
            plt.rcParams['xtick.labelsize'] = 72
            plt.rcParams['ytick.labelsize'] = 72
            
            # ===== Figure 1: SHAP Summary Plot =====
            print(f"\n   📊 Plot: SHAP Summary Plot (Top {top_n} features)")
            
            fig = plt.figure(figsize=(45, 28))
            
            shap.summary_plot(
                sorted_shap, 
                X_train_df, 
                feature_names=display_features,
                show=False, 
                max_display=top_n,
                plot_size=None,
                color_bar=True,
                cmap=CMAP
            )
            
            ax = plt.gca()
            
            # ===== Set title (without model name) =====
            ax.set_title(r'SHAP value of Modulus (E)', 
                        fontsize=92, fontweight='bold', 
                        fontname='Times New Roman', pad=60)
            ax.set_xlabel('SHAP value (impact on model output)', 
                         fontsize=82, fontweight='bold', 
                         fontname='Times New Roman', labelpad=55)
            ax.set_ylabel('Features', 
                         fontsize=82, fontweight='bold', 
                         fontname='Times New Roman', labelpad=55)
            
            # ==============================================================
            # Key fix 1: manually take over x-axis tick labels and force U+2212
            # ==============================================================
            xticks = ax.get_xticks()
            xlim = ax.get_xlim()
            valid_xticks = [x for x in xticks if xlim[0] <= x <= xlim[1]]
            
            ax.set_xticks(valid_xticks)
            new_xticklabels = [f"{x:g}".replace('-', '\u2212') for x in valid_xticks]
            ax.set_xticklabels(new_xticklabels, fontname='Times New Roman', 
                               fontsize=72, fontweight='bold')
            # ==============================================================
            
            # ===== X-axis tick font =====
            ax.tick_params(axis='x', labelsize=72, pad=20)
            
            # ===== Y-axis tick font =====
            ax.tick_params(axis='y', labelsize=72, pad=20)
            for label in ax.get_yticklabels():
                label.set_fontname('Times New Roman')
                label.set_fontsize(72)
                label.set_fontweight('bold')
            
            # ===== Adjust dot size (same as SVR, 600) =====
            for collection in ax.collections:
                if hasattr(collection, 'set_sizes'):
                    try:
                        collection.set_sizes([600])
                    except:
                        pass
            
            # ===== Set colorbar fonts =====
            cbar_ax = None
            for fig_ax in fig.get_axes():
                if fig_ax != ax:
                    cbar_ax = fig_ax
                    break
            
            if cbar_ax is not None:
                try:
                    cbar_ax.set_ylabel('Feature value', 
                                       fontsize=68, fontweight='bold', 
                                       fontname='Times New Roman', labelpad=50)
                    cbar_ax.tick_params(labelsize=60)
                    
                    # Key fix: no longer force-overwrite label text, only set font
                    for label in cbar_ax.get_yticklabels():
                        label.set_fontname('Times New Roman')
                        label.set_fontsize(60)
                        label.set_fontweight('bold')
                except:
                    pass
            
            # ===== Get axis limits for drawing bars =====
            x_min, x_max = ax.get_xlim()
            x_range = x_max - x_min
            bar_x_start = x_min - x_range * 0.02
            y_positions = ax.get_yticks()
            y_labels = [label.get_text() for label in ax.get_yticklabels()]
            
            # Get the feature order corresponding to the current y-axis labels
            feature_order = []
            for label in y_labels:
                if label in display_features:
                    feature_order.append(label)
            
            # Compute importance values
            sorted_importance = importance[sorted_idx]
            max_importance = max(sorted_importance)
            
            # ===== Draw light-red importance bars on the left (same as SVR) =====
            for i, feat_name in enumerate(feature_order):
                if i >= len(y_positions):
                    break
                y_pos = y_positions[i]
                
                if feat_name in display_features:
                    feat_idx = display_features.index(feat_name)
                    importance_value = sorted_importance[feat_idx]
                    importance_ratio = importance_value / max_importance
                    bar_width = importance_ratio * x_range * 0.18
                    
                    # Light red bars (alpha 0.35)
                    ax.barh(y_pos, bar_width, left=bar_x_start, 
                           color='#FFB6C1', alpha=0.35, height=0.65,
                           edgecolor='none', linewidth=0)
            
            # ===== Adjust x-axis limits =====
            ax.set_xlim(bar_x_start, x_max)
            
            # ===== Set spine widths =====
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['left'].set_linewidth(3)
            ax.spines['bottom'].set_linewidth(3)
            
            # ===== Add grid lines =====
            ax.grid(True, alpha=0.15, axis='x', which='major', 
                   linestyle='--', linewidth=1.5, color='#999999')
            
            plt.tight_layout()
            
            save_path = os.path.join(self.output_dir, 'shap_summary_plot.png')
            # ==============================================================
            # Key fix 2: drop bbox_inches='tight' to prevent re-layout on save
            # from resetting the tick labels
            # ==============================================================
            plt.savefig(save_path, dpi=300, format='png', pad_inches=1.0)
            # ==============================================================
            plt.close()
            print(f"   ✅ Summary plot saved: {save_path}")
            print(f"   ✅ Title: 92pt bold")
            print(f"   ✅ Axis labels: 82pt bold")
            print(f"   ✅ Tick labels: 72pt bold")
            print(f"   ✅ Dot size: 600")
            print(f"   ✅ Colorbar label: 68pt bold")
            print(f"   ✅ Colorbar tick labels: 60pt bold")
            
            gc.collect()
            
            # ===== Figure 2: SHAP Bar Plot (also Top-15) =====
            print(f"\n   📊 Plot 2: SHAP Bar Plot (Top {top_n} features)")
            
            fig2, ax2 = plt.subplots(figsize=(38, 22))
            
            # Only take Top 15
            top_indices = sorted_idx[:top_n]
            top_features = [self.feature_names[i] for i in top_indices]
            top_importance = importance[top_indices]
            
            show_display = []
            for f in top_features:
                show_display.append(format_feature_name(f))
            
            show_colors = [get_feature_color(f) for f in top_features]
            
            bars = ax2.barh(range(len(show_display)), top_importance, color=show_colors)
            ax2.set_yticks(range(len(show_display)))
            ax2.set_yticklabels(show_display, fontsize=28, fontweight='bold', fontname='Times New Roman')
            ax2.set_xlabel('Mean |SHAP value|', fontsize=36, fontweight='bold', fontname='Times New Roman', labelpad=25)
            ax2.set_title(f'Feature Importance (SHAP) (Top {top_n})', 
                         fontsize=42, fontweight='bold', fontname='Times New Roman', pad=30)
            
            ax2.tick_params(axis='x', labelsize=28)
            for label in ax2.get_xticklabels():
                label.set_fontname('Times New Roman')
                label.set_fontsize(28)
                label.set_fontweight('bold')
            
            ax2.spines['top'].set_visible(False)
            ax2.spines['right'].set_visible(False)
            ax2.spines['left'].set_linewidth(2)
            ax2.spines['bottom'].set_linewidth(2)
            
            from matplotlib.patches import Patch
            legend_elements = [
                Patch(facecolor=COLOR_VF, label='Vf_actual'),
                Patch(facecolor=COLOR_STL, label='STL'),
                Patch(facecolor=COLOR_PHYSICAL, label='Physical'),
                Patch(facecolor=COLOR_RESIN, label='Resin'),
                Patch(facecolor=COLOR_WEAVE, label='Weave'),
            ]
            ax2.legend(handles=legend_elements, loc='lower right', fontsize=26, frameon=True)
            
            plt.tight_layout()
            
            save_path2 = os.path.join(self.output_dir, 'shap_bar_plot.png')
            # Also drop bbox_inches='tight' here for consistency
            plt.savefig(save_path2, dpi=300, format='png')
            plt.close()
            print(f"   ✅ Bar plot saved: {save_path2}")
            
            gc.collect()
            
            # ===== Reset fonts =====
            plt.rcParams['font.size'] = 12
            plt.rcParams['axes.labelsize'] = 14
            plt.rcParams['axes.titlesize'] = 16
            plt.rcParams['xtick.labelsize'] = 11
            plt.rcParams['ytick.labelsize'] = 11
            
            return True
            
        except Exception as e:
            print(f"❌ Failed to create plots: {e}")
            traceback.print_exc()
            return False
    
    def run(self):
        """Run the complete analysis"""
        print(f"\n{'='*80}")
        print("🚀 Bayesian Ridge SHAP Analysis")
        print("   Using the 31 features in feature_list.csv")
        print("   Extracting data from full_data_all_features.csv")
        print('='*80)
        
        if not self.load_model_and_data():
            return False
        
        if not self.prepare_data():
            return False
        
        if not self.compute_shap_values():
            return False
        
        self.save_training_data()
        self.save_shap_values()
        self.plot_shap(top_n=15)
        
        print(f"\n{'='*80}")
        print(f"✅ Analysis completed!")
        print(f"   Output directory: {self.output_dir}")
        print(f"\n   📁 Generated files:")
        print(f"   ├── training_data_raw.csv")
        print(f"   ├── training_data_scaled.csv")
        print(f"   ├── training_data_stats.csv")
        print(f"   ├── shap_values_training.csv")
        print(f"   ├── feature_importance_ranking.csv")
        print(f"   ├── category_importance_summary.csv")
        print(f"   ├── model_shap_info.csv")
        print(f"   ├── shap_summary_plot.png")
        print(f"   └── shap_bar_plot.png")
        print('='*80)
        
        return True


def main():
    try:
        analyzer = BayesianRidgeSHAPAnalyzer(MODEL_PATH, RESULTS_DIR)
        analyzer.run()
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        traceback.print_exc()


if __name__ == "__main__":
    main()