# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 21:53:17 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 10 22:52:18 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Composite Material Bayesian Ridge SHAP Analysis System - Full Feature Version
Uses 31 feature names from feature_list.csv, extracts corresponding columns from full_data_all_features.csv
Bayesian Ridge uses LinearExplainer
Style references Vf_actual feature version, moderate font sizes, shows 31 feature importance in bottom-right
"""

import os
import numpy as np
import pandas as pd
import pickle
import warnings
from datetime import datetime
import matplotlib.pyplot as plt
import shap
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import traceback
import gc

warnings.filterwarnings('ignore')

# ==================== Font Settings ====================
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False

# ==================== Path Settings ====================
MODEL_PATH = r"your model constructed by model construction code"
RESULTS_DIR = r"your model_results_with_resin_weave_seed166_20260805_125145 from model construction code"

# ==================== Color Constants ====================
COLOR_VF = '#E41A1C'
COLOR_STL = '#0072B2'
COLOR_PHYSICAL = '#009E73'
COLOR_RESIN = '#D55E00'
COLOR_WEAVE = '#CC79A7'
CMAP = plt.cm.coolwarm


def get_feature_category(feature_name):
    """Get feature category"""
    if feature_name == 'Vf_actual':
        return 'Vf_actual'
    elif feature_name.startswith('stl_'):
        return 'STL'
    elif feature_name.startswith('struct_'):
        return 'Physical'
    elif feature_name.startswith('resin_type_'):
        return 'Resin'
    elif feature_name.startswith('weave_type_'):
        return 'Weave'
    else:
        return 'Other'


def get_feature_color(feature_name):
    """Get feature color"""
    if feature_name == 'Vf_actual':
        return COLOR_VF
    elif feature_name.startswith('stl_'):
        return COLOR_STL
    elif feature_name.startswith('struct_'):
        return COLOR_PHYSICAL
    elif feature_name.startswith('resin_type_'):
        return COLOR_RESIN
    elif feature_name.startswith('weave_type_'):
        return COLOR_WEAVE
    else:
        return '#999999'


class BayesianRidgeSHAPAnalyzer:
    def __init__(self, model_path, results_dir):
        self.model_path = model_path
        self.results_dir = results_dir
        self.model = None
        self.scaler = None
        self.feature_names = None
        self.data = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.X_train_scaled = None
        self.X_test_scaled = None
        self.shap_values = None
        self.expected_value = None
        self.sample_ids_train = None
        self.sample_ids_test = None
        self.vf_feature_index = None
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_dir = os.path.join(self.results_dir, f'shap_analysis_BayesianRidge_{timestamp}')
        os.makedirs(self.output_dir, exist_ok=True)
        print(f"\nOutput directory: {self.output_dir}")
    
    def load_model_and_data(self):
        """Load model and data"""
        print(f"\n{'='*80}")
        print("Loading model and data...")
        print('='*80)
        
        try:
            # 1. Load model
            print("\nStep 1: Loading model...")
            with open(self.model_path, 'rb') as f:
                model_data = pickle.load(f)
            
            if isinstance(model_data, dict):
                self.model = model_data.get('model')
                self.scaler = model_data.get('scaler_X')
                if 'feature_names' in model_data:
                    self.feature_names = model_data['feature_names']
                    print(f"   Loaded {len(self.feature_names)} features from model")
                print(f"   Model type: {type(self.model).__name__}")
            else:
                self.model = model_data
                print(f"   Model type: {type(self.model).__name__}")
            
            # 2. If feature names not in model, read from feature_list.csv
            if self.feature_names is None:
                print("\nStep 2: Loading feature list from feature_list.csv...")
                feature_list_path = os.path.join(
                    self.results_dir, 
                    'predictions', 
                    'BayesianRidge', 
                    'feature_list.csv'
                )
                
                if not os.path.exists(feature_list_path):
                    feature_list_path = os.path.join(self.results_dir, 'all_features_list.csv')
                
                if os.path.exists(feature_list_path):
                    feature_df = pd.read_csv(feature_list_path)
                    if 'Feature_Name' in feature_df.columns:
                        self.feature_names = feature_df['Feature_Name'].tolist()
                    elif 'Feature' in feature_df.columns:
                        self.feature_names = feature_df['Feature'].tolist()
                    else:
                        self.feature_names = feature_df.iloc[:, 0].tolist()
                    print(f"   Loaded {len(self.feature_names)} features from feature_list.csv")
                else:
                    print(f"   feature_list.csv not found!")
                    return False
            
            # Print feature list
            print(f"\n   Model features ({len(self.feature_names)} features):")
            for i, f in enumerate(self.feature_names):
                category = get_feature_category(f)
                marker = " *" if f == 'Vf_actual' else ""
                print(f"      {i+1:2d}. {f}{marker} ({category})")
            
            # Identify Vf_actual
            if 'Vf_actual' in self.feature_names:
                self.vf_feature_index = self.feature_names.index('Vf_actual')
                print(f"\n   Vf_actual at index: {self.vf_feature_index}")
            
            # 3. Load data from full_data_all_features.csv
            print("\nStep 3: Loading data from full_data_all_features.csv...")
            data_path = os.path.join(self.results_dir, 'full_data_all_features.csv')
            
            if not os.path.exists(data_path):
                data_path = os.path.join(self.results_dir, '..', 'full_data_all_features.csv')
            
            if os.path.exists(data_path):
                self.data = pd.read_csv(data_path)
                print(f"   Data loaded: {data_path}")
                print(f"       Shape: {self.data.shape}")
            else:
                print(f"   full_data_all_features.csv not found!")
                return False
            
            if 'E_GPa' not in self.data.columns:
                print(f"   Target 'E_GPa' not found in data!")
                return False
            
            print(f"   Target: E_GPa")
            print(f"   Data columns count: {len(self.data.columns)}")
            
            return True
            
        except Exception as e:
            print(f"Failed to load: {e}")
            traceback.print_exc()
            return False
    
    def prepare_data(self, test_size=0.2, random_state=166):
        """Prepare data - use feature_list feature names to extract from full_data"""
        print(f"\n{'='*80}")
        print("Preparing data...")
        print('='*80)
        
        if self.data is None or self.feature_names is None:
            return False
        
        # Use feature_list feature names to extract corresponding columns from data
        X = np.zeros((len(self.data), len(self.feature_names)))
        missing_features = []
        
        print(f"\n   Extracting {len(self.feature_names)} features from data...")
        
        for i, feature_name in enumerate(self.feature_names):
            if feature_name in self.data.columns:
                X[:, i] = self.data[feature_name].fillna(0).values
            else:
                missing_features.append(feature_name)
                X[:, i] = 0
        
        if missing_features:
            print(f"\n   Warning: Missing {len(missing_features)} features in data (filled with 0):")
            for f in missing_features[:5]:
                print(f"      - {f}")
            if len(missing_features) > 5:
                print(f"      ... and {len(missing_features)-5} more")
        
        # Target variable
        y = self.data['E_GPa'].values
        
        # Sample IDs
        if 'sample_id' in self.data.columns:
            sample_ids = self.data['sample_id'].values
        else:
            sample_ids = np.arange(len(y))
        
        print(f"\n   X shape: {X.shape}")
        print(f"   Features: {len(self.feature_names)}")
        print(f"   y range: {y.min():.2f} - {y.max():.2f} GPa")
        
        # Split training and test sets
        self.X_train, self.X_test, self.y_train, self.y_test, self.sample_ids_train, self.sample_ids_test = train_test_split(
            X, y, sample_ids, test_size=test_size, random_state=random_state
        )
        
        print(f"   Train: {self.X_train.shape[0]}, Test: {self.X_test.shape[0]}")
        
        # Standardize
        if self.scaler is not None:
            try:
                self.X_train_scaled = self.scaler.transform(self.X_train)
                self.X_test_scaled = self.scaler.transform(self.X_test)
                print(f"   Using model scaler")
            except Exception as e:
                print(f"   Scaler failed: {e}")
                print(f"   Creating new scaler...")
                self.scaler = StandardScaler()
                self.X_train_scaled = self.scaler.fit_transform(self.X_train)
                self.X_test_scaled = self.scaler.transform(self.X_test)
                print(f"   Created new scaler")
        else:
            self.scaler = StandardScaler()
            self.X_train_scaled = self.scaler.fit_transform(self.X_train)
            self.X_test_scaled = self.scaler.transform(self.X_test)
            print(f"   Created new scaler")
        
        # Verify feature count matches
        if self.X_train_scaled.shape[1] != len(self.feature_names):
            print(f"   Feature count mismatch!")
            print(f"      X_train_scaled: {self.X_train_scaled.shape[1]}")
            print(f"      feature_names: {len(self.feature_names)}")
            return False
        
        print(f"   Feature count: {self.X_train_scaled.shape[1]}")
        
        return True
    
    def compute_shap_values(self):
        """Calculate SHAP values"""
        print(f"\n{'='*80}")
        print("Calculating SHAP values...")
        print('='*80)
        
        if self.model is None or self.X_train_scaled is None:
            return False
        
        try:
            print(f"   Using LinearExplainer for Bayesian Ridge")
            
            # Try different parameters
            try:
                self.explainer = shap.LinearExplainer(
                    self.model, 
                    self.X_train_scaled, 
                    feature_perturbation="interventional"
                )
                print("   Using LinearExplainer with feature_perturbation='interventional'")
            except TypeError:
                try:
                    self.explainer = shap.LinearExplainer(
                        self.model, 
                        self.X_train_scaled, 
                        feature_dependence="independent"
                    )
                    print("   Using LinearExplainer with feature_dependence='independent'")
                except TypeError:
                    self.explainer = shap.LinearExplainer(self.model, self.X_train_scaled)
                    print("   Using LinearExplainer with default parameters")
            
            print(f"   Computing SHAP values...")
            self.shap_values = self.explainer.shap_values(self.X_train_scaled)
            
            if isinstance(self.shap_values, list):
                self.shap_values = self.shap_values[0]
            
            if hasattr(self.explainer, 'expected_value'):
                self.expected_value = self.explainer.expected_value
                if hasattr(self.expected_value, '__iter__'):
                    self.expected_value = self.expected_value[0]
            else:
                self.expected_value = np.mean(self.y_train)
            
            print(f"   SHAP values shape: {self.shap_values.shape}")
            print(f"   Expected value: {self.expected_value:.4f}")
            
            # Print feature importance
            importance = np.abs(self.shap_values).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1]
            
            print(f"\n   Feature Importance (All {len(self.feature_names)} features):")
            print(f"   {'Rank':<6} {'Feature Name':<45} {'Mean |SHAP|':<15} {'Category'}")
            print(f"   {'-'*100}")
            for i, idx in enumerate(sorted_idx):
                feature = self.feature_names[idx]
                category = get_feature_category(feature)
                is_vf = "*" if feature == 'Vf_actual' else ""
                print(f"   {i+1:<6} {feature:<45} {importance[idx]:<15.8f} {category} {is_vf}")
            
            return True
            
        except Exception as e:
            print(f"Failed: {e}")
            traceback.print_exc()
            return False
    
    def save_training_data(self):
        """Save training data"""
        print(f"\n{'='*80}")
        print("Saving training data...")
        print('='*80)
        
        try:
            # Save raw training data
            train_df = pd.DataFrame(self.X_train, columns=self.feature_names)
            if self.sample_ids_train is not None:
                train_df.insert(0, 'Sample_ID', self.sample_ids_train)
            train_df['E_GPa'] = self.y_train
            
            train_path = os.path.join(self.output_dir, 'training_data_raw.csv')
            train_df.to_csv(train_path, index=False, encoding='utf-8-sig')
            print(f"   Training data (raw) saved: {train_path}")
            print(f"       Shape: {train_df.shape}")
            
            # Save standardized training data
            train_scaled_df = pd.DataFrame(self.X_train_scaled, columns=self.feature_names)
            if self.sample_ids_train is not None:
                train_scaled_df.insert(0, 'Sample_ID', self.sample_ids_train)
            train_scaled_df['E_GPa'] = self.y_train
            
            scaled_path = os.path.join(self.output_dir, 'training_data_scaled.csv')
            train_scaled_df.to_csv(scaled_path, index=False, encoding='utf-8-sig')
            print(f"   Training data (scaled) saved: {scaled_path}")
            print(f"       Shape: {train_scaled_df.shape}")
            
            # Save training set statistics
            stats = {
                'Sample_Count': len(self.y_train),
                'Feature_Count': len(self.feature_names),
                'E_GPa_Mean': np.mean(self.y_train),
                'E_GPa_Std': np.std(self.y_train),
                'E_GPa_Min': np.min(self.y_train),
                'E_GPa_Max': np.max(self.y_train),
                'E_GPa_Median': np.median(self.y_train),
            }
            
            # Add Vf_actual statistics
            if self.vf_feature_index is not None:
                stats['Vf_actual_Mean'] = np.mean(self.X_train[:, self.vf_feature_index])
                stats['Vf_actual_Std'] = np.std(self.X_train[:, self.vf_feature_index])
                stats['Vf_actual_Range'] = f"[{self.X_train[:, self.vf_feature_index].min():.4f}, {self.X_train[:, self.vf_feature_index].max():.4f}]"
            
            stats_df = pd.DataFrame([stats])
            stats_path = os.path.join(self.output_dir, 'training_data_stats.csv')
            stats_df.to_csv(stats_path, index=False, encoding='utf-8-sig')
            print(f"   Training stats saved: {stats_path}")
            
            return True
            
        except Exception as e:
            print(f"   Failed to save training data: {e}")
            return False
    
    def save_shap_values(self):
        """Save SHAP results"""
        print(f"\n{'='*80}")
        print("Saving SHAP results...")
        print('='*80)
        
        if self.shap_values is None:
            print(f"   No SHAP values to save")
            return False
        
        try:
            shap_data = self.shap_values
            
            # 1. Save SHAP values
            shap_df = pd.DataFrame(shap_data, columns=self.feature_names)
            if self.sample_ids_train is not None:
                shap_df.insert(0, 'Sample_ID', self.sample_ids_train)
            shap_df['E_GPa_True'] = self.y_train
            
            if self.model is not None and self.X_train_scaled is not None:
                y_pred = self.model.predict(self.X_train_scaled)
                shap_df['E_GPa_Predicted'] = y_pred
            
            shap_path = os.path.join(self.output_dir, 'shap_values_training.csv')
            shap_df.to_csv(shap_path, index=False, encoding='utf-8-sig')
            print(f"   SHAP values saved: {shap_path}")
            
            # 2. Save feature importance ranking
            importance = np.abs(shap_data).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1]
            
            importance_df = pd.DataFrame({
                'Rank': range(1, len(sorted_idx) + 1),
                'Feature_Name': [self.feature_names[i] for i in sorted_idx],
                'Feature_Category': [get_feature_category(self.feature_names[i]) for i in sorted_idx],
                'Mean_|SHAP|': importance[sorted_idx],
                'Relative_Importance_%': importance[sorted_idx] / importance.sum() * 100
            })
            
            importance_path = os.path.join(self.output_dir, 'feature_importance_ranking.csv')
            importance_df.to_csv(importance_path, index=False, encoding='utf-8-sig')
            print(f"   Feature importance ranking saved: {importance_path}")
            
            # 3. Save category importance summary
            category_importance = {}
            for i, feature in enumerate(self.feature_names):
                cat = get_feature_category(feature)
                category_importance[cat] = category_importance.get(cat, 0) + importance[i]
            
            total_imp = sum(category_importance.values())
            cat_df = pd.DataFrame({
                'Feature_Category': list(category_importance.keys()),
                'Total_Importance': list(category_importance.values()),
                'Percentage_%': [v/total_imp*100 for v in category_importance.values()]
            })
            cat_df = cat_df.sort_values('Total_Importance', ascending=False)
            cat_path = os.path.join(self.output_dir, 'category_importance_summary.csv')
            cat_df.to_csv(cat_path, index=False, encoding='utf-8-sig')
            print(f"   Category importance summary saved: {cat_path}")
            
            # 4. Save model information
            model_info = {
                'Model_Type': type(self.model).__name__,
                'Explainer_Type': 'LinearExplainer',
                'Feature_Count': len(self.feature_names),
                'Training_Samples': len(self.y_train),
                'Test_Samples': len(self.y_test),
                'SHAP_Expected_Value': self.expected_value,
                'Analysis_Time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            info_df = pd.DataFrame([model_info])
            info_path = os.path.join(self.output_dir, 'model_shap_info.csv')
            info_df.to_csv(info_path, index=False, encoding='utf-8-sig')
            print(f"   Model info saved: {info_path}")
            
            return True
            
        except Exception as e:
            print(f"   Failed to save: {e}")
            return False
    
    def plot_shap(self):
        """Create SHAP plots - larger bold fonts, shows 31 feature importance in bottom-right"""
        print(f"\n{'='*80}")
        print("Creating SHAP plots...")
        print('='*80)
        
        if self.shap_values is None:
            return False
        
        try:
            shap_data = self.shap_values
            n_features = len(self.feature_names)
            
            # Sort by importance
            importance = np.abs(shap_data).mean(axis=0)
            sorted_idx = np.argsort(importance)[::-1]
            sorted_shap = shap_data[:, sorted_idx]
            sorted_X = self.X_train_scaled[:, sorted_idx]
            
            # Simplify feature names for display
            display_features = []
            for f in [self.feature_names[i] for i in sorted_idx]:
                if f == 'Vf_actual':
                    display_features.append('Vf_actual')
                elif f.startswith('resin_type_'):
                    # Resin type names will be LCP-1, LCP-2, LCP-3
                    display_features.append(f.replace('resin_type_', '').lower())
                elif f.startswith('weave_type_'):
                    w = f.replace('weave_type_', '')
                    if w == 'plain':
                        display_features.append('weave_plain')
                    elif w == 'twill_2x1':
                        display_features.append('weave_twill')
                    elif w == 'satin_5':
                        display_features.append('weave_satin')
                    else:
                        display_features.append(f'weave_{w.lower()}')
                elif f.startswith('struct_'):
                    name = f.replace('struct_', '')
                    parts = name.split('_')
                    display_features.append('_'.join([p.lower() for p in parts]))
                elif f.startswith('stl_'):
                    name = f.replace('stl_', '')
                    parts = name.split('_')
                    display_features.append('stl_' + '_'.join([p.lower() for p in parts]))
                else:
                    display_features.append(f.lower())
            
            X_train_df = pd.DataFrame(sorted_X, columns=display_features)
            
            # ===== Set larger font sizes =====
            plt.rcParams['font.size'] = 34
            plt.rcParams['axes.labelsize'] = 42
            plt.rcParams['axes.titlesize'] = 50
            plt.rcParams['xtick.labelsize'] = 34
            plt.rcParams['ytick.labelsize'] = 34
            
            # ===== Plot 1: SHAP Summary Plot =====
            print(f"\n   Plot 1: SHAP Summary Plot")
            
            fig = plt.figure(figsize=(48, 32))
            
            shap.summary_plot(
                sorted_shap, 
                X_train_df, 
                feature_names=display_features,
                show=False, 
                max_display=n_features,
                plot_size=(44, 28),
                color_bar=True,
                cmap=CMAP
            )
            
            ax = plt.gca()
            
            ax.set_title(r'SHAP value of Modulus (E) - Bayesian Ridge Model', 
                        fontsize=50, fontweight='bold', 
                        fontname='Times New Roman', pad=40)
            ax.set_xlabel('SHAP value (impact on model output)', 
                         fontsize=42, fontweight='bold', 
                         fontname='Times New Roman', labelpad=35)
            ax.set_ylabel('Features', 
                         fontsize=42, fontweight='bold', 
                         fontname='Times New Roman', labelpad=35)
            
            ax.tick_params(axis='x', labelsize=34, pad=12)
            for label in ax.get_xticklabels():
                label.set_fontname('Times New Roman')
                label.set_fontsize(34)
                label.set_fontweight('bold')
            
            ax.tick_params(axis='y', labelsize=34, pad=12)
            for label in ax.get_yticklabels():
                label.set_fontname('Times New Roman')
                label.set_fontsize(34)
                label.set_fontweight('bold')
            
            # Adjust point sizes
            for collection in ax.collections:
                if hasattr(collection, 'set_sizes'):
                    try:
                        collection.set_sizes([280])
                    except:
                        pass
            
            # Set colorbar
            cbar_ax = None
            for fig_ax in fig.get_axes():
                if fig_ax != ax:
                    cbar_ax = fig_ax
                    break
            
            if cbar_ax is not None:
                try:
                    cbar_ax.set_ylabel('Feature value (standardized)', 
                                       fontsize=36, fontweight='bold', 
                                       fontname='Times New Roman', labelpad=25)
                    cbar_ax.tick_params(labelsize=32)
                    for label in cbar_ax.get_yticklabels():
                        label.set_fontname('Times New Roman')
                        label.set_fontsize(32)
                        label.set_fontweight('bold')
                except:
                    pass
            
            # ===== Draw feature importance subplot in bottom-right (shows all 31 features) =====
            x_min, x_max = ax.get_xlim()
            y_min, y_max = ax.get_ylim()
            x_range = x_max - x_min
            y_range = y_max - y_min
            
            # Adjust subplot size to accommodate 31 features
            legend_x = x_max - x_range * 0.45
            legend_y = y_min + y_range * 0.01
            legend_width = x_range * 0.40
            legend_height = y_range * 0.42
            
            from matplotlib.patches import Rectangle
            
            rect = Rectangle(
                (legend_x, legend_y),
                legend_width,
                legend_height,
                facecolor='white',
                edgecolor='#888888',
                linewidth=2.0,
                alpha=0.92,
                zorder=100
            )
            ax.add_patch(rect)
            
            ax.text(
                legend_x + legend_width / 2,
                legend_y + legend_height - 0.01 * y_range,
                'Feature Importance',
                fontsize=32,
                fontweight='bold',
                fontname='Times New Roman',
                ha='center',
                va='top',
                color='#000000',
                zorder=101
            )
            
            sep_y = legend_y + legend_height - 0.04 * y_range
            ax.plot([legend_x + 0.02 * x_range, legend_x + legend_width - 0.02 * x_range], 
                   [sep_y, sep_y],
                   color='#888888', linewidth=1.5, zorder=101)
            
            # Show all 31 features
            n_display = len(display_features)
            display_features_sub = display_features[:n_display]
            display_importance = importance[sorted_idx][:n_display]
            max_imp = max(display_importance)
            
            bar_height = (legend_height - 0.08 * y_range) / n_display
            bar_width_ratio = 0.50
            
            # Adjust font sizes based on feature count (31 features use larger fonts)
            if n_display <= 20:
                font_size_name = 22
                font_size_value = 20
            elif n_display <= 25:
                font_size_name = 18
                font_size_value = 16
            else:
                font_size_name = 16
                font_size_value = 14
            
            for i, (feat_name, imp_val) in enumerate(zip(display_features_sub, display_importance)):
                y_pos = sep_y - (i + 0.5) * bar_height - 0.01 * y_range
                if y_pos < legend_y + 0.02 * y_range:
                    break
                imp_ratio = imp_val / max_imp
                bar_width = imp_ratio * legend_width * bar_width_ratio
                bar_x_start = legend_x + legend_width - 0.02 * x_range - bar_width
                
                # Orange bars
                ax.barh(y_pos, bar_width, left=bar_x_start, 
                       color='#E69F00', alpha=0.7, height=bar_height * 0.5, zorder=101)
                
                # Values (bold)
                ax.text(
                    legend_x + legend_width - 0.01 * x_range,
                    y_pos,
                    f'{imp_val:.4f}',
                    fontsize=font_size_value,
                    fontweight='bold',
                    fontname='Times New Roman',
                    ha='right',
                    va='center',
                    color='#D55E00',
                    zorder=101
                )
                
                if len(feat_name) > 20:
                    display_name = feat_name[:18] + '..'
                else:
                    display_name = feat_name
                
                ax.text(
                    legend_x + 0.02 * x_range,
                    y_pos,
                    display_name,
                    fontsize=font_size_name,
                    fontweight='bold',
                    fontname='Times New Roman',
                    ha='left',
                    va='center',
                    color='#1a1a1a',
                    zorder=101
                )
            
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['left'].set_linewidth(2)
            ax.spines['bottom'].set_linewidth(2)
            
            plt.tight_layout()
            
            save_path = os.path.join(self.output_dir, 'shap_summary_plot.png')
            plt.savefig(save_path, dpi=300, bbox_inches='tight', format='png', pad_inches=0.5)
            plt.close()
            print(f"   Summary plot saved: {save_path}")
            
            gc.collect()
            
            # ===== Plot 2: SHAP Bar Plot =====
            print(f"\n   Plot 2: SHAP Bar Plot")
            
            fig2, ax2 = plt.subplots(figsize=(38, 22))
            
            all_importance = np.abs(shap_data).mean(axis=0)
            all_sorted_idx = np.argsort(all_importance)[::-1]
            all_sorted_features = [self.feature_names[i] for i in all_sorted_idx]
            all_sorted_importance = all_importance[all_sorted_idx]
            
            show_display = []
            for f in all_sorted_features:
                if f == 'Vf_actual':
                    show_display.append('Vf_actual')
                elif f.startswith('resin_type_'):
                    # Resin type names will be LCP-1, LCP-2, LCP-3
                    show_display.append(f.replace('resin_type_', '').lower())
                elif f.startswith('weave_type_'):
                    w = f.replace('weave_type_', '')
                    if w == 'plain':
                        show_display.append('weave_plain')
                    elif w == 'twill_2x1':
                        show_display.append('weave_twill')
                    elif w == 'satin_5':
                        show_display.append('weave_satin')
                    else:
                        show_display.append(f'weave_{w.lower()}')
                elif f.startswith('struct_'):
                    name = f.replace('struct_', '')
                    parts = name.split('_')
                    show_display.append('_'.join([p.lower() for p in parts]))
                elif f.startswith('stl_'):
                    name = f.replace('stl_', '')
                    parts = name.split('_')
                    show_display.append('stl_' + '_'.join([p.lower() for p in parts]))
                else:
                    show_display.append(f.lower())
            
            show_colors = [get_feature_color(f) for f in all_sorted_features]
            
            bars = ax2.barh(range(len(show_display)), all_sorted_importance, color=show_colors)
            ax2.set_yticks(range(len(show_display)))
            ax2.set_yticklabels(show_display, fontsize=28, fontweight='bold', fontname='Times New Roman')
            ax2.set_xlabel('Mean |SHAP value|', fontsize=36, fontweight='bold', fontname='Times New Roman', labelpad=25)
            ax2.set_title('Feature Importance (SHAP) - Bayesian Ridge Model', 
                         fontsize=42, fontweight='bold', fontname='Times New Roman', pad=30)
            
            ax2.tick_params(axis='x', labelsize=28)
            for label in ax2.get_xticklabels():
                label.set_fontname('Times New Roman')
                label.set_fontsize(28)
                label.set_fontweight('bold')
            
            ax2.spines['top'].set_visible(False)
            ax2.spines['right'].set_visible(False)
            ax2.spines['left'].set_linewidth(2)
            ax2.spines['bottom'].set_linewidth(2)
            
            from matplotlib.patches import Patch
            legend_elements = [
                Patch(facecolor=COLOR_VF, label='Vf_actual'),
                Patch(facecolor=COLOR_STL, label='STL'),
                Patch(facecolor=COLOR_PHYSICAL, label='Physical'),
                Patch(facecolor=COLOR_RESIN, label='Resin'),
                Patch(facecolor=COLOR_WEAVE, label='Weave'),
            ]
            ax2.legend(handles=legend_elements, loc='lower right', fontsize=26, frameon=True)
            
            plt.tight_layout()
            
            save_path2 = os.path.join(self.output_dir, 'shap_bar_plot.png')
            plt.savefig(save_path2, dpi=300, bbox_inches='tight', format='png')
            plt.close()
            print(f"   Bar plot saved: {save_path2}")
            
            gc.collect()
            
            # ===== Reset fonts =====
            plt.rcParams['font.size'] = 12
            plt.rcParams['axes.labelsize'] = 14
            plt.rcParams['axes.titlesize'] = 16
            plt.rcParams['xtick.labelsize'] = 11
            plt.rcParams['ytick.labelsize'] = 11
            
            return True
            
        except Exception as e:
            print(f"Failed to create plots: {e}")
            traceback.print_exc()
            return False
    
    def run(self):
        """Run full analysis"""
        print(f"\n{'='*80}")
        print("Bayesian Ridge SHAP Analysis")
        print("   Using 31 features from feature_list.csv")
        print("   Extracting data from full_data_all_features.csv")
        print('='*80)
        
        if not self.load_model_and_data():
            return False
        
        if not self.prepare_data():
            return False
        
        if not self.compute_shap_values():
            return False
        
        self.save_training_data()
        self.save_shap_values()
        self.plot_shap()
        
        print(f"\n{'='*80}")
        print(f"Analysis completed!")
        print(f"   Output directory: {self.output_dir}")
        print(f"\n   Generated files:")
        print(f"   ├── training_data_raw.csv")
        print(f"   ├── training_data_scaled.csv")
        print(f"   ├── training_data_stats.csv")
        print(f"   ├── shap_values_training.csv")
        print(f"   ├── feature_importance_ranking.csv")
        print(f"   ├── category_importance_summary.csv")
        print(f"   ├── model_shap_info.csv")
        print(f"   ├── shap_summary_plot.png")
        print(f"   └── shap_bar_plot.png")
        print('='*80)
        
        return True


def main():
    try:
        analyzer = BayesianRidgeSHAPAnalyzer(MODEL_PATH, RESULTS_DIR)
        analyzer.run()
        
    except Exception as e:
        print(f"\nERROR: {e}")
        traceback.print_exc()


if __name__ == "__main__":
    main()