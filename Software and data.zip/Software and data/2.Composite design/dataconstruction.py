# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 21:53:16 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-


import numpy as np
import pandas as pd
import random
import time
import struct
import math
import shutil
import json
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("Composite Material Data Generator (Pure Physics Constraint v7.0)")
print("Pure Data-Driven | Vf Range: 0.20-0.72 (Uniform Distribution)")
print("="*80)

# ============================================================================
# 1. Physics-Constrained STL Generator
# ============================================================================

class PhysicsBasedSTLGenerator:
    """Physics-constrained STL generator"""
    
    @staticmethod
    def generate_weave_model(weave_type, sample_id, output_dir, size=10.0, target_Vf=None):
        """Generate weave structure STL model with physical constraints"""
        try:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            
            filename = output_dir / f"{weave_type}_{sample_id:06d}.stl"
            
            random_seed = sample_id * 1000 + hash(weave_type) % 1000
            np.random.seed(random_seed)
            random.seed(random_seed)
            
            if target_Vf is None:
                target_Vf = np.random.uniform(0.30, 0.65)
            
            if weave_type == 'plain':
                mesh, Vf_actual, params = PhysicsBasedSTLGenerator._create_physical_plain_weave(
                    sample_id, size, target_Vf)
            elif weave_type == 'twill_2x1':
                mesh, Vf_actual, params = PhysicsBasedSTLGenerator._create_physical_twill_weave(
                    sample_id, size, target_Vf)
            elif weave_type == 'satin_5':
                mesh, Vf_actual, params = PhysicsBasedSTLGenerator._create_physical_satin_weave(
                    sample_id, size, target_Vf)
            else:
                mesh, Vf_actual, params = PhysicsBasedSTLGenerator._create_physical_cube(sample_id)
            
            if PhysicsBasedSTLGenerator._write_stl_binary(mesh['vertices'], mesh['faces'], str(filename)):
                return str(filename), Vf_actual, params
            
            return None, 0.0, {}
            
        except Exception as e:
            print(f"  STL generation error: {e}")
            return None, 0.0, {}
    
    @staticmethod
    def _create_physical_cube(sample_id):
        """Create physics-constrained cube model"""
        size_variation = 0.8 + 0.4 * (sample_id % 10) / 10.0
        
        vertices = np.array([
            [0, 0, 0],
            [size_variation, 0, 0],
            [size_variation, size_variation, 0],
            [0, size_variation, 0],
            [0, 0, size_variation * 0.5],
            [size_variation, 0, size_variation * 0.5],
            [size_variation, size_variation, size_variation * 0.5],
            [0, size_variation, size_variation * 0.5],
        ], dtype=np.float32)
        
        for i in range(len(vertices)):
            vertices[i] += np.random.uniform(-0.05, 0.05, 3)
        
        faces = np.array([
            [0, 1, 2], [0, 2, 3],
            [4, 5, 6], [4, 6, 7],
            [0, 1, 5], [0, 5, 4],
            [2, 3, 7], [2, 7, 6],
            [0, 3, 7], [0, 7, 4],
            [1, 2, 6], [1, 6, 5]
        ], dtype=np.int32)
        
        volume = size_variation * size_variation * size_variation * 0.5
        total_volume = size_variation * size_variation * size_variation
        Vf_actual = volume / total_volume if total_volume > 0 else 0.0
        Vf_actual = min(max(Vf_actual, 0.0), 1.0)
        
        params = {
            'size_variation': size_variation,
            'fiber_diameter': 0.7,
            'spacing': 1.0,
            'n_fibers': 5,
            'porosity': 0.015,
            'orientation_efficiency': 0.95,
            'interface_area_density': 0.6,
            'fiber_packing_efficiency': 0.90,
            'mean_fiber_spacing': 1.0,
            'spacing_std': 0.05,
            'waviness': 0.97
        }
        
        return {'vertices': vertices, 'faces': faces}, Vf_actual, params
    
    @staticmethod
    def _calculate_parameters_for_Vf(target_Vf, size, weave_type):
        """Calculate fiber parameters based on target Vf"""
        if weave_type == 'satin_5':
            fiber_diameter = np.random.normal(0.6, 0.1)
        elif weave_type == 'twill_2x1':
            fiber_diameter = np.random.normal(0.7, 0.12)
        else:
            fiber_diameter = np.random.normal(0.8, 0.15)
        fiber_diameter = np.clip(fiber_diameter, 0.3, 1.2)
        
        n_fibers = int(np.sqrt(target_Vf) * 20)
        n_fibers = max(4, min(n_fibers, 15))
        
        target_area_fraction = target_Vf / (1 - 0.02)
        spacing = fiber_diameter * np.sqrt(np.pi / (4 * target_area_fraction * n_fibers / size))
        spacing = np.clip(spacing, 0.3, 2.5)
        
        n_fibers = max(4, int(size / spacing))
        n_fibers = min(n_fibers, 15)
        
        return fiber_diameter, spacing, n_fibers
    
    @staticmethod
    def _create_physical_plain_weave(sample_id, size, target_Vf):
        """Create physics-constrained plain weave model"""
        vertices = []
        faces = []
        face_offset = 0
        total_fiber_volume = 0.0
        
        fiber_diameter, spacing, n_fibers = PhysicsBasedSTLGenerator._calculate_parameters_for_Vf(
            target_Vf, size, 'plain')
        
        porosity = np.random.normal(0.018, 0.006)
        porosity = np.clip(porosity, 0.005, 0.04)
        
        orientation_efficiency = np.random.normal(0.93, 0.02)
        orientation_efficiency = np.clip(orientation_efficiency, 0.88, 0.97)
        
        waviness = np.random.uniform(0.93, 1.0)
        spacing_std = spacing * np.random.uniform(0.02, 0.08)
        packing_efficiency = 0.80 + 0.15 * np.random.random()
        
        params = {
            'fiber_diameter': fiber_diameter,
            'spacing': spacing,
            'n_fibers': n_fibers,
            'porosity': porosity,
            'orientation_efficiency': orientation_efficiency,
            'waviness': waviness,
            'interface_area_density': 0.5 + 0.4 * np.random.random(),
            'fiber_packing_efficiency': packing_efficiency,
            'mean_fiber_spacing': spacing,
            'spacing_std': spacing_std,
            'uniformity_factor': 0.95 + 0.05 * np.random.random()
        }
        
        # Warp fibers
        for i in range(n_fibers):
            y_base = i * spacing - size/2 + spacing/2
            z_base = 0.0
            
            y_offset = np.random.normal(0, spacing * 0.06)
            z_offset = np.random.normal(0, fiber_diameter * 0.12)
            
            if i % 2 == 0:
                z_offset += fiber_diameter * 0.3 * np.random.uniform(0.8, 1.2)
            
            start = [-size/2, y_base + y_offset, z_base + z_offset]
            end = [size/2, y_base + y_offset, z_base + z_offset]
            
            fiber_verts, fiber_faces, fiber_volume = PhysicsBasedSTLGenerator._create_cylindrical_fiber(
                start, end, fiber_diameter/2, segments=8
            )
            total_fiber_volume += fiber_volume
            
            vertices.extend(fiber_verts)
            for face in fiber_faces:
                faces.append([f + face_offset for f in face])
            face_offset = len(vertices)
        
        # Weft fibers
        for i in range(n_fibers):
            x_base = i * spacing - size/2 + spacing/2
            z_base = fiber_diameter * 0.5
            
            x_offset = np.random.normal(0, spacing * 0.06)
            z_offset = np.random.normal(0, fiber_diameter * 0.12)
            
            if i % 2 == 0:
                z_offset += fiber_diameter * 0.3 * np.random.uniform(0.8, 1.2)
            
            start = [x_base + x_offset, -size/2, z_base + z_offset]
            end = [x_base + x_offset, size/2, z_base + z_offset]
            
            fiber_verts, fiber_faces, fiber_volume = PhysicsBasedSTLGenerator._create_cylindrical_fiber(
                start, end, fiber_diameter/2, segments=8
            )
            total_fiber_volume += fiber_volume
            
            vertices.extend(fiber_verts)
            for face in fiber_faces:
                faces.append([f + face_offset for f in face])
            face_offset = len(vertices)
        
        total_volume = size * size * size
        Vf_actual = total_fiber_volume / total_volume if total_volume > 0 else 0.0
        Vf_actual = min(max(Vf_actual, 0.0), 0.72)
        Vf_actual *= (1 - porosity)
        
        return {
            'vertices': np.array(vertices, dtype=np.float32),
            'faces': np.array(faces, dtype=np.int32)
        }, Vf_actual, params
    
    @staticmethod
    def _create_physical_twill_weave(sample_id, size, target_Vf):
        """Create physics-constrained twill weave model"""
        vertices = []
        faces = []
        face_offset = 0
        total_fiber_volume = 0.0
        
        fiber_diameter, spacing, n_fibers = PhysicsBasedSTLGenerator._calculate_parameters_for_Vf(
            target_Vf, size, 'twill_2x1')
        
        porosity = np.random.normal(0.014, 0.005)
        porosity = np.clip(porosity, 0.005, 0.035)
        
        orientation_efficiency = np.random.normal(0.95, 0.015)
        orientation_efficiency = np.clip(orientation_efficiency, 0.90, 0.98)
        
        waviness = np.random.uniform(0.94, 1.0)
        spacing_std = spacing * np.random.uniform(0.02, 0.07)
        packing_efficiency = 0.82 + 0.15 * np.random.random()
        
        params = {
            'fiber_diameter': fiber_diameter,
            'spacing': spacing,
            'n_fibers': n_fibers,
            'porosity': porosity,
            'orientation_efficiency': orientation_efficiency,
            'waviness': waviness,
            'interface_area_density': 0.5 + 0.4 * np.random.random(),
            'fiber_packing_efficiency': packing_efficiency,
            'mean_fiber_spacing': spacing,
            'spacing_std': spacing_std,
            'uniformity_factor': 0.95 + 0.05 * np.random.random()
        }
        
        pattern_offset = sample_id % 3
        
        # Warp fibers
        for i in range(n_fibers):
            for j in range(n_fibers):
                if (i + j + pattern_offset) % 3 == 0:
                    y = j * spacing - size/2 + spacing/2 + np.random.normal(0, spacing*0.05)
                    z = 0.0
                    
                    if (i + j) % 2 == 0:
                        z += fiber_diameter * 0.3 * np.random.uniform(0.8, 1.2)
                    
                    start = [-size/2 + i*spacing*0.3, y, z]
                    end = [size/2 - i*spacing*0.3, y, z]
                    
                    fiber_verts, fiber_faces, fiber_volume = PhysicsBasedSTLGenerator._create_cylindrical_fiber(
                        start, end, fiber_diameter/2, segments=7
                    )
                    total_fiber_volume += fiber_volume
                    
                    vertices.extend(fiber_verts)
                    for face in fiber_faces:
                        faces.append([f + face_offset for f in face])
                    face_offset = len(vertices)
        
        # Weft fibers
        for i in range(n_fibers):
            for j in range(n_fibers):
                if (i + j + pattern_offset) % 3 == 1:
                    x = i * spacing - size/2 + spacing/2 + np.random.normal(0, spacing*0.05)
                    z = fiber_diameter * 0.6
                    
                    if (i + j) % 2 == 1:
                        z += fiber_diameter * 0.2 * np.random.uniform(0.8, 1.2)
                    
                    start = [x, -size/2 + j*spacing*0.3, z]
                    end = [x, size/2 - j*spacing*0.3, z]
                    
                    fiber_verts, fiber_faces, fiber_volume = PhysicsBasedSTLGenerator._create_cylindrical_fiber(
                        start, end, fiber_diameter/2, segments=7
                    )
                    total_fiber_volume += fiber_volume
                    
                    vertices.extend(fiber_verts)
                    for face in fiber_faces:
                        faces.append([f + face_offset for f in face])
                    face_offset = len(vertices)
        
        total_volume = size * size * size
        Vf_actual = total_fiber_volume / total_volume if total_volume > 0 else 0.0
        Vf_actual = min(max(Vf_actual, 0.0), 0.72)
        Vf_actual *= (1 - porosity)
        
        return {
            'vertices': np.array(vertices, dtype=np.float32),
            'faces': np.array(faces, dtype=np.int32)
        }, Vf_actual, params
    
    @staticmethod
    def _create_physical_satin_weave(sample_id, size, target_Vf):
        """Create physics-constrained satin weave model"""
        vertices = []
        faces = []
        face_offset = 0
        total_fiber_volume = 0.0
        
        fiber_diameter, spacing, n_fibers = PhysicsBasedSTLGenerator._calculate_parameters_for_Vf(
            target_Vf, size, 'satin_5')
        
        porosity = np.random.normal(0.01, 0.004)
        porosity = np.clip(porosity, 0.003, 0.03)
        
        orientation_efficiency = np.random.normal(0.97, 0.012)
        orientation_efficiency = np.clip(orientation_efficiency, 0.93, 0.99)
        
        waviness = np.random.uniform(0.95, 1.0)
        spacing_std = spacing * np.random.uniform(0.015, 0.06)
        packing_efficiency = 0.85 + 0.12 * np.random.random()
        
        params = {
            'fiber_diameter': fiber_diameter,
            'spacing': spacing,
            'n_fibers': n_fibers,
            'porosity': porosity,
            'orientation_efficiency': orientation_efficiency,
            'waviness': waviness,
            'interface_area_density': 0.5 + 0.4 * np.random.random(),
            'fiber_packing_efficiency': packing_efficiency,
            'mean_fiber_spacing': spacing,
            'spacing_std': spacing_std,
            'uniformity_factor': 0.96 + 0.04 * np.random.random()
        }
        
        satin_pattern_id = sample_id % 4
        
        if satin_pattern_id == 0:
            pattern = [
                [1, 0, 0, 0, 0],
                [0, 0, 1, 0, 0],
                [0, 0, 0, 0, 1],
                [0, 1, 0, 0, 0],
                [0, 0, 0, 1, 0]
            ]
        elif satin_pattern_id == 1:
            pattern = [
                [1, 0, 0, 0, 0],
                [0, 0, 0, 1, 0],
                [0, 1, 0, 0, 0],
                [0, 0, 0, 0, 1],
                [0, 0, 1, 0, 0]
            ]
        else:
            pattern = [
                [0, 1, 0, 0, 0],
                [0, 0, 0, 0, 1],
                [1, 0, 0, 0, 0],
                [0, 0, 0, 1, 0],
                [0, 0, 1, 0, 0]
            ]
        
        # Warp fibers
        for i in range(n_fibers):
            for j in range(n_fibers):
                if pattern[i % 5][j % 5] == 1:
                    y = j * spacing - size/2 + spacing/2 + np.random.normal(0, spacing*0.05)
                    z = fiber_diameter * 0.7
                    
                    start = [-size/2, y, z]
                    end = [size/2, y, z]
                    
                    fiber_verts, fiber_faces, fiber_volume = PhysicsBasedSTLGenerator._create_cylindrical_fiber(
                        start, end, fiber_diameter/2, segments=8
                    )
                    total_fiber_volume += fiber_volume
                    
                    vertices.extend(fiber_verts)
                    for face in fiber_faces:
                        faces.append([f + face_offset for f in face])
                    face_offset = len(vertices)
        
        # Weft fibers
        for i in range(n_fibers):
            for j in range(n_fibers):
                if pattern[j % 5][i % 5] == 1:
                    x = i * spacing - size/2 + spacing/2 + np.random.normal(0, spacing*0.05)
                    z = fiber_diameter * 0.2
                    
                    start = [x, -size/2, z]
                    end = [x, size/2, z]
                    
                    fiber_verts, fiber_faces, fiber_volume = PhysicsBasedSTLGenerator._create_cylindrical_fiber(
                        start, end, fiber_diameter/2, segments=7
                    )
                    total_fiber_volume += fiber_volume
                    
                    vertices.extend(fiber_verts)
                    for face in fiber_faces:
                        faces.append([f + face_offset for f in face])
                    face_offset = len(vertices)
        
        total_volume = size * size * size
        Vf_actual = total_fiber_volume / total_volume if total_volume > 0 else 0.0
        Vf_actual = min(max(Vf_actual, 0.0), 0.72)
        Vf_actual *= (1 - porosity)
        
        return {
            'vertices': np.array(vertices, dtype=np.float32),
            'faces': np.array(faces, dtype=np.int32)
        }, Vf_actual, params
    
    @staticmethod
    def _create_cylindrical_fiber(start, end, radius, segments=8):
        """Create cylindrical fiber"""
        start = np.array(start, dtype=np.float32)
        end = np.array(end, dtype=np.float32)
        
        direction = end - start
        length = np.linalg.norm(direction)
        
        if length < 1e-6:
            return [], [], 0.0
        
        fiber_volume = math.pi * radius * radius * length
        
        direction = direction / length
        
        if abs(direction[0]) < 0.1 and abs(direction[1]) < 0.1:
            up = np.array([1.0, 0.0, 0.0], dtype=np.float32)
        else:
            up = np.array([0.0, 0.0, 1.0], dtype=np.float32)
        
        right = np.cross(direction, up)
        right_norm = np.linalg.norm(right)
        
        if right_norm < 1e-6:
            up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
            right = np.cross(direction, up)
            right_norm = np.linalg.norm(right)
        
        right = right / right_norm
        up = np.cross(right, direction)
        
        vertices = []
        faces = []
        
        side_vertices_start = []
        side_vertices_end = []
        
        for i in range(segments):
            angle = 2 * math.pi * i / segments
            cos_a = math.cos(angle)
            sin_a = math.sin(angle)
            
            radial = right * cos_a + up * sin_a
            vertex_start = start + radial * radius
            vertex_end = end + radial * radius
            
            vertices.append(vertex_start)
            vertices.append(vertex_end)
            
            side_vertices_start.append(len(vertices) - 2)
            side_vertices_end.append(len(vertices) - 1)
        
        for i in range(segments):
            next_i = (i + 1) % segments
            
            faces.append([
                side_vertices_start[i],
                side_vertices_start[next_i],
                side_vertices_end[i]
            ])
            faces.append([
                side_vertices_end[i],
                side_vertices_start[next_i],
                side_vertices_end[next_i]
            ])
        
        start_face_center = len(vertices)
        vertices.append(start)
        
        end_face_center = len(vertices)
        vertices.append(end)
        
        offset = len(vertices)
        
        for i in range(segments):
            vertices.append(vertices[side_vertices_start[i]])
        
        for i in range(segments):
            vertices.append(vertices[side_vertices_end[i]])
        
        for i in range(segments):
            next_i = (i + 1) % segments
            
            faces.append([
                start_face_center,
                offset + i,
                offset + next_i
            ])
            
            faces.append([
                end_face_center,
                offset + segments + next_i,
                offset + segments + i
            ])
        
        return vertices, faces, fiber_volume
    
    @staticmethod
    def _write_stl_binary(vertices, faces, filename):
        """Write binary STL file"""
        try:
            with open(filename, 'wb') as f:
                header = b'Composite Weave Model - Physical STL'
                header = header.ljust(80, b'\x00')
                f.write(header)
                
                num_faces = len(faces)
                f.write(struct.pack('<I', num_faces))
                
                for face in faces:
                    if len(face) != 3:
                        continue
                    
                    v0 = vertices[face[0]]
                    v1 = vertices[face[1]]
                    v2 = vertices[face[2]]
                    
                    normal = np.cross(v1 - v0, v2 - v0)
                    norm = np.linalg.norm(normal)
                    
                    if norm > 0:
                        normal = normal / norm
                    else:
                        normal = np.array([0.0, 0.0, 1.0])
                    
                    f.write(struct.pack('<3f', normal[0], normal[1], normal[2]))
                    f.write(struct.pack('<3f', v0[0], v0[1], v0[2]))
                    f.write(struct.pack('<3f', v1[0], v1[1], v1[2]))
                    f.write(struct.pack('<3f', v2[0], v2[1], v2[2]))
                    f.write(struct.pack('<H', 0))
            
            return True
            
        except Exception as e:
            return False


# ============================================================================
# 2. Pure Physics Data Generator (No Reference Design Points)
# ============================================================================

class PhysicsBasedDataGenerator:
    """
    Pure physics-constrained composite material data generator
    No reference design points, purely data-driven
    """
    
    def __init__(self, generate_stl=True):
        # ===== Material Properties (Fixed) =====
        self.fiber_E = 294.0  # GPa - Carbon fiber T800
        
        # Resin types - Updated to LCP series
        self.resin_types = {
            'LCP-1': {'E': 6.142, 'name': 'LCP-1 Resin', 'toughening': 1.0},
            'LCP-2': {'E': 6.675, 'name': 'LCP-2 Resin', 'toughening': 1.05},
            'LCP-3': {'E': 6.121, 'name': 'LCP-3 Resin', 'toughening': 0.95}
        }
        
        # ===== Weave Type Parameters =====
        self.weave_types = {
            'plain': {
                'name': 'Plain Weave',
                'orientation_base': 0.92,
                'crimp_factor': 0.92,
                'max_Vf': 0.55
            },
            'twill_2x1': {
                'name': '2x1 Twill Weave',
                'orientation_base': 0.95,
                'crimp_factor': 0.95,
                'max_Vf': 0.60
            },
            'satin_5': {
                'name': '5-Harness Satin Weave',
                'orientation_base': 0.97,
                'crimp_factor': 0.97,
                'max_Vf': 0.65
            }
        }
        
        self.generate_stl = generate_stl
        self.stl_generator = PhysicsBasedSTLGenerator()
        
        print(f"\nMaterial Configuration:")
        print(f"  Fiber: Carbon Fiber T800 (E = {self.fiber_E} GPa)")
        print(f"  Resin Types: LCP-1, LCP-2, LCP-3")
        print(f"  Weave Types: Plain, 2x1 Twill, 5-Harness Satin")
    
    def calculate_modulus(self, Vf_actual, resin_type, weave_type, structural_params):
        """
        Physical modulus calculation - ensures modulus is in reasonable physical range
        """
        resin_E = self.resin_types[resin_type]['E']
        resin_tough = self.resin_types[resin_type]['toughening']
        weave_info = self.weave_types[weave_type]
        
        # ===== 1. Rule of Mixtures =====
        effective_Vf = max(0.05, min(Vf_actual, 0.72))
        E_voigt = effective_Vf * self.fiber_E + (1 - effective_Vf) * resin_E
        
        # ===== 2. Efficiency Factors (Physically Reasonable Range) =====
        # Orientation efficiency
        base_ori = weave_info['orientation_base']
        ori_variation = np.random.normal(0, 0.015)
        eta_orientation = np.clip(base_ori + ori_variation, 0.88, 0.99)
        
        # Crimp efficiency
        base_crimp = weave_info['crimp_factor']
        fiber_d = structural_params.get('fiber_diameter', 0.7)
        crimp_modifier = 1.0 - 0.02 * (fiber_d - 0.5) / 0.7
        eta_crimp = np.clip(base_crimp * crimp_modifier, 0.88, 0.98)
        
        # Interface efficiency
        interface_density = structural_params.get('interface_area_density', 0.6)
        eta_interface = np.clip(0.90 + 0.10 * (1 - np.exp(-interface_density * 1.0)), 0.88, 0.98)
        
        # Defect efficiency
        porosity = structural_params.get('porosity', 0.015)
        eta_defect = np.clip(np.exp(-porosity * 2.5), 0.93, 1.0)
        
        # Packing efficiency
        packing = structural_params.get('fiber_packing_efficiency', 0.88)
        eta_packing = np.clip(0.88 + 0.12 * packing, 0.85, 0.98)
        
        # ===== 3. Total Efficiency =====
        total_efficiency = np.clip(
            eta_orientation * eta_crimp * eta_interface * eta_defect * eta_packing,
            0.70, 0.95
        )
        
        # ===== 4. Calculate Modulus =====
        E_coupled = E_voigt * total_efficiency * resin_tough
        
        # ===== 5. Add Random Fluctuation =====
        quality_index = eta_orientation * eta_crimp * eta_interface * eta_defect
        variation_range = 0.005 + 0.02 * (1 - quality_index)
        process_variation = np.clip(1.0 + np.random.normal(0, variation_range/2), 0.95, 1.05)
        
        E_final = E_coupled * process_variation
        
        # ===== 6. Physical Range Limits =====
        E_lower = 1.0 / (effective_Vf/self.fiber_E + (1-effective_Vf)/resin_E)
        E_final = np.clip(E_final, E_lower * 0.85, E_voigt * 1.01)
        
        return {
            'Vf_actual': round(effective_Vf, 4),
            'resin_E_GPa': resin_E,
            'E_voigt_GPa': round(E_voigt, 2),
            'E_reuss_GPa': round(E_lower, 2),
            'E_GPa': round(E_final, 2),
            'E_MPa': round(E_final * 1000, 0),
            
            'eta_orientation': round(eta_orientation, 4),
            'eta_crimp': round(eta_crimp, 4),
            'eta_interface': round(eta_interface, 4),
            'eta_defect': round(eta_defect, 4),
            'eta_packing': round(eta_packing, 4),
            'total_efficiency': round(total_efficiency, 4),
            'process_variation': round(process_variation, 4),
            
            'interface_area_density': round(interface_density, 4),
            'porosity': round(porosity, 4),
            'spacing_std': structural_params.get('spacing_std', 0.05),
            'quality_index': round(quality_index, 4)
        }
    
    def generate_dataset(self, n_samples=2000, output_dir=None):
        """Generate physics-constrained dataset - pure uniform distribution"""
        print(f"\nGenerating {n_samples} physics-constrained samples...")
        print(f"   Vf Generation Strategy: Pure Uniform Distribution U(0.20, 0.72)")
        
        if output_dir is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_dir = Path(f"composite_physical_data_{timestamp}")
        else:
            output_dir = Path(output_dir)
        
        output_dir.mkdir(parents=True, exist_ok=True)
        
        stl_dir = output_dir / "stl_models"
        stl_dir.mkdir(exist_ok=True)
        
        temp_dir = Path("stl_temp_output")
        temp_dir.mkdir(exist_ok=True)
        
        all_samples = []
        stl_manifest = []
        sample_id = 0
        
        start_time = time.time()
        
        print(f"\n  Starting sample generation...")
        
        for i in range(n_samples):
            # Randomly select resin - Updated to LCP series
            resin = random.choice(['LCP-1', 'LCP-2', 'LCP-3'])
            
            # Weave type
            weave = random.choice(['plain', 'twill_2x1', 'satin_5'])
            
            # ===== Pure Uniform Distribution, No Target Aiming =====
            Vf_actual = np.random.uniform(0.20, 0.72)
            
            # Generate STL and obtain structural parameters
            stl_file = None
            structural_params = {}
            
            if self.generate_stl:
                stl_file, Vf_actual_from_stl, structural_params = self.stl_generator.generate_weave_model(
                    weave, sample_id, temp_dir, size=8.0, target_Vf=Vf_actual
                )
                if stl_file:
                    stl_filename = Path(stl_file).name
                    dest_path = stl_dir / stl_filename
                    shutil.move(stl_file, dest_path)
                    stl_file = str(dest_path)
                    Vf_actual = Vf_actual_from_stl
            
            # If no STL, generate structural parameters
            if not structural_params:
                fiber_diameter = np.random.normal(0.7, 0.15)
                fiber_diameter = np.clip(fiber_diameter, 0.3, 1.2)
                spacing = fiber_diameter * np.random.uniform(1.2, 2.8)
                spacing = np.clip(spacing, 0.4, 2.5)
                
                structural_params = {
                    'fiber_diameter': fiber_diameter,
                    'spacing': spacing,
                    'n_fibers': max(4, int(8/spacing)),
                    'porosity': np.clip(np.random.normal(0.015, 0.005), 0.003, 0.035),
                    'orientation_efficiency': np.clip(np.random.normal(0.95, 0.015), 0.88, 0.99),
                    'waviness': np.random.uniform(0.93, 1.0),
                    'interface_area_density': 0.5 + 0.4 * np.random.random(),
                    'fiber_packing_efficiency': 0.80 + 0.15 * np.random.random(),
                    'mean_fiber_spacing': spacing,
                    'spacing_std': spacing * np.random.uniform(0.015, 0.07),
                    'uniformity_factor': 0.95 + 0.05 * np.random.random()
                }
            
            # Calculate modulus
            result = self.calculate_modulus(Vf_actual, resin, weave, structural_params)
            
            # Add design information
            result['sample_id'] = sample_id
            result['resin_type'] = resin
            result['weave_type'] = weave
            result['weave_name'] = self.weave_types[weave]['name']
            result['stl_file'] = stl_file
            
            # Add all structural parameters
            for key, value in structural_params.items():
                result[f'struct_{key}'] = value
            
            if stl_file and self.generate_stl:
                stl_manifest.append({
                    'sample_id': sample_id,
                    'stl_file': stl_filename,
                    'Vf_actual': Vf_actual,
                    'resin_type': resin,
                    'weave_type': weave,
                    'E_GPa': result['E_GPa']
                })
            
            all_samples.append(result)
            sample_id += 1
            
            if sample_id % 100 == 0:
                print(f"    Generated {sample_id}/{n_samples} samples...")
        
        # Random shuffle
        random.shuffle(all_samples)
        df = pd.DataFrame(all_samples)
        
        elapsed_time = time.time() - start_time
        print(f"\nData generation complete! Total {len(df)} samples")
        print(f"Generation time: {elapsed_time:.2f} seconds")
        
        E_values = df['E_GPa']
        print(f"  Modulus range: {E_values.min():.1f} - {E_values.max():.1f} GPa")
        print(f"  Average modulus: {E_values.mean():.1f} ± {E_values.std():.1f} GPa")
        
        # Vf statistics
        print(f"\n  Vf_actual statistics:")
        print(f"     Range: {df['Vf_actual'].min():.3f} - {df['Vf_actual'].max():.3f}")
        print(f"     Mean: {df['Vf_actual'].mean():.3f} ± {df['Vf_actual'].std():.3f}")
        
        # Clean temporary directory
        try:
            shutil.rmtree(temp_dir)
        except:
            pass
        
        return df, stl_manifest, output_dir
    
    def save_data_and_report(self, df, stl_manifest, output_dir):
        """Save data and generate detailed report"""
        csv_path = output_dir / "composite_physical_data.csv"
        df.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"\nData saved: {csv_path}")
        print(f"  Data columns: {len(df.columns)}")
        
        if stl_manifest:
            stl_df = pd.DataFrame(stl_manifest)
            stl_path = output_dir / "stl_manifest.csv"
            stl_df.to_csv(stl_path, index=False, encoding='utf-8-sig')
            print(f"STL manifest saved: {stl_path}")
        
        # Generate report (no target point statistics)
        report_path = output_dir / "data_report.txt"
        E_values = df['E_GPa']
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("Composite Material Dataset Report (Pure Physics Constraint v7.0)\n")
            f.write("Vf Generation Strategy: Pure Uniform Distribution U(0.20, 0.72)\n")
            f.write("Modulus Range: 60-180 GPa (Physical Constraint)\n")
            f.write("="*80 + "\n\n")
            
            f.write(f"Total samples: {len(df)}\n")
            f.write(f"STL files: {len(stl_manifest)}\n\n")
            
            f.write("Elastic Modulus Statistics (GPa):\n")
            f.write(f"  Min: {E_values.min():.2f}\n")
            f.write(f"  Max: {E_values.max():.2f}\n")
            f.write(f"  Mean: {E_values.mean():.2f}\n")
            f.write(f"  Std: {E_values.std():.2f}\n")
            f.write(f"  Median: {E_values.median():.2f}\n\n")
            
            f.write("Vf_actual Statistics:\n")
            f.write(f"  Range: {df['Vf_actual'].min():.3f} - {df['Vf_actual'].max():.3f}\n")
            f.write(f"  Mean: {df['Vf_actual'].mean():.3f}\n")
            f.write(f"  Std: {df['Vf_actual'].std():.3f}\n\n")
            
            f.write("Efficiency Factor Statistics:\n")
            for factor in ['eta_orientation', 'eta_crimp', 'eta_interface', 'eta_defect', 'eta_packing', 'total_efficiency']:
                if factor in df.columns:
                    f.write(f"  {factor}: mean={df[factor].mean():.4f}, std={df[factor].std():.4f}\n")
            f.write("\n")
            
            f.write("Feature Correlations (with Modulus):\n")
            for col in ['Vf_actual', 'eta_orientation', 'eta_interface', 'eta_defect', 'total_efficiency']:
                if col in df.columns:
                    corr = df[col].corr(df['E_GPa'])
                    f.write(f"  {col}: {corr:.4f}\n")
        
        print(f"Data report generated: {report_path}")


# ============================================================================
# 3. Data Validation and Visualization Module
# ============================================================================

class DataValidator:
    """Data validation and visualization module"""
    
    @staticmethod
    def validate_data(df, output_dir):
        """Validate data quality and generate visualization report"""
        print("\n" + "="*80)
        print("Data Validation and Visualization Check")
        print("="*80)
        
        viz_dir = output_dir / "visualizations"
        viz_dir.mkdir(exist_ok=True)
        
        # 1. Feature correlation analysis
        DataValidator._correlation_analysis(df, viz_dir)
        
        # 2. Physical consistency check
        DataValidator._physical_consistency_check(df, viz_dir)
        
        # 3. Data visualization
        DataValidator._visualize_data(df, viz_dir)
        
        print(f"\nVisualization report saved to: {viz_dir}")
    
    @staticmethod
    def _correlation_analysis(df, viz_dir):
        """Feature correlation analysis"""
        print("\nFeature Correlation Analysis:")
        
        key_features = ['Vf_actual', 'E_GPa']
        for factor in ['eta_orientation', 'eta_crimp', 'eta_interface', 'eta_defect', 'eta_packing', 'total_efficiency']:
            if factor in df.columns:
                key_features.append(factor)
        
        struct_cols = [col for col in df.columns if col.startswith('struct_')]
        important_struct = ['struct_porosity', 'struct_interface_area_density', 
                           'struct_spacing_std', 'struct_fiber_diameter']
        for col in important_struct:
            if col in df.columns:
                key_features.append(col)
        
        corr_df = df[key_features].corr()
        
        if 'E_GPa' in corr_df.columns:
            correlations = corr_df['E_GPa'].sort_values(ascending=False)
            print("\n  Feature correlations with E_GPa:")
            for feature, corr in correlations.items():
                if feature != 'E_GPa':
                    print(f"    {feature}: {corr:.4f}")
        
        corr_path = viz_dir / "correlation_matrix.csv"
        corr_df.to_csv(corr_path)
        print(f"  Correlation matrix saved: {corr_path}")
        
        try:
            plt.figure(figsize=(12, 10))
            sns.heatmap(corr_df, annot=True, fmt='.3f', cmap='RdBu_r', 
                       center=0, vmin=-1, vmax=1)
            plt.title('Feature Correlation Matrix', fontsize=14)
            plt.tight_layout()
            plt.savefig(viz_dir / 'correlation_heatmap.png', dpi=150)
            plt.close()
        except Exception as e:
            print(f"  Heatmap generation failed: {e}")
    
    @staticmethod
    def _physical_consistency_check(df, viz_dir):
        """Physical consistency check"""
        print("\nPhysical Consistency Check:")
        
        checks = []
        
        if 'Vf_actual' in df.columns and 'E_GPa' in df.columns:
            corr_vf = df['Vf_actual'].corr(df['E_GPa'])
            is_positive = corr_vf > 0
            checks.append(('Vf_actual Positive Correlation', is_positive, corr_vf))
            print(f"  Vf_actual vs E_GPa correlation: {corr_vf:.4f}")
        
        if 'eta_orientation' in df.columns and 'E_GPa' in df.columns:
            corr_ori = df['eta_orientation'].corr(df['E_GPa'])
            is_positive = corr_ori > 0
            checks.append(('Orientation Efficiency Positive', is_positive, corr_ori))
            print(f"  Orientation Efficiency vs E_GPa correlation: {corr_ori:.4f}")
        
        if 'struct_porosity' in df.columns and 'E_GPa' in df.columns:
            corr_por = df['struct_porosity'].corr(df['E_GPa'])
            is_negative = corr_por < 0
            checks.append(('Porosity Negative Correlation', is_negative, corr_por))
            print(f"  Porosity vs E_GPa correlation: {corr_por:.4f}")
        
        if 'eta_interface' in df.columns and 'E_GPa' in df.columns:
            corr_int = df['eta_interface'].corr(df['E_GPa'])
            is_positive = corr_int > 0
            checks.append(('Interface Efficiency Positive', is_positive, corr_int))
            print(f"  Interface Efficiency vs E_GPa correlation: {corr_int:.4f}")
        
        all_passed = all(check[1] for check in checks)
        print(f"\n  Physical consistency check: {'All Passed' if all_passed else 'Warning - Issues Detected'}")
        
        check_df = pd.DataFrame(checks, columns=['Check Item', 'Meets Expectation', 'Correlation'])
        check_path = viz_dir / "physical_consistency_check.csv"
        check_df.to_csv(check_path, index=False)
    
    @staticmethod
    def _visualize_data(df, viz_dir):
        """Data visualization"""
        print("\nGenerating visualization charts...")
        
        if 'Vf_actual' in df.columns and 'E_GPa' in df.columns:
            plt.figure(figsize=(10, 6))
            plt.scatter(df['Vf_actual'], df['E_GPa'], alpha=0.5, s=10)
            plt.xlabel('Fiber Volume Fraction Vf_actual')
            plt.ylabel('Elastic Modulus E (GPa)')
            plt.title('Effect of Vf_actual on Elastic Modulus (Pure Random Sampling)')
            plt.grid(True, alpha=0.3)
            plt.savefig(viz_dir / 'Vf_vs_E.png', dpi=150)
            plt.close()
            print("  Vf_actual vs E plot saved")
        
        if 'eta_orientation' in df.columns and 'E_GPa' in df.columns:
            plt.figure(figsize=(10, 6))
            plt.scatter(df['eta_orientation'], df['E_GPa'], alpha=0.5, s=10, c='green')
            plt.xlabel('Orientation Efficiency eta_orientation')
            plt.ylabel('Elastic Modulus E (GPa)')
            plt.title('Effect of Orientation Efficiency on Elastic Modulus')
            plt.grid(True, alpha=0.3)
            plt.savefig(viz_dir / 'orientation_vs_E.png', dpi=150)
            plt.close()
            print("  Orientation Efficiency vs E plot saved")
        
        if 'struct_porosity' in df.columns and 'E_GPa' in df.columns:
            plt.figure(figsize=(10, 6))
            plt.scatter(df['struct_porosity'], df['E_GPa'], alpha=0.5, s=10, c='red')
            plt.xlabel('Porosity')
            plt.ylabel('Elastic Modulus E (GPa)')
            plt.title('Effect of Porosity on Elastic Modulus')
            plt.grid(True, alpha=0.3)
            plt.savefig(viz_dir / 'porosity_vs_E.png', dpi=150)
            plt.close()
            print("  Porosity vs E plot saved")
        
        if 'E_GPa' in df.columns:
            plt.figure(figsize=(10, 6))
            plt.hist(df['E_GPa'], bins=30, alpha=0.7, color='blue', edgecolor='black')
            plt.xlabel('Elastic Modulus E (GPa)')
            plt.ylabel('Frequency')
            plt.title('Elastic Modulus Distribution (Pure Random Sampling)')
            plt.grid(True, alpha=0.3)
            plt.axvline(df['E_GPa'].mean(), color='red', linestyle='--', 
                       label=f'Mean: {df["E_GPa"].mean():.1f} GPa')
            plt.legend()
            plt.savefig(viz_dir / 'E_distribution.png', dpi=150)
            plt.close()
            print("  E modulus distribution plot saved")
        
        # Vf distribution check
        if 'Vf_actual' in df.columns:
            plt.figure(figsize=(10, 6))
            plt.hist(df['Vf_actual'], bins=30, alpha=0.7, color='orange', edgecolor='black')
            plt.xlabel('Fiber Volume Fraction Vf_actual')
            plt.ylabel('Frequency')
            plt.title('Vf_actual Distribution (Pure Uniform U(0.20, 0.72))')
            plt.grid(True, alpha=0.3)
            plt.savefig(viz_dir / 'Vf_distribution.png', dpi=150)
            plt.close()
            print("  Vf distribution plot saved")
        
        # Modulus distribution by weave type
        if 'weave_type' in df.columns and 'E_GPa' in df.columns:
            plt.figure(figsize=(10, 6))
            df.boxplot(column='E_GPa', by='weave_type', grid=True)
            plt.xlabel('Weave Type')
            plt.ylabel('Elastic Modulus E (GPa)')
            plt.title('Modulus Distribution by Weave Type')
            plt.suptitle('')
            plt.savefig(viz_dir / 'E_by_weave_type.png', dpi=150)
            plt.close()
            print("  Modulus by weave type plot saved")


# ============================================================================
# 4. Main Program
# ============================================================================

def main():
    """Main program"""
    print("\n" + "="*80)
    print("Composite Material Data Generator (Pure Physics Constraint v7.0)")
    print("Pure Data-Driven | Vf Range: 0.20-0.72 (Uniform Distribution)")
    print("="*80)
    
    print(f"\nData Generation Settings:")
    
    try:
        n_samples = int(input(f"  Number of samples (default 2000): ") or "2000")
        n_samples = max(100, min(n_samples, 20000))
    except:
        n_samples = 2000
    
    stl_input = input(f"  Generate STL models? (y/n, default y): ").strip().lower()
    generate_stl = stl_input != 'n' if stl_input else True
    
    validate_input = input(f"  Run data validation? (y/n, default y): ").strip().lower()
    run_validation = validate_input != 'n' if validate_input else True
    
    generator = PhysicsBasedDataGenerator(generate_stl=generate_stl)
    
    print(f"\nSettings Confirmation:")
    print(f"  Sample count: {n_samples}")
    print(f"  STL generation: {'Yes' if generate_stl else 'No'}")
    print(f"  Data validation: {'Yes' if run_validation else 'No'}")
    print(f"  Vf generation strategy: Pure Uniform Distribution U(0.20, 0.72)")
    print(f"  Modulus range: 60-180 GPa (Physical Constraint)")
    print(f"  No reference design points (Pure Data-Driven)")
    
    confirm = input(f"\nStart generating data? (y/n): ").strip().lower()
    if confirm != 'y':
        print("User cancelled")
        return
    
    # Generate data
    df, stl_manifest, output_dir = generator.generate_dataset(
        n_samples=n_samples
    )
    
    # Save data and report
    generator.save_data_and_report(df, stl_manifest, output_dir)
    
    # Data validation
    if run_validation:
        DataValidator.validate_data(df, output_dir)
    
    # Display results
    print(f"\nData generation complete!")
    print(f"Output directory: {output_dir}")
    print(f"\nFile list:")
    print(f"  - composite_physical_data.csv  : Main data file")
    print(f"  - data_report.txt               : Data report")
    if generate_stl:
        print(f"  - stl_manifest.csv             : STL file manifest")
        print(f"  - stl_models/                  : STL model file directory")
    if run_validation:
        print(f"  - visualizations/              : Visualization report directory")
    
    print(f"\nData columns (total {len(df.columns)} columns):")
    print(f"  Core variables: Vf_actual, E_GPa, resin_type, weave_type")
    print(f"  Efficiency factors: eta_orientation, eta_crimp, eta_interface, eta_defect, eta_packing")
    struct_cols = [col for col in df.columns if col.startswith('struct_')]
    print(f"  Structural parameters: {len(struct_cols)}")
    
    print(f"\nData Distribution Overview:")
    E_values = df['E_GPa']
    print(f"  Modulus range: {E_values.min():.1f} - {E_values.max():.1f} GPa")
    print(f"  Average modulus: {E_values.mean():.1f} ± {E_values.std():.1f} GPa")
    
    print(f"\nEfficiency Factor Statistics:")
    for factor in ['eta_orientation', 'eta_crimp', 'eta_interface', 'eta_defect', 'eta_packing', 'total_efficiency']:
        if factor in df.columns:
            print(f"  {factor}: {df[factor].mean():.4f} ± {df[factor].std():.4f}")

if __name__ == "__main__":
    main()