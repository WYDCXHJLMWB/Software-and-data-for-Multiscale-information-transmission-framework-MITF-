# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 21:57:03 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Aug  4 00:09:48 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-


import os
import sys
import numpy as np
import pandas as pd
import pickle
import warnings
from datetime import datetime
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import optuna
from optuna.samplers import TPESampler
import json
import random

warnings.filterwarnings('ignore')

print("="*80)
print("Composite Material Inverse Design System - Bayesian Optimization Version")
print("Using full dataset with STL features")
print("Actively searching for optimal solutions in continuous parameter space")
print("Model: Bayesian Ridge")
print("Features: Vf_actual + STL Geometric + Physical Structure + Resin Type + Weave Type")
print("Uses standardized data throughout (consistent with model training)")
print("="*80)

# ==================== Path Settings ====================
MODEL_PATH = r"your model from model construction code"
FEATURE_LIST_PATH = r"your feature from model construction code"
DATA_PATH = r"your data from model construction code"

# ==================== Resin and Weave Type Definitions ====================
RESIN_TYPES = ['LCP-1', 'LCP-2', 'LCP-3']
WEAVE_TYPES = ['plain', 'twill_2x1', 'satin_5']

# Resin properties reference
RESIN_PROPERTIES = {
    'LCP-1': {'E_GPa': 6.142, 'toughening_factor': 1.0, 'description': 'Standard toughness resin'},
    'LCP-2': {'E_GPa': 6.675, 'toughening_factor': 1.05, 'description': 'High toughness resin'},
    'LCP-3': {'E_GPa': 6.121, 'toughening_factor': 0.95, 'description': 'High modulus resin'}
}

WEAVE_PROPERTIES = {
    'plain': {'efficiency': 0.92, 'description': 'Plain weave, low cost'},
    'twill_2x1': {'efficiency': 0.95, 'description': '2x1 Twill weave, moderate performance'},
    'satin_5': {'efficiency': 0.97, 'description': '5-Harness Satin weave, excellent performance'}
}


class BayesianOptimizationDesigner:
    """Bayesian optimization inverse designer"""
    
    def __init__(self, model_path, data_path, feature_list_path=None):
        self.model_path = model_path
        self.data_path = data_path
        self.feature_list_path = feature_list_path
        
        self.model = None
        self.scaler_X = None
        self.encoder = None
        self.numerical_columns = []
        self.categorical_columns = []
        self.model_feature_names = []  # Model's actual feature names (including encoded)
        self.data_feature_names = []   # Feature names extracted from data
        self.feature_means = None
        self.feature_stds = None
        
        # Feature ranges (learned from data)
        self.feature_ranges = {}
        self.feature_stats = {}
        
        # Resin and weave type encoding mappings
        self.resin_encoding = {}
        self.weave_encoding = {}
        
        # Load model and data
        self.load_model()
        self.load_data_ranges()
        self.build_encoding_maps()
    
    def load_model(self):
        """Load model"""
        print(f"\nLoading model: {self.model_path}")
        
        if not os.path.exists(self.model_path):
            print(f"Model file does not exist")
            return
        
        with open(self.model_path, 'rb') as f:
            model_data = pickle.load(f)
        
        self.model = model_data['model']
        self.scaler_X = model_data.get('scaler_X')
        self.encoder = model_data.get('encoder')
        self.numerical_columns = model_data.get('numerical_columns', [])
        self.categorical_columns = model_data.get('categorical_columns', [])
        
        # Get model feature names
        if 'feature_names' in model_data:
            self.model_feature_names = model_data['feature_names']
            print(f"   Got features from model: {len(self.model_feature_names)}")
        else:
            print(f"   Warning: No feature names in model")
        
        # Get scaler mean and standard deviation
        if self.scaler_X is not None:
            self.feature_means = self.scaler_X.mean_
            self.feature_stds = self.scaler_X.scale_
            print(f"   Got standardization parameters")
        
        print(f"   Model loaded successfully: {type(self.model).__name__}")
        print(f"   Model feature count: {len(self.model_feature_names)}")
        
        # Display feature statistics
        if self.numerical_columns:
            print(f"   Numerical features: {len(self.numerical_columns)}")
        if self.categorical_columns:
            print(f"   Categorical features: {len(self.categorical_columns)}")
    
    def load_data_ranges(self):
        """Learn feature ranges from data"""
        print(f"\nLoading data: {self.data_path}")
        
        if not os.path.exists(self.data_path):
            print(f"Data file does not exist: {self.data_path}")
            # Try to find
            possible_paths = [
                r"C:\Users\ma'wei'bin\Desktop\Project\Step2\Modulus\model_results_with_resin_weave_seed166_20260805_125145\full_data_all_features.csv",
                r"C:\Users\ma'wei'bin\Desktop\Project\Step2\Modulus\composite_physical_data_20260805_115552\composite_physical_data.csv",
            ]
            for p in possible_paths:
                if os.path.exists(p):
                    self.data_path = p
                    print(f"   Found data: {self.data_path}")
                    break
            else:
                print(f"Cannot find data file")
                return
        
        df = pd.read_csv(self.data_path)
        print(f"   Data shape: {df.shape}")
        print(f"   Data columns: {len(df.columns)}")
        
        # Get feature names from data (numerical + categorical)
        self.data_feature_names = []
        
        # Numerical features
        for col in self.numerical_columns:
            if col in df.columns:
                self.data_feature_names.append(col)
        
        # Vf_actual special handling
        if 'Vf_actual' in df.columns and 'Vf_actual' not in self.data_feature_names:
            self.data_feature_names.append('Vf_actual')
        
        # Categorical features (original column names)
        for col in self.categorical_columns:
            if col in df.columns and col not in self.data_feature_names:
                self.data_feature_names.append(col)
        
        print(f"   Data features: {len(self.data_feature_names)}")
        
        # Extract feature ranges
        for idx, name in enumerate(self.data_feature_names):
            values = df[name].dropna().values
            
            # Categorical feature handling
            if name in self.categorical_columns:
                # Categorical features: get all possible values
                unique_vals = np.unique(values)
                # For categorical features, range uses index representation
                self.feature_ranges[name] = {
                    'type': 'categorical',
                    'values': unique_vals.tolist(),
                    'n_values': len(unique_vals)
                }
                print(f"   {name}: categorical variable, values: {unique_vals.tolist()}")
                continue
            
            # Numerical features
            if len(values) > 0:
                mean_val = np.mean(values)
                std_val = np.std(values)
                
                self.feature_stats[name] = {
                    'mean': mean_val,
                    'std': std_val,
                    'min': values.min(),
                    'max': values.max(),
                    'q25': np.percentile(values, 25),
                    'q50': np.percentile(values, 50),
                    'q75': np.percentile(values, 75)
                }
                
                # Set search range
                if name == 'Vf_actual':
                    low = max(0.05, values.min() - 0.02)
                    high = min(0.72, values.max() + 0.02)
                elif name.startswith('stl_'):
                    range_width = values.max() - values.min()
                    low = values.min() - 0.1 * range_width
                    high = values.max() + 0.1 * range_width
                    if name == 'stl_surface_uniformity':
                        low = max(0.0, low)
                        high = min(1.0, high)
                    elif name in ['stl_volume_to_area_ratio', 'stl_aspect_ratio']:
                        low = max(0.001, low)
                elif name.startswith('struct_'):
                    range_width = values.max() - values.min()
                    low = values.min() - 0.1 * range_width
                    high = values.max() + 0.1 * range_width
                    if name == 'struct_porosity':
                        low = max(0.001, low)
                        high = min(0.1, high)
                    elif name in ['struct_orientation_efficiency', 'struct_waviness', 
                                 'struct_uniformity_factor', 'struct_interface_area_density']:
                        low = max(0.3, low)
                        high = min(1.0, high)
                else:
                    low = values.min() - 0.1 * std_val
                    high = values.max() + 0.1 * std_val
                
                self.feature_ranges[name] = {
                    'type': 'numerical',
                    'low': low,
                    'high': high,
                    'mean': mean_val,
                    'std': std_val
                }
                
                if idx < 20:
                    print(f"   {name}: [{low:.4f}, {high:.4f}] (mean: {mean_val:.4f} ± {std_val:.4f})")
        
        print(f"\n   Successfully loaded ranges for {len(self.feature_ranges)} features")
    
    def build_encoding_maps(self):
        """Build encoding maps for resin and weave types"""
        if self.encoder is not None:
            # Get encoding mapping from encoder
            for i, col in enumerate(self.categorical_columns):
                categories = self.encoder.categories_[i]
                if col == 'resin_type':
                    for j, cat in enumerate(categories):
                        self.resin_encoding[cat] = j
                    print(f"   Resin encoding: {self.resin_encoding}")
                elif col == 'weave_type':
                    for j, cat in enumerate(categories):
                        self.weave_encoding[cat] = j
                    print(f"   Weave encoding: {self.weave_encoding}")
    
    def encode_categorical(self, resin_type, weave_type):
        """Encode categorical features"""
        # Use encoder for encoding
        if self.encoder is not None:
            # Build input data
            cat_data = []
            for col in self.categorical_columns:
                if col == 'resin_type':
                    cat_data.append(resin_type)
                elif col == 'weave_type':
                    cat_data.append(weave_type)
            
            # Convert to 2D array
            cat_array = np.array([cat_data])
            try:
                encoded = self.encoder.transform(cat_array)
                return encoded.flatten()
            except Exception as e:
                print(f"   Encoding failed: {e}")
                # Use manual encoding
                return self._manual_encode(resin_type, weave_type)
        else:
            # Manual encoding
            return self._manual_encode(resin_type, weave_type)
    
    def _manual_encode(self, resin_type, weave_type):
        """Manual encoding"""
        # Resin encoding: LCP-1=0, LCP-2=1, LCP-3=2
        resin_map = {'LCP-1': 0, 'LCP-2': 1, 'LCP-3': 2}
        # Weave encoding: plain=0, twill_2x1=1, satin_5=2
        weave_map = {'plain': 0, 'twill_2x1': 1, 'satin_5': 2}
        
        resin_encoded = resin_map.get(resin_type, 0)
        weave_encoded = weave_map.get(weave_type, 0)
        
        # One-hot encoding
        resin_onehot = np.zeros(len(RESIN_TYPES))
        resin_onehot[resin_encoded] = 1
        
        weave_onehot = np.zeros(len(WEAVE_TYPES))
        weave_onehot[weave_encoded] = 1
        
        return np.concatenate([resin_onehot, weave_onehot])
    
    def build_feature_vector(self, numerical_values, resin_type, weave_type):
        """Build complete feature vector (numerical features + categorical encoding)"""
        # Numerical features
        numeric_array = np.array(numerical_values).reshape(1, -1)
        
        # Categorical feature encoding
        cat_encoded = self.encode_categorical(resin_type, weave_type)
        cat_array = cat_encoded.reshape(1, -1)
        
        # Merge
        X = np.hstack([numeric_array, cat_array])
        return X.flatten()
    
    def predict(self, numerical_values, resin_type, weave_type):
        """
        Predict modulus
        numerical_values: List of original values for numerical features
        resin_type: Resin type (LCP-1, LCP-2, LCP-3)
        weave_type: Weave type (plain, twill_2x1, satin_5)
        """
        # Build feature vector
        X = self.build_feature_vector(numerical_values, resin_type, weave_type)
        X = X.reshape(1, -1)
        
        # Standardize
        if self.scaler_X is not None:
            X_scaled = self.scaler_X.transform(X)
        else:
            X_scaled = X
        
        pred = self.model.predict(X_scaled)[0]
        
        # Physical range limits
        if pred > 500 or pred < 0:
            return 1000.0
        
        return max(0.0, float(pred))
    
    def objective(self, trial):
        """Optuna objective function - minimize |prediction - target|"""
        # 1. Sample numerical features
        numerical_values = []
        for name in self.data_feature_names:
            if name in self.categorical_columns:
                continue  # Categorical features handled separately
            if name == 'Vf_actual' or name.startswith('stl_') or name.startswith('struct_'):
                range_info = self.feature_ranges[name]
                if range_info['type'] == 'numerical':
                    low, high = range_info['low'], range_info['high']
                    if name in ['stl_volume_to_area_ratio', 'stl_triangle_area_mean']:
                        value = trial.suggest_float(name, low, high, log=True)
                    else:
                        value = trial.suggest_float(name, low, high)
                    numerical_values.append(value)
        
        # 2. Sample resin type
        resin_type = trial.suggest_categorical('resin_type', RESIN_TYPES)
        
        # 3. Sample weave type
        weave_type = trial.suggest_categorical('weave_type', WEAVE_TYPES)
        
        # 4. Predict
        pred = self.predict(numerical_values, resin_type, weave_type)
        
        if pred > 500:
            return 10000.0
        
        gap = abs(pred - self.target_value)
        
        trial.set_user_attr('prediction', pred)
        trial.set_user_attr('gap', gap)
        trial.set_user_attr('resin_type', resin_type)
        trial.set_user_attr('weave_type', weave_type)
        trial.set_user_attr('numerical_values', numerical_values)
        
        return gap
    
    def optimize(self, target_E, n_trials=500):
        """Perform Bayesian optimization"""
        print(f"\nStarting Bayesian optimization...")
        print(f"   Target modulus: {target_E} GPa")
        print(f"   Number of trials: {n_trials}")
        print(f"   Search space: {len(self.data_feature_names)} dimensions (including resin and weave types)")
        print(f"   Model: {type(self.model).__name__}")
        print(f"   Resin types: {RESIN_TYPES}")
        print(f"   Weave types: {WEAVE_TYPES}")
        
        self.target_value = target_E
        
        study = optuna.create_study(
            sampler=TPESampler(seed=42, n_startup_trials=30),
            direction='minimize',
            study_name=f"bayesian_design_{target_E}GPa"
        )
        
        study.optimize(self.objective, n_trials=n_trials, show_progress_bar=True)
        
        best_pred = study.best_trial.user_attrs.get('prediction', 0)
        best_resin = study.best_trial.user_attrs.get('resin_type', 'LCP-2')
        best_weave = study.best_trial.user_attrs.get('weave_type', 'satin_5')
        best_gap = study.best_value
        
        print(f"\nOptimization complete!")
        print(f"   Best gap: {best_gap:.2f} GPa")
        print(f"   Best predicted modulus: {best_pred:.2f} GPa")
        print(f"   Best resin: {best_resin}")
        print(f"   Best weave: {best_weave}")
        
        return study
    
    def get_best_designs(self, study, top_n=10):
        """Get best designs"""
        valid_trials = []
        for trial in study.trials:
            pred = trial.user_attrs.get('prediction', 0)
            if 10 < pred < 500:
                valid_trials.append(trial)
        
        if not valid_trials:
            print(f"Warning: No valid predictions found, using all trials")
            valid_trials = study.trials
        
        sorted_trials = sorted(valid_trials, key=lambda t: t.value)
        
        best_designs = []
        for i, trial in enumerate(sorted_trials[:top_n]):
            pred = trial.user_attrs.get('prediction', 0)
            resin = trial.user_attrs.get('resin_type', 'N/A')
            weave = trial.user_attrs.get('weave_type', 'N/A')
            numerical_vals = trial.user_attrs.get('numerical_values', [])
            
            design = {
                'Rank': i + 1,
                'Predicted_Modulus_GPa': pred,
                'Gap_GPa': trial.value,
                'Trial_Number': trial.number,
                'Resin_Type': resin,
                'Resin_Modulus_GPa': RESIN_PROPERTIES.get(resin, {}).get('E_GPa', 0),
                'Resin_Toughening_Factor': RESIN_PROPERTIES.get(resin, {}).get('toughening_factor', 1.0),
                'Weave_Type': weave,
                'Weave_Efficiency': WEAVE_PROPERTIES.get(weave, {}).get('efficiency', 0),
            }
            
            # Add numerical features
            num_idx = 0
            for name in self.data_feature_names:
                if name in self.categorical_columns:
                    continue
                if num_idx < len(numerical_vals):
                    design[name] = numerical_vals[num_idx]
                    num_idx += 1
            
            best_designs.append(design)
        
        return best_designs
    
    def save_results(self, best_designs, study, target_E, output_dir):
        """Save results"""
        os.makedirs(output_dir, exist_ok=True)
        
        # 1. Save resin information
        resin_df = pd.DataFrame([{
            'Resin_Code': k,
            'Elastic_Modulus_GPa': v['E_GPa'],
            'Toughening_Factor': v['toughening_factor'],
            'Description': v['description']
        } for k, v in RESIN_PROPERTIES.items()])
        resin_df.to_csv(os.path.join(output_dir, 'resin_properties.csv'), index=False, encoding='utf-8-sig')
        print(f"Resin properties saved")
        
        # 2. Save weave information
        weave_df = pd.DataFrame([{
            'Weave_Code': k,
            'Efficiency': v['efficiency'],
            'Description': v['description']
        } for k, v in WEAVE_PROPERTIES.items()])
        weave_df.to_csv(os.path.join(output_dir, 'weave_properties.csv'), index=False, encoding='utf-8-sig')
        print(f"Weave properties saved")
        
        # 3. Save best designs
        if best_designs:
            df_best = pd.DataFrame(best_designs)
            df_best.to_csv(os.path.join(output_dir, 'best_designs.csv'), index=False, encoding='utf-8-sig')
            print(f"Best designs saved")
        
        # 4. Save all trials
        all_trials = []
        for trial in study.trials:
            pred = trial.user_attrs.get('prediction', 0)
            if 10 < pred < 500:
                row = {
                    'Trial_Number': trial.number,
                    'Predicted_Modulus_GPa': pred,
                    'Gap_GPa': trial.value,
                    'Target_Modulus_GPa': target_E,
                    'Resin_Type': trial.user_attrs.get('resin_type', 'N/A'),
                    'Weave_Type': trial.user_attrs.get('weave_type', 'N/A'),
                }
                numerical_vals = trial.user_attrs.get('numerical_values', [])
                num_idx = 0
                for name in self.data_feature_names:
                    if name in self.categorical_columns:
                        continue
                    if num_idx < len(numerical_vals):
                        row[name] = numerical_vals[num_idx]
                        num_idx += 1
                all_trials.append(row)
        
        if all_trials:
            df_all = pd.DataFrame(all_trials)
            df_all = df_all.sort_values('Gap_GPa')
            df_all.to_csv(os.path.join(output_dir, 'all_trials.csv'), index=False, encoding='utf-8-sig')
            print(f"All trials saved")
        
        # 5. Save optimization information
        info = {
            'Target_Modulus_GPa': target_E,
            'Total_Trials': len(study.trials),
            'Valid_Trials': len(all_trials),
            'Best_Gap_GPa': float(study.best_value),
            'Best_Prediction_GPa': float(study.best_trial.user_attrs.get('prediction', 0)),
            'Best_Resin': study.best_trial.user_attrs.get('resin_type', 'N/A'),
            'Best_Weave': study.best_trial.user_attrs.get('weave_type', 'N/A'),
            'Model_Type': type(self.model).__name__,
            'Model_Name': 'BayesianRidge',
            'Numerical_Features': [n for n in self.data_feature_names if n not in self.categorical_columns],
            'Categorical_Features': self.categorical_columns,
            'Available_Resin_Types': RESIN_TYPES,
            'Available_Weave_Types': WEAVE_TYPES,
            'Generation_Time': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        with open(os.path.join(output_dir, 'optimization_info.json'), 'w', encoding='utf-8') as f:
            json.dump(info, f, indent=2, ensure_ascii=False)
        print(f"Optimization information saved")
        
        # 6. Print best designs
        if best_designs:
            print(f"\nBest Designs (Target: {target_E} GPa):")
            print("="*100)
            print(f"   Available Resin Types: {RESIN_TYPES}")
            for r in RESIN_TYPES:
                props = RESIN_PROPERTIES[r]
                print(f"      - {r}: Modulus={props['E_GPa']:.3f} GPa, Toughening={props['toughening_factor']}")
            print(f"   Available Weave Types: {WEAVE_TYPES}")
            for w in WEAVE_TYPES:
                props = WEAVE_PROPERTIES[w]
                print(f"      - {w}: Efficiency={props['efficiency']:.3f}")
            print("="*100)
            
            for i, design in enumerate(best_designs[:5], 1):
                print(f"\n[{i}] Predicted Modulus: {design['Predicted_Modulus_GPa']:.2f} GPa (Gap: {design['Gap_GPa']:.2f})")
                print(f"    Trial Number: {design['Trial_Number']}")
                print(f"    Resin Type: {design.get('Resin_Type', 'N/A')} (Modulus: {design.get('Resin_Modulus_GPa', 0):.3f} GPa)")
                print(f"    Weave Type: {design.get('Weave_Type', 'N/A')} (Efficiency: {design.get('Weave_Efficiency', 0):.3f})")
                if 'Vf_actual' in design:
                    print(f"    Vf_actual: {design.get('Vf_actual', np.nan):.4f}")
                
                # Show important features
                key_features = ['struct_porosity', 'struct_orientation_efficiency', 
                              'struct_interface_area_density']
                for name in key_features:
                    if name in design:
                        print(f"    {name}: {design[name]:.4f}")
            print("="*100)


def main():
    global DATA_PATH
    
    print(f"\nPath Settings:")
    print(f"   Model: {MODEL_PATH}")
    print(f"   Data: {DATA_PATH}")
    if os.path.exists(FEATURE_LIST_PATH):
        print(f"   Feature List: {FEATURE_LIST_PATH}")
    
    if not os.path.exists(MODEL_PATH):
        print(f"Model file does not exist: {MODEL_PATH}")
        return
    
    if not os.path.exists(DATA_PATH):
        print(f"Data file does not exist: {DATA_PATH}")
        possible_paths = [
            r"C:\Users\ma'wei'bin\Desktop\Project\Step2\Modulus\model_results_with_resin_weave_seed166_20260805_125145\full_data_all_features.csv",
            r"C:\Users\ma'wei'bin\Desktop\Project\Step2\Modulus\composite_physical_data_20260805_115552\composite_physical_data.csv",
        ]
        found = False
        for p in possible_paths:
            if os.path.exists(p):
                DATA_PATH = p
                found = True
                print(f"   Found data file: {DATA_PATH}")
                break
        if not found:
            print(f"Cannot find data file")
            return
    
    print("\n" + "="*80)
    print("Resin Properties:")
    for r, props in RESIN_PROPERTIES.items():
        print(f"   {r}: Modulus={props['E_GPa']:.3f} GPa, Toughening={props['toughening_factor']}")
    print("Weave Properties:")
    for w, props in WEAVE_PROPERTIES.items():
        print(f"   {w}: Efficiency={props['efficiency']:.3f}")
    print("="*80)
    
    try:
        target_E = float(input(f"\nTarget Modulus (GPa) [default 150]: ") or "150")
        n_trials = int(input(f"Optimization Trials [default 500]: ") or "500")
    except:
        target_E = 150
        n_trials = 500
    
    designer = BayesianOptimizationDesigner(MODEL_PATH, DATA_PATH, FEATURE_LIST_PATH)
    
    if not designer.feature_ranges:
        print("Data loading failed")
        return
    
    study = designer.optimize(target_E, n_trials=n_trials)
    best_designs = designer.get_best_designs(study, top_n=10)
    
    output_dir = f"bayesian_design_BayesianRidge_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    designer.save_results(best_designs, study, target_E, output_dir)
    
    print(f"\nComplete!")
    print(f"Results saved in: {output_dir}")


if __name__ == "__main__":
    try:
        import optuna
        print("optuna library loaded")
    except ImportError:
        print("optuna library not installed, please run: pip install optuna")
        sys.exit(1)
    
    main()