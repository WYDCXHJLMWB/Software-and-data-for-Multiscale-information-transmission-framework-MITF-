# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 21:53:16 2026

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-



import os
import sys
import numpy as np
import pandas as pd
from pathlib import Path
import json
import re
from datetime import datetime
import warnings
from typing import Dict, List, Tuple, Optional, Union, Any
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
import pickle
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
warnings.filterwarnings('ignore')

# ==================== Tunable Parameters ====================
RANDOM_SEED = 166          
TEST_SIZE = 0.2           
N_FOLDS = 5               
TARGET_COLUMN = 'E_GPa'   
INCLUDE_VF = True          # ===== Include Vf as feature =====
VF_FEATURE = 'Vf_actual'   # ===== Use Vf_actual (actual value) =====
INCLUDE_RESIN = True       # ===== Include resin type =====
INCLUDE_WEAVE = True       # ===== Include weave type =====

# ==================== User Configurable Paths ====================
CSV_PATH = r"your composite_physical_data from dataconstruction code"
STL_BASE_DIR = r"your composite_physical_data stl_models from dataconstruction code"

# ==================== Resin and Weave Type Definitions ====================
RESIN_TYPES = ['LCP-1', 'LCP-2', 'LCP-3']
WEAVE_TYPES = ['plain', 'twill_2x1', 'satin_5']

print("\n" + "="*80)
print("Composite Material Multi-Modal Intelligent Modeling System - Full Feature v4.0")
print(f"Random Seed: {RANDOM_SEED}")
print(f"Test Set Ratio: {TEST_SIZE}")
print(f"Cross-Validation Folds: {N_FOLDS}")
print("Feature Types: STL Geometric + Physical Structure + Vf_actual + Resin Type + Weave Type")
print("Algorithms: 8 (Bayesian Ridge + 7 Non-linear Models)")
print("Output: Predictions, Feature Lists, Feature Importance for Each Model")
print("="*80)

# ==================== Setup Paths ====================
print(f"\nData Paths:")
print(f"   CSV File: {CSV_PATH}")
print(f"   STL Directory: {STL_BASE_DIR}")

if not os.path.exists(CSV_PATH):
    print(f"CSV file does not exist: {CSV_PATH}")
    sys.exit(1)

print(f"\nPath check passed")
print("="*80)

# Setup matplotlib style
plt.style.use('seaborn-v0_8-darkgrid')
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['figure.dpi'] = 100

# ==================== Dynamic Import Library ====================

def safe_import(module_name, optional=False):
    try:
        module = __import__(module_name)
        print(f"Loaded: {module_name}")
        return module
    except ImportError as e:
        if optional:
            print(f"Warning: {module_name} not installed (optional)")
            return None
        else:
            print(f"Error: {module_name} not installed")
            return None

sklearn = safe_import('sklearn')
if sklearn:
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split, KFold
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor, ExtraTreesRegressor
    from sklearn.svm import SVR
    from sklearn.linear_model import BayesianRidge
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.tree import DecisionTreeRegressor
    SKLEARN_AVAILABLE = True
    print(f"   Scikit-learn version: {sklearn.__version__}")
else:
    SKLEARN_AVAILABLE = False

trimesh = safe_import('trimesh', optional=True)
if trimesh:
    print(f"trimesh version: {trimesh.__version__}")
    TRIMESH_AVAILABLE = True
else:
    TRIMESH_AVAILABLE = False


# ==================== Define Feature Categories ====================

# ===== 1. STL Geometric Features (extracted from STL files) =====
STL_GEOMETRIC_FEATURES = [
    'stl_volume_to_area_ratio',
    'stl_aspect_ratio',
    'stl_triangle_area_mean',
    'stl_triangle_area_std',
    'stl_triangle_area_variation',
    'stl_centroid_x',
    'stl_centroid_y',
    'stl_centroid_z',
    'stl_complexity_index',
    'stl_surface_uniformity',
    'stl_size_ratio_xy',
    'stl_size_ratio_xz',
    'stl_size_ratio_yz',
]

# ===== 2. Physical Structure Features (read from CSV) =====
PHYSICAL_STRUCTURE_FEATURES = [
    'struct_fiber_diameter',
    'struct_spacing',
    'struct_n_fibers',
    'struct_spacing_ratio',
    'struct_porosity',
    'struct_fiber_packing_efficiency',
    'struct_orientation_efficiency',
    'struct_waviness',
    'struct_uniformity_factor',
    'struct_interface_area_density',
    'struct_mean_fiber_spacing',
    'struct_spacing_std',
]

# ===== 3. Categorical Features (resin and weave types) =====
CATEGORICAL_FEATURES = ['resin_type', 'weave_type']

# ===== 4. Excluded Features (data leakage) =====
EXCLUDED_FEATURES = [
    'Vf_target', 'Vf_design', 
    'Vf_difference', 'Vf_difference_percent',
    'E_fiber_GPa', 'E_resin_GPa', 'weave_efficiency',
    'resin_E_GPa', 'weave_base_efficiency',
    'E_voigt_GPa', 'E_reuss_GPa', 
    'E_MPa', 'variation_factor',
    'sample_id', 'sample_id0', 'id', 'index',
    'resin_name', 'weave_name',
    'stl_file', 'model_unique_id',
]

# ===== 5. Final Features Used =====
USED_FEATURES = []

if INCLUDE_VF:
    USED_FEATURES.append(VF_FEATURE)

USED_FEATURES.extend(STL_GEOMETRIC_FEATURES)
USED_FEATURES.extend(PHYSICAL_STRUCTURE_FEATURES)

print(f"\nFeature Configuration:")
print(f"   Vf_actual: {'Included' if INCLUDE_VF else 'Excluded'}")
print(f"   STL Geometric Features: {len(STL_GEOMETRIC_FEATURES)}")
print(f"   Physical Structure Features: {len(PHYSICAL_STRUCTURE_FEATURES)}")
print(f"   Resin Type: {'Included (One-Hot Encoding)' if INCLUDE_RESIN else 'Excluded'}")
print(f"   Weave Type: {'Included (One-Hot Encoding)' if INCLUDE_WEAVE else 'Excluded'}")


# ==================== STL Feature Extractor ====================

class STLFeatureExtractor:
    """Extract geometric features from STL models"""
    
    def __init__(self, stl_base_dir):
        self.stl_base_dir = stl_base_dir
        self.features_cache = {}
        self.trimesh_available = TRIMESH_AVAILABLE
        self.stl_features = STL_GEOMETRIC_FEATURES
    
    def extract_features_for_sample(self, sample_id):
        if sample_id in self.features_cache:
            return self.features_cache[sample_id]
        
        stl_file = self._find_stl_file(sample_id)
        if stl_file is None:
            return {'sample_id': sample_id}
        
        features = self._extract_stl_geometric_features(stl_file, sample_id)
        self.features_cache[sample_id] = features
        return features
    
    def _find_stl_file(self, sample_id):
        if not os.path.exists(self.stl_base_dir):
            return None
        stl_files = [f for f in os.listdir(self.stl_base_dir) if f.lower().endswith('.stl')]
        for filename in stl_files:
            num_matches = re.findall(r'\d+', filename)
            for num_str in num_matches:
                try:
                    if int(num_str) == sample_id:
                        return os.path.join(self.stl_base_dir, filename)
                except:
                    continue
        return None
    
    def _extract_stl_geometric_features(self, stl_file, sample_id):
        features = {'sample_id': sample_id}
        
        if not self.trimesh_available:
            return features
        
        try:
            mesh = trimesh.load(stl_file)
            
            volume = float(mesh.volume)
            area = float(mesh.area)
            
            bounds = mesh.bounds
            size_x = float(bounds[1][0] - bounds[0][0])
            size_y = float(bounds[1][1] - bounds[0][1])
            size_z = float(bounds[1][2] - bounds[0][2])
            
            all_features = {}
            all_features['stl_volume_to_area_ratio'] = volume / (area + 1e-10)
            all_features['stl_aspect_ratio'] = max(size_x, size_y, size_z) / (min(size_x, size_y, size_z) + 1e-10)
            
            triangles = mesh.triangles
            if len(triangles) > 0:
                v1 = triangles[:, 1] - triangles[:, 0]
                v2 = triangles[:, 2] - triangles[:, 0]
                areas = 0.5 * np.linalg.norm(np.cross(v1, v2), axis=1)
                all_features['stl_triangle_area_mean'] = float(np.mean(areas))
                all_features['stl_triangle_area_std'] = float(np.std(areas))
                all_features['stl_triangle_area_variation'] = float(np.std(areas) / (np.mean(areas) + 1e-10))
            else:
                all_features['stl_triangle_area_mean'] = 0.0
                all_features['stl_triangle_area_std'] = 0.0
                all_features['stl_triangle_area_variation'] = 0.0
            
            centroid = mesh.centroid
            all_features['stl_centroid_x'] = float(centroid[0])
            all_features['stl_centroid_y'] = float(centroid[1])
            all_features['stl_centroid_z'] = float(centroid[2])
            
            all_features['stl_complexity_index'] = float(len(mesh.faces) * area / (volume**2 + 1e-10))
            all_features['stl_surface_uniformity'] = 1.0 - float(all_features['stl_triangle_area_std'] / (all_features['stl_triangle_area_mean'] + 1e-10))
            
            all_features['stl_size_ratio_xy'] = size_x / (size_y + 1e-10)
            all_features['stl_size_ratio_xz'] = size_x / (size_z + 1e-10)
            all_features['stl_size_ratio_yz'] = size_y / (size_z + 1e-10)
            
            for key in self.stl_features:
                if key in all_features:
                    features[key] = all_features[key]
                    
        except Exception as e:
            print(f"     Failed to extract STL features for sample {sample_id}: {str(e)[:80]}")
        
        return features
    
    def extract_all_features(self, sample_ids):
        print(f"\nExtracting STL Geometric Features...")
        print(f"   Number of features: {len(self.stl_features)}")
        print(f"   Processing {len(sample_ids)} samples")
        
        all_features = {}
        valid_count = 0
        
        for sample_id in tqdm(sample_ids, desc="Processing STL files"):
            features = self.extract_features_for_sample(sample_id)
            stl_keys = [k for k in features.keys() if k.startswith('stl_')]
            if len(stl_keys) > 5:
                all_features[sample_id] = features
                valid_count += 1
            else:
                all_features[sample_id] = {'sample_id': sample_id}
        
        print(f"STL feature extraction complete:")
        print(f"   Successfully extracted: {valid_count} samples")
        print(f"   Success rate: {valid_count/len(sample_ids)*100:.1f}%")
        
        return all_features


# ==================== Data Preprocessor ====================

class DataPreprocessor:
    def __init__(self, target_column='E_GPa', include_vf=True, vf_feature='Vf_actual',
                 include_resin=True, include_weave=True):
        self.target_column = target_column
        self.include_vf = include_vf
        self.vf_feature = vf_feature
        self.include_resin = include_resin
        self.include_weave = include_weave
        self.id_columns = []
        self.feature_columns = []
        self.categorical_columns = []
        self.excluded_columns = []
    
    def preprocess(self, data):
        print(f"\nData Preprocessing...")
        print(f"   Original data shape: {data.shape}")
        print(f"   Original columns: {len(data.columns)}")
        
        data_clean = data.copy()
        
        if self.target_column not in data_clean.columns:
            print(f"Target column {self.target_column} does not exist")
            return None
        
        print(f"   Target column: {self.target_column}")
        
        self.id_columns = []
        for col in data_clean.columns:
            if col.lower() in ['sample_id', 'sample_id0', 'id', 'index']:
                self.id_columns.append(col)
        print(f"   ID columns: {self.id_columns}")
        
        all_columns = [col for col in data_clean.columns 
                      if col not in self.id_columns and col != self.target_column]
        
        self.feature_columns = []
        self.categorical_columns = []
        self.excluded_columns = []
        
        for col in all_columns:
            if self.include_vf and col == self.vf_feature:
                self.feature_columns.append(col)
            elif col in STL_GEOMETRIC_FEATURES:
                self.feature_columns.append(col)
            elif col in PHYSICAL_STRUCTURE_FEATURES:
                self.feature_columns.append(col)
            elif self.include_resin and col == 'resin_type':
                self.categorical_columns.append(col)
            elif self.include_weave and col == 'weave_type':
                self.categorical_columns.append(col)
            elif col in EXCLUDED_FEATURES:
                self.excluded_columns.append(col)
            else:
                self.excluded_columns.append(col)
        
        print(f"\nRetained Numerical Features ({len(self.feature_columns)}):")
        for col in self.feature_columns[:10]:
            if col == self.vf_feature:
                print(f"   - {col} *")
            elif col in STL_GEOMETRIC_FEATURES:
                print(f"   - {col} (geometry)")
            elif col in PHYSICAL_STRUCTURE_FEATURES:
                print(f"   - {col} (physics)")
        if len(self.feature_columns) > 10:
            print(f"   ... plus {len(self.feature_columns)-10} more")
        
        print(f"\nRetained Categorical Features ({len(self.categorical_columns)}):")
        for col in self.categorical_columns:
            print(f"   - {col}")
        
        return {
            'data': data_clean,
            'id_columns': self.id_columns,
            'feature_columns': self.feature_columns,
            'categorical_columns': self.categorical_columns,
            'excluded_columns': self.excluded_columns,
            'target_column': self.target_column,
        }


# ==================== Model Trainer ====================

class ModelTrainer:
    def __init__(self, test_size=0.2, random_state=88, n_folds=5):
        self.test_size = test_size
        self.random_state = random_state
        self.n_folds = n_folds
        self.all_models = {}
        self.results = []
        self.cv_predictions = {}
        self.test_predictions = {}
        self.trained_models = {}
        self.feature_usage = {}
        self.best_model_name = None
        self.categorical_columns = []
        self.numerical_columns = []
        self.encoder = None
        self.all_feature_names = []
        
        print(f"\nModel Trainer Configuration:")
        print(f"   Random seed: {self.random_state}")
        print(f"   Test set ratio: {self.test_size}")
        print(f"   Cross-validation folds: {self.n_folds}")
        print(f"   Number of algorithms: 8 (1 linear + 7 non-linear)")
    
    def _get_all_models(self):
        models = {
            'BayesianRidge': BayesianRidge(),
            'DecisionTree': DecisionTreeRegressor(max_depth=5, random_state=self.random_state),
            'RandomForest': RandomForestRegressor(n_estimators=100, max_depth=10, random_state=self.random_state, n_jobs=-1),
            'GradientBoosting': GradientBoostingRegressor(n_estimators=100, max_depth=5, learning_rate=0.1, random_state=self.random_state),
            'AdaBoost': AdaBoostRegressor(n_estimators=50, random_state=self.random_state),
            'ExtraTrees': ExtraTreesRegressor(n_estimators=100, max_depth=10, random_state=self.random_state, n_jobs=-1),
            'KNN': KNeighborsRegressor(n_neighbors=5),
            'SVM': SVR(kernel='rbf', C=1, epsilon=0.1),
        }
        return models
    
    def _categorize_features(self, feature_names):
        categories = {}
        for f in feature_names:
            if f == VF_FEATURE:
                categories[f] = 'Vf_actual'
            elif f in STL_GEOMETRIC_FEATURES:
                categories[f] = 'STL Geometric'
            elif f in PHYSICAL_STRUCTURE_FEATURES:
                categories[f] = 'Physical Structure'
            elif f.startswith('resin_type_'):
                categories[f] = 'Resin Type'
            elif f.startswith('weave_type_'):
                categories[f] = 'Weave Type'
            else:
                categories[f] = 'Other'
        return categories
    
    def prepare_data_with_encoding(self, data, categorical_columns, feature_columns):
        print(f"\nPreparing Data (One-Hot Encoding)...")
        
        self.categorical_columns = categorical_columns
        self.numerical_columns = feature_columns
        
        X_numerical = data[feature_columns].fillna(0).values
        
        if categorical_columns:
            X_categorical = data[categorical_columns].fillna('unknown').values
            
            self.encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
            X_categorical_encoded = self.encoder.fit_transform(X_categorical)
            
            cat_feature_names = []
            for i, col in enumerate(categorical_columns):
                categories = self.encoder.categories_[i]
                for cat in categories:
                    if cat != 'unknown':
                        cat_feature_names.append(f"{col}_{cat}")
            
            X = np.hstack([X_numerical, X_categorical_encoded])
            self.all_feature_names = feature_columns + cat_feature_names
            
            print(f"   Numerical features: {len(feature_columns)}")
            print(f"   Categorical features: {len(categorical_columns)} (encoded to {len(cat_feature_names)} features)")
            print(f"   Total features: {len(self.all_feature_names)}")
            
            return X, self.all_feature_names
        else:
            self.all_feature_names = feature_columns
            return X_numerical, self.all_feature_names
    
    def train_and_evaluate(self, data, feature_columns, categorical_columns, target_column='E_GPa'):
        print(f"\nTraining and Evaluating Models...")
        print(f"Best Model Selection: Maximum 5-fold CV R² mean")
        
        X, all_feature_names = self.prepare_data_with_encoding(data, categorical_columns, feature_columns)
        y = data[target_column].values
        
        if 'sample_id' in data.columns:
            sample_ids = data['sample_id'].values
        else:
            sample_ids = np.arange(len(y))
        
        print(f"   Samples: {len(X)}, Features: {X.shape[1]}")
        print(f"   Target statistics - mean: {y.mean():.4f}, std: {y.std():.4f}")
        print(f"   Target range: {y.min():.2f} - {y.max():.2f} GPa")
        
        X_train, X_test, y_train, y_test, id_train, id_test = train_test_split(
            X, y, sample_ids, test_size=self.test_size, random_state=self.random_state
        )
        
        print(f"   Training set: {len(X_train)}, Test set: {len(X_test)}")
        
        scaler_X = StandardScaler()
        X_train_scaled = scaler_X.fit_transform(X_train)
        X_test_scaled = scaler_X.transform(X_test)
        
        models = self._get_all_models()
        results = []
        
        for model_name, model in models.items():
            print(f"\n   Training {model_name}...")
            
            try:
                model.fit(X_train_scaled, y_train)
                
                self.trained_models[model_name] = {
                    'model': model,
                    'scaler_X': scaler_X,
                    'feature_names': all_feature_names,
                    'categorical_columns': categorical_columns,
                    'numerical_columns': feature_columns,
                    'encoder': self.encoder,
                    'model_type': model_name,
                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                
                self._record_feature_usage(model_name, model, all_feature_names)
                
                y_train_pred = model.predict(X_train_scaled)
                y_test_pred = model.predict(X_test_scaled)
                
                train_r2 = r2_score(y_train, y_train_pred)
                train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
                train_mae = mean_absolute_error(y_train, y_train_pred)
                
                test_r2 = r2_score(y_test, y_test_pred)
                test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
                test_mae = mean_absolute_error(y_test, y_test_pred)
                
                kf = KFold(n_splits=self.n_folds, shuffle=True, random_state=self.random_state)
                cv_r2_scores = []
                cv_rmse_scores = []
                cv_mae_scores = []
                cv_predictions = np.zeros_like(y_train)
                cv_fold_predictions = []
                
                fold_idx = 0
                for train_idx, val_idx in kf.split(X_train_scaled):
                    X_fold_train, X_fold_val = X_train_scaled[train_idx], X_train_scaled[val_idx]
                    y_fold_train, y_fold_val = y_train[train_idx], y_train[val_idx]
                    id_fold_val = id_train[val_idx]
                    
                    fold_model = models[model_name]
                    fold_model.fit(X_fold_train, y_fold_train)
                    
                    y_fold_pred = fold_model.predict(X_fold_val)
                    cv_predictions[val_idx] = y_fold_pred
                    
                    fold_df = pd.DataFrame({
                        'Sample_ID': id_fold_val,
                        'True_Value': y_fold_val,
                        'Predicted_Value': y_fold_pred,
                        'Fold': fold_idx + 1
                    })
                    cv_fold_predictions.append(fold_df)
                    
                    fold_r2 = r2_score(y_fold_val, y_fold_pred)
                    fold_rmse = np.sqrt(mean_squared_error(y_fold_val, y_fold_pred))
                    fold_mae = mean_absolute_error(y_fold_val, y_fold_pred)
                    
                    cv_r2_scores.append(fold_r2)
                    cv_rmse_scores.append(fold_rmse)
                    cv_mae_scores.append(fold_mae)
                    fold_idx += 1
                
                cv_all_folds_df = pd.concat(cv_fold_predictions, ignore_index=True)
                
                cv_mean_r2 = np.mean(cv_r2_scores)
                cv_std_r2 = np.std(cv_r2_scores)
                cv_mean_rmse = np.mean(cv_rmse_scores)
                cv_std_rmse = np.std(cv_rmse_scores)
                cv_mean_mae = np.mean(cv_mae_scores)
                cv_std_mae = np.std(cv_mae_scores)
                
                self.cv_predictions[model_name] = {
                    'cv_true': y_train,
                    'cv_pred': cv_predictions,
                    'cv_fold_details': cv_all_folds_df,
                    'cv_r2_scores': cv_r2_scores,
                    'cv_rmse_scores': cv_rmse_scores,
                    'cv_mae_scores': cv_mae_scores,
                    'cv_mean_r2': cv_mean_r2,
                    'cv_std_r2': cv_std_r2,
                    'cv_mean_rmse': cv_mean_rmse,
                    'cv_std_rmse': cv_std_rmse,
                    'cv_mean_mae': cv_mean_mae,
                    'cv_std_mae': cv_std_mae,
                    'sample_ids': id_train,
                }
                
                self.test_predictions[model_name] = {
                    'test_true': y_test,
                    'test_pred': y_test_pred,
                    'sample_ids': id_test,
                    'test_r2': test_r2,
                    'test_rmse': test_rmse,
                    'test_mae': test_mae,
                }
                
                result = {
                    'model_name': model_name,
                    'model': model,
                    'scaler_X': scaler_X,
                    'train_r2': train_r2,
                    'train_rmse': train_rmse,
                    'train_mae': train_mae,
                    'test_r2': test_r2,
                    'test_rmse': test_rmse,
                    'test_mae': test_mae,
                    'cv_mean_r2': cv_mean_r2,
                    'cv_std_r2': cv_std_r2,
                    'cv_mean_rmse': cv_mean_rmse,
                    'cv_std_rmse': cv_std_rmse,
                    'cv_mean_mae': cv_mean_mae,
                    'cv_std_mae': cv_std_mae,
                    'cv_r2_scores': cv_r2_scores,
                    'cv_rmse_scores': cv_rmse_scores,
                    'cv_mae_scores': cv_mae_scores,
                    'y_test_true': y_test,
                    'y_test_pred': y_test_pred,
                    'y_train': y_train,
                    'y_train_pred': y_train_pred,
                    'feature_names': all_feature_names,
                }
                
                results.append(result)
                self.all_models[model_name] = result
                
                print(f"      Train R²: {train_r2:.4f}, Train RMSE: {train_rmse:.4f} GPa")
                print(f"      Test R²: {test_r2:.4f}, Test RMSE: {test_rmse:.4f} GPa")
                print(f"      5-Fold CV Mean R²: {cv_mean_r2:.4f} (±{cv_std_r2:.4f})")
                print(f"      5-Fold CV Mean RMSE: {cv_mean_rmse:.4f} GPa (±{cv_std_rmse:.4f})")
                
                if cv_mean_r2 > 0.85:
                    rating = "Excellent"
                elif cv_mean_r2 > 0.6:
                    rating = "Good"
                elif cv_mean_r2 > 0.4:
                    rating = "Fair"
                else:
                    rating = "Poor"
                print(f"      Rating: {rating}")
                
            except Exception as e:
                print(f"      Training failed: {str(e)[:100]}")
        
        if not results:
            print("All models failed")
            return None, None
        
        best_model = self._select_best_model_by_cv(results)
        self.results = results
        return results, best_model
    
    def _record_feature_usage(self, model_name, model, feature_names):
        feature_usage = {
            'model_name': model_name,
            'model_type': type(model).__name__,
            'total_features': len(feature_names),
            'feature_names': feature_names,
            'feature_categories': self._categorize_features(feature_names),
        }
        
        try:
            if hasattr(model, 'feature_importances_'):
                importance = model.feature_importances_
                feature_usage['has_importance'] = True
                feature_usage['importance'] = importance
                sorted_idx = np.argsort(importance)[::-1]
                feature_usage['top_features'] = [(feature_names[i], importance[i]) for i in sorted_idx[:10]]
                feature_usage['category_importance'] = self._aggregate_importance_by_category(
                    feature_names, importance
                )
            elif hasattr(model, 'coef_'):
                coef = np.abs(model.coef_)
                feature_usage['has_coef'] = True
                feature_usage['coef'] = coef
                sorted_idx = np.argsort(coef)[::-1]
                feature_usage['top_features'] = [(feature_names[i], coef[i]) for i in sorted_idx[:10]]
                feature_usage['category_importance'] = self._aggregate_importance_by_category(
                    feature_names, coef
                )
        except:
            pass
        
        self.feature_usage[model_name] = feature_usage
    
    def _aggregate_importance_by_category(self, feature_names, importance):
        category_importance = {}
        category_features = {}
        
        for f, imp in zip(feature_names, importance):
            if f == VF_FEATURE:
                cat = 'Vf_actual'
            elif f in STL_GEOMETRIC_FEATURES:
                cat = 'STL Geometric'
            elif f in PHYSICAL_STRUCTURE_FEATURES:
                cat = 'Physical Structure'
            elif f.startswith('resin_type_'):
                cat = 'Resin Type'
            elif f.startswith('weave_type_'):
                cat = 'Weave Type'
            else:
                cat = 'Other'
            
            if cat not in category_importance:
                category_importance[cat] = 0
                category_features[cat] = []
            category_importance[cat] += imp
            category_features[cat].append(f)
        
        total = sum(category_importance.values())
        if total > 0:
            for cat in category_importance:
                category_importance[cat] /= total
        
        return {
            'importance': category_importance,
            'features': category_features
        }
    
    def _select_best_model_by_cv(self, results):
        results.sort(key=lambda x: (-x['cv_mean_r2'], -x['test_r2']))
        best = results[0]
        self.best_model_name = best['model_name']
        
        print(f"\n" + "="*80)
        print(f"Best Model: {best['model_name']}")
        print("="*80)
        print(f"\nPerformance Metrics:")
        print(f"   • 5-Fold CV Mean R²: {best['cv_mean_r2']:.4f} (±{best['cv_std_r2']:.4f})")
        print(f"   • 5-Fold CV Mean RMSE: {best['cv_mean_rmse']:.4f} GPa (±{best['cv_std_rmse']:.4f})")
        print(f"   • Test R²: {best['test_r2']:.4f}")
        print(f"   • Test RMSE: {best['test_rmse']:.4f} GPa")
        print(f"   • Train R²: {best['train_r2']:.4f}")
        
        return best
    
    def _create_visualizations(self, output_dir):
        """Create visualization charts"""
        try:
            if not self.results:
                return
            
            viz_dir = os.path.join(output_dir, 'visualizations')
            os.makedirs(viz_dir, exist_ok=True)
            
            # 1. Model performance comparison - R²
            fig, axes = plt.subplots(1, 2, figsize=(14, 6))
            
            model_names = [r['model_name'] for r in self.results]
            test_r2 = [r['test_r2'] for r in self.results]
            cv_r2 = [r['cv_mean_r2'] for r in self.results]
            
            x = np.arange(len(model_names))
            width = 0.35
            
            ax1 = axes[0]
            bars1 = ax1.bar(x - width/2, test_r2, width, label='Test R²', color='steelblue')
            bars2 = ax1.bar(x + width/2, cv_r2, width, label='CV Mean R²', color='coral')
            
            ax1.set_xlabel('Model', fontsize=11)
            ax1.set_ylabel('R² Score', fontsize=11)
            ax1.set_title('Model R² Comparison', fontsize=13, fontweight='bold')
            ax1.set_xticks(x)
            ax1.set_xticklabels(model_names, rotation=45, ha='right', fontsize=9)
            ax1.legend()
            ax1.grid(True, alpha=0.3, axis='y')
            
            # Add value labels
            for i, (bar1, bar2) in enumerate(zip(bars1, bars2)):
                height1 = bar1.get_height()
                height2 = bar2.get_height()
                ax1.text(bar1.get_x() + bar1.get_width()/2., height1,
                        f'{height1:.3f}', ha='center', va='bottom', fontsize=8)
                ax1.text(bar2.get_x() + bar2.get_width()/2., height2,
                        f'{height2:.3f}', ha='center', va='bottom', fontsize=8)
            
            # 2. Model performance comparison - RMSE
            test_rmse = [r['test_rmse'] for r in self.results]
            cv_rmse = [r['cv_mean_rmse'] for r in self.results]
            
            ax2 = axes[1]
            bars3 = ax2.bar(x - width/2, test_rmse, width, label='Test RMSE', color='steelblue')
            bars4 = ax2.bar(x + width/2, cv_rmse, width, label='CV Mean RMSE', color='coral')
            
            ax2.set_xlabel('Model', fontsize=11)
            ax2.set_ylabel('RMSE (GPa)', fontsize=11)
            ax2.set_title('Model RMSE Comparison', fontsize=13, fontweight='bold')
            ax2.set_xticks(x)
            ax2.set_xticklabels(model_names, rotation=45, ha='right', fontsize=9)
            ax2.legend()
            ax2.grid(True, alpha=0.3, axis='y')
            
            # Add value labels
            for i, (bar3, bar4) in enumerate(zip(bars3, bars4)):
                height3 = bar3.get_height()
                height4 = bar4.get_height()
                ax2.text(bar3.get_x() + bar3.get_width()/2., height3,
                        f'{height3:.1f}', ha='center', va='bottom', fontsize=8)
                ax2.text(bar4.get_x() + bar4.get_width()/2., height4,
                        f'{height4:.1f}', ha='center', va='bottom', fontsize=8)
            
            plt.tight_layout()
            plt.savefig(os.path.join(viz_dir, 'model_performance_comparison.png'), dpi=150, bbox_inches='tight')
            plt.close()
            print(f"   Model performance comparison plot saved")
            
            # 3. Best model prediction performance
            best_model = self.results[0]
            
            fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
            
            # Training set
            ax1 = axes[0]
            ax1.scatter(best_model['y_train'], best_model['y_train_pred'], alpha=0.6, color='steelblue', s=30)
            ax1.plot([best_model['y_train'].min(), best_model['y_train'].max()], 
                    [best_model['y_train'].min(), best_model['y_train'].max()], 
                    'r--', linewidth=2, label='Ideal Prediction')
            ax1.set_xlabel('True Value (GPa)', fontsize=11)
            ax1.set_ylabel('Predicted Value (GPa)', fontsize=11)
            ax1.set_title(f'Training Set: {best_model["model_name"]}\nR² = {best_model["train_r2"]:.4f}, RMSE = {best_model["train_rmse"]:.2f} GPa', 
                         fontsize=12, fontweight='bold')
            ax1.legend()
            ax1.grid(True, alpha=0.3)
            
            # Test set
            ax2 = axes[1]
            ax2.scatter(best_model['y_test_true'], best_model['y_test_pred'], alpha=0.6, color='coral', s=30)
            ax2.plot([best_model['y_test_true'].min(), best_model['y_test_true'].max()], 
                    [best_model['y_test_true'].min(), best_model['y_test_true'].max()], 
                    'r--', linewidth=2, label='Ideal Prediction')
            ax2.set_xlabel('True Value (GPa)', fontsize=11)
            ax2.set_ylabel('Predicted Value (GPa)', fontsize=11)
            ax2.set_title(f'Test Set: {best_model["model_name"]}\nR² = {best_model["test_r2"]:.4f}, RMSE = {best_model["test_rmse"]:.2f} GPa', 
                         fontsize=12, fontweight='bold')
            ax2.legend()
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig(os.path.join(viz_dir, 'best_model_predictions.png'), dpi=150, bbox_inches='tight')
            plt.close()
            print(f"   Best model prediction plot saved")
            
            # 4. Feature importance (best model)
            if self.feature_usage.get(best_model['model_name'], {}).get('has_importance'):
                usage = self.feature_usage[best_model['model_name']]
                if 'importance' in usage:
                    features = usage['feature_names']
                    importance = usage['importance']
                    
                    # Sort and take top 10
                    sorted_idx = np.argsort(importance)[-10:]
                    
                    plt.figure(figsize=(10, 8))
                    colors = []
                    for f in [features[i] for i in sorted_idx]:
                        if f == VF_FEATURE:
                            colors.append('gold')
                        elif f in STL_GEOMETRIC_FEATURES:
                            colors.append('steelblue')
                        elif f in PHYSICAL_STRUCTURE_FEATURES:
                            colors.append('coral')
                        elif f.startswith('resin_type_'):
                            colors.append('green')
                        elif f.startswith('weave_type_'):
                            colors.append('purple')
                        else:
                            colors.append('gray')
                    
                    plt.barh([features[i] for i in sorted_idx], [importance[i] for i in sorted_idx], color=colors)
                    plt.xlabel('Importance', fontsize=11)
                    plt.ylabel('Feature', fontsize=11)
                    plt.title(f'Best Model ({best_model["model_name"]}) Feature Importance Top 10', fontsize=13, fontweight='bold')
                    plt.grid(True, alpha=0.3, axis='x')
                    
                    from matplotlib.patches import Patch
                    legend_elements = [
                        Patch(facecolor='gold', label='Vf_actual'),
                        Patch(facecolor='steelblue', label='STL Geometric'),
                        Patch(facecolor='coral', label='Physical Structure'),
                        Patch(facecolor='green', label='Resin Type'),
                        Patch(facecolor='purple', label='Weave Type'),
                    ]
                    plt.legend(handles=legend_elements, loc='lower right')
                    
                    plt.tight_layout()
                    plt.savefig(os.path.join(viz_dir, 'best_model_feature_importance.png'), dpi=150, bbox_inches='tight')
                    plt.close()
                    print(f"   Best model feature importance plot saved")
            
            # 5. Feature category importance (best model)
            if self.feature_usage.get(best_model['model_name'], {}).get('category_importance'):
                usage = self.feature_usage[best_model['model_name']]
                cat_imp = usage['category_importance']
                
                categories = list(cat_imp['importance'].keys())
                values = list(cat_imp['importance'].values())
                
                plt.figure(figsize=(10, 6))
                colors = {'Vf_actual': 'gold', 'STL Geometric': 'steelblue', 
                         'Physical Structure': 'coral', 'Resin Type': 'green', 
                         'Weave Type': 'purple', 'Other': 'gray'}
                bar_colors = [colors.get(cat, 'gray') for cat in categories]
                
                plt.bar(categories, values, color=bar_colors)
                plt.xlabel('Feature Category', fontsize=11)
                plt.ylabel('Importance Ratio', fontsize=11)
                plt.title(f'Best Model ({best_model["model_name"]}) Feature Category Importance', fontsize=13, fontweight='bold')
                plt.grid(True, alpha=0.3, axis='y')
                
                for i, v in enumerate(values):
                    plt.text(i, v + 0.01, f'{v:.1%}', ha='center', va='bottom', fontsize=10)
                
                plt.tight_layout()
                plt.savefig(os.path.join(viz_dir, 'best_model_category_importance.png'), dpi=150, bbox_inches='tight')
                plt.close()
                print(f"   Best model category importance plot saved")
            
        except Exception as e:
            print(f"   Warning: Failed to create visualizations: {e}")
    
    def save_results(self, output_dir, merged_data=None, feature_columns=None, categorical_columns=None):
        """Save results"""
        if not self.results:
            print("Warning: No results to save")
            return
        
        os.makedirs(output_dir, exist_ok=True)
        
        predictions_dir = os.path.join(output_dir, 'predictions')
        os.makedirs(predictions_dir, exist_ok=True)
        
        # Save full data
        if merged_data is not None:
            full_data_path = os.path.join(output_dir, 'full_data_all_features.csv')
            merged_data.to_csv(full_data_path, index=False, encoding='utf-8-sig')
            print(f"\nFull data saved: {full_data_path}")
        
        # Save feature list
        if self.all_feature_names:
            feature_list_path = os.path.join(output_dir, 'all_features_list.csv')
            feature_df = pd.DataFrame({
                'Feature_Name': self.all_feature_names,
                'Feature_Category': [self._categorize_features([f])[f] for f in self.all_feature_names]
            })
            feature_df.to_csv(feature_list_path, index=False, encoding='utf-8-sig')
            print(f"All features list saved: {feature_list_path}")
        
        # Save predictions for each model
        print(f"\nSaving predictions for each model...")
        
        for model_name in self.all_models.keys():
            model_dir = os.path.join(predictions_dir, model_name.replace(' ', '_'))
            os.makedirs(model_dir, exist_ok=True)
            
            # CV predictions
            if model_name in self.cv_predictions:
                cv_data = self.cv_predictions[model_name]
                cv_df = pd.DataFrame({
                    'Sample_ID': cv_data['sample_ids'],
                    'True_Value': cv_data['cv_true'],
                    'Predicted_Value': cv_data['cv_pred'],
                })
                cv_df.to_csv(os.path.join(model_dir, 'CV_predictions.csv'), index=False, encoding='utf-8-sig')
                
                if 'cv_fold_details' in cv_data:
                    cv_data['cv_fold_details'].to_csv(
                        os.path.join(model_dir, 'CV_fold_details.csv'), 
                        index=False, encoding='utf-8-sig'
                    )
                
                cv_metrics = pd.DataFrame({
                    'Metric': ['Mean R²', 'Std R²', 'Mean RMSE', 'Std RMSE'],
                    'Value': [
                        cv_data['cv_mean_r2'],
                        cv_data['cv_std_r2'],
                        cv_data['cv_mean_rmse'],
                        cv_data['cv_std_rmse']
                    ]
                })
                cv_metrics.to_csv(os.path.join(model_dir, 'CV_metrics.csv'), index=False, encoding='utf-8-sig')
                
                print(f"   {model_name} CV predictions saved")
            
            # Test set predictions
            if model_name in self.test_predictions:
                test_data = self.test_predictions[model_name]
                test_df = pd.DataFrame({
                    'Sample_ID': test_data['sample_ids'],
                    'True_Value': test_data['test_true'],
                    'Predicted_Value': test_data['test_pred'],
                })
                test_df.to_csv(os.path.join(model_dir, 'Test_predictions.csv'), index=False, encoding='utf-8-sig')
                
                test_metrics = pd.DataFrame({
                    'Metric': ['R²', 'RMSE', 'MAE'],
                    'Value': [
                        test_data['test_r2'],
                        test_data['test_rmse'],
                        test_data['test_mae']
                    ]
                })
                test_metrics.to_csv(os.path.join(model_dir, 'Test_metrics.csv'), index=False, encoding='utf-8-sig')
                
                print(f"   {model_name} test set predictions saved")
            
            # Feature information
            if model_name in self.feature_usage:
                usage = self.feature_usage[model_name]
                
                feature_list_df = pd.DataFrame({
                    'Feature_Name': usage['feature_names'],
                    'Feature_Category': [usage['feature_categories'][f] for f in usage['feature_names']]
                })
                feature_list_df.to_csv(os.path.join(model_dir, 'feature_list.csv'), index=False, encoding='utf-8-sig')
                
                if usage.get('has_importance'):
                    importance_df = pd.DataFrame({
                        'Feature_Name': usage['feature_names'],
                        'Feature_Category': [usage['feature_categories'][f] for f in usage['feature_names']],
                        'Importance': usage['importance']
                    })
                    importance_df = importance_df.sort_values('Importance', ascending=False)
                    importance_df.to_csv(os.path.join(model_dir, 'feature_importance.csv'), index=False, encoding='utf-8-sig')
                    
                    if 'category_importance' in usage:
                        cat_imp = usage['category_importance']
                        cat_df = pd.DataFrame({
                            'Feature_Category': list(cat_imp['importance'].keys()),
                            'Importance_Ratio': list(cat_imp['importance'].values())
                        })
                        cat_df = cat_df.sort_values('Importance_Ratio', ascending=False)
                        cat_df.to_csv(os.path.join(model_dir, 'feature_category_importance.csv'), index=False, encoding='utf-8-sig')
                    
                    print(f"   {model_name} feature importance saved")
        
        # Model performance summary
        results_data = []
        for r in self.results:
            results_data.append({
                'Model_Name': r['model_name'],
                'Model_Type': 'Linear' if r['model_name'] == 'BayesianRidge' else 'Non-linear',
                'Train_R2': r['train_r2'],
                'Train_RMSE': r['train_rmse'],
                'Test_R2': r['test_r2'],
                'Test_RMSE': r['test_rmse'],
                '5Fold_CV_Mean_R2': r['cv_mean_r2'],
                '5Fold_CV_Std_R2': r['cv_std_r2'],
                '5Fold_CV_Mean_RMSE': r['cv_mean_rmse'],
                'Feature_Count': len(r['feature_names']),
            })
        
        results_df = pd.DataFrame(results_data)
        results_df = results_df.sort_values('5Fold_CV_Mean_R2', ascending=False)
        results_df.to_csv(os.path.join(output_dir, 'model_performance.csv'), index=False, encoding='utf-8-sig')
        print(f"\nModel performance summary saved")
        
        # Save models
        models_dir = os.path.join(output_dir, 'models')
        os.makedirs(models_dir, exist_ok=True)
        
        for model_name, model_data in self.trained_models.items():
            try:
                save_data = {
                    'model': model_data['model'],
                    'scaler_X': model_data['scaler_X'],
                    'model_name': model_name,
                    'feature_names': model_data['feature_names'],
                    'categorical_columns': model_data.get('categorical_columns', []),
                    'numerical_columns': model_data.get('numerical_columns', []),
                    'encoder': model_data.get('encoder'),
                    'timestamp': model_data['timestamp'],
                    'random_seed': self.random_state,
                }
                model_path = os.path.join(models_dir, f"{model_name.replace(' ', '_')}.pkl")
                with open(model_path, 'wb') as f:
                    pickle.dump(save_data, f)
                print(f"   {model_name} model saved")
            except Exception as e:
                print(f"   Failed to save {model_name}: {e}")
        
        # Visualizations
        self._create_visualizations(output_dir)
        
        print(f"\nAll results saved to: {output_dir}")


# ==================== Main Program ====================

def main():
    print("\n" + "="*80)
    print("Composite Material Multi-Modal Intelligent Modeling System - Full Feature v4.0")
    print("="*80)
    
    # Load data
    print(f"\nLoading data...")
    data = pd.read_csv(CSV_PATH)
    print(f"   Data shape: {data.shape}")
    print(f"   Columns: {len(data.columns)}")
    
    if TARGET_COLUMN not in data.columns:
        print(f"Target column {TARGET_COLUMN} does not exist")
        return
    
    print(f"   Target column: {TARGET_COLUMN}")
    print(f"   Target range: {data[TARGET_COLUMN].min():.2f} - {data[TARGET_COLUMN].max():.2f} GPa")
    
    if INCLUDE_VF and VF_FEATURE in data.columns:
        vf_stats = data[VF_FEATURE].describe()
        print(f"\n   Vf_actual statistics:")
        print(f"      Mean: {vf_stats['mean']:.4f}")
        print(f"      Range: [{vf_stats['min']:.4f}, {vf_stats['max']:.4f}]")
    
    if INCLUDE_RESIN and 'resin_type' in data.columns:
        print(f"\n   Resin type distribution:")
        for resin, count in data['resin_type'].value_counts().items():
            print(f"      {resin}: {count}")
    
    if INCLUDE_WEAVE and 'weave_type' in data.columns:
        print(f"\n   Weave type distribution:")
        for weave, count in data['weave_type'].value_counts().items():
            print(f"      {weave}: {count}")
    
    # Extract STL geometric features
    print(f"\nExtracting STL Geometric Features...")
    stl_extractor = STLFeatureExtractor(STL_BASE_DIR)
    
    if 'sample_id' in data.columns:
        sample_ids = data['sample_id'].unique().tolist()
    else:
        sample_ids = data.index.tolist()
    
    print(f"   Number of sample IDs: {len(sample_ids)}")
    stl_features_dict = stl_extractor.extract_all_features(sample_ids)
    
    # Build STL feature DataFrame
    print(f"\nBuilding STL feature DataFrame...")
    stl_data = []
    for sample_id, features in stl_features_dict.items():
        if isinstance(features, dict):
            row = {'sample_id': sample_id}
            for col in STL_GEOMETRIC_FEATURES:
                row[col] = features.get(col, np.nan)
            stl_data.append(row)
    
    stl_df = pd.DataFrame(stl_data)
    print(f"   STL feature DataFrame shape: {stl_df.shape}")
    
    # Merge all features
    print(f"\nMerging all features...")
    if 'sample_id' in data.columns:
        merged_data = pd.merge(data, stl_df, on='sample_id', how='left')
    else:
        merged_data = data.copy()
        for col in STL_GEOMETRIC_FEATURES:
            if col in stl_df.columns:
                merged_data[col] = stl_df[col]
    
    print(f"   Merged data shape: {merged_data.shape}")
    
    # Save merged data
    merged_path = os.path.join(os.path.dirname(CSV_PATH), 'full_data_all_features.csv')
    merged_data.to_csv(merged_path, index=False, encoding='utf-8-sig')
    print(f"\nFull data saved: {merged_path}")
    
    # Preprocess
    print(f"\nData Preprocessing...")
    preprocessor = DataPreprocessor(
        TARGET_COLUMN,
        include_vf=INCLUDE_VF,
        vf_feature=VF_FEATURE,
        include_resin=INCLUDE_RESIN,
        include_weave=INCLUDE_WEAVE
    )
    processed_data = preprocessor.preprocess(merged_data)
    
    if not processed_data:
        print("Data preprocessing failed")
        return
    
    # Train models
    print(f"\nTraining Models...")
    trainer = ModelTrainer(
        test_size=TEST_SIZE,
        random_state=RANDOM_SEED,
        n_folds=N_FOLDS
    )
    results, best_model = trainer.train_and_evaluate(
        processed_data['data'],
        processed_data['feature_columns'],
        processed_data['categorical_columns'],
        TARGET_COLUMN
    )
    
    if results is None:
        print("Model training failed")
        return
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f'model_results_with_resin_weave_seed{RANDOM_SEED}_{timestamp}'
    trainer.save_results(
        output_dir, 
        merged_data=merged_data,
        feature_columns=processed_data['feature_columns'],
        categorical_columns=processed_data['categorical_columns']
    )
    
    print(f"\nAnalysis complete!")
    print(f"Results saved in: {output_dir}/")
    print(f"\nAlgorithm List (8 types):")
    print(f"   Linear: Bayesian Ridge")
    print(f"   Non-linear: Decision Tree, Random Forest, Gradient Boosting, AdaBoost, ExtraTrees, KNN, SVM")
    print(f"\nFeature Inclusion:")
    print(f"   • Vf_actual: {'Yes' if INCLUDE_VF else 'No'}")
    print(f"   • Resin Type: {'Yes (One-Hot)' if INCLUDE_RESIN else 'No'}")
    print(f"   • Weave Type: {'Yes (One-Hot)' if INCLUDE_WEAVE else 'No'}")
    print(f"   • STL Geometric Features: {len(STL_GEOMETRIC_FEATURES)}")
    print(f"   • Physical Structure Features: {len(PHYSICAL_STRUCTURE_FEATURES)}")


if __name__ == "__main__":
    main()